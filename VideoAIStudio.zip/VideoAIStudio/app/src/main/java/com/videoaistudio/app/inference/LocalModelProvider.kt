package com.videoaistudio.app.inference

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.nio.FloatBuffer
import java.util.concurrent.CancellationException

/**
 * Chạy model do người dùng tự chọn (.onnx) — đọc THẲNG nội dung từ Content URI vào
 * RAM để nạp vào ONNX Runtime, KHÔNG copy ra thành file riêng trên ổ đĩa. Lý do đổi
 * cách này: copy ra đĩa sẽ chiếm gấp đôi dung lượng máy một cách không cần thiết,
 * nhất là với model vài trăm MB — đọc thẳng vào RAM rồi giải phóng ngay sau khi
 * nạp xong (ONNX Runtime giữ bản sao trong bộ nhớ của chính nó, buffer tạm này
 * có thể giải phóng) là cách dùng tài nguyên hợp lý hơn.
 */
class LocalModelProvider(
    private val context: Context,
    private val config: ModelConfig
) : IInferenceProvider {

    private val ortEnv: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    private var session: OrtSession? = null

    private fun readModelBytes(): ByteArray {
        val pathOrUri = config.localFilePath
            ?: throw IllegalArgumentException("ModelConfig thiếu localFilePath cho model local: ${config.displayName}")

        return if (pathOrUri.startsWith("content://")) {
            context.contentResolver.openInputStream(Uri.parse(pathOrUri))?.use { it.readBytes() }
                ?: throw IllegalStateException("Không đọc được model từ URI (có thể quyền truy cập đã bị thu hồi)")
        } else {
            // Tương thích ngược cho trường hợp có sẵn đường dẫn file thật (ít dùng tới).
            val f = File(pathOrUri)
            require(f.exists()) { "Không tìm thấy file model tại: $pathOrUri" }
            f.readBytes()
        }
    }

    private fun loadSessionIfNeeded() {
        if (session != null) return

        val modelBytes = readModelBytes()
        val options = OrtSession.SessionOptions()

        when (config.hardwareTarget) {
            HardwareTarget.GPU_NPU_AUTO -> {
                options.addNnapi()
            }
            HardwareTarget.NPU_QNN_FORCED -> {
                // TRIỂN KHAI THẬT (Phase 3) — trước đây luôn throw ở đây.
                //
                // Dùng QNN Execution Provider có sẵn trong gói
                // "onnxruntime-android-qnn" (xem app/build.gradle.kts) — KHÔNG cần tải
                // riêng QAIRT SDK, thư viện native Hexagon HTP đã nằm sẵn trong APK sau
                // khi build, Android tự giải nén vào thư mục native lib riêng của app.
                //
                // "backend_path" PHẢI trỏ đúng đường dẫn thật của libQnnHtp.so trên máy
                // (không phải chỉ tên file suông) — dùng applicationInfo.nativeLibraryDir
                // để lấy đúng đường dẫn, vì đây là nơi Android giải nén các thư viện .so
                // đóng gói theo từng ABI khi cài app.
                try {
                    val nativeLibDir = context.applicationInfo.nativeLibraryDir
                    val htpBackend = File(nativeLibDir, "libQnnHtp.so")
                    if (!htpBackend.exists()) {
                        throw UnsupportedOperationException(
                            "Không tìm thấy thư viện QNN HTP ($htpBackend) trong app. " +
                            "Máy này có thể không hỗ trợ kiến trúc CPU (ABI) mà QNN yêu cầu " +
                            "(cần arm64-v8a), hoặc gói onnxruntime-android-qnn chưa được " +
                            "build đúng cho thiết bị này."
                        )
                    }
                    // FIX: dùng đúng hàm Java API CHÍNH THỨC "addQnn(Map<String,String>)"
                    // (xem Javadoc: OrtSession.SessionOptions trên onnxruntime.ai) thay vì
                    // "addExecutionProvider(\"QNN\", map)" — hàm đó KHÔNG có overload nhận
                    // String tên provider trong Java API của ONNX Runtime; overload thật
                    // của addExecutionProvider() nhận List<OrtEpDevice>, không phải String.
                    // Gọi sai overload có thể không compile được hoặc gọi nhầm API khác.
                    // [SỬA 11/10/2026] TẮT CPU fallback — trước đây chế độ "NPU ép buộc" CHỈ gọi
                    // addQnn() nên phép nào QNN không nhận vẫn rớt về CPU EP (ONNX Runtime luôn thêm
                    // CPU EP làm đường lùi mặc định) mà không báo gì, trong khi tài liệu/comment
                    // khẳng định "báo lỗi thay vì rớt CPU" — xem PROJECT_SPEC.md mục 6, 11/10/2026
                    // (bổ sung 2). Khoá "session.disable_cpu_ep_fallback" do chính tài liệu QNN EP của
                    // ONNX Runtime nêu. Hệ quả CÓ CHỦ ĐÍCH: model float chưa lượng tử hoá / có phép NPU
                    // không nhận sẽ BÁO LỖI khi nạp ở chế độ này (UI đã có sẵn luồng hỏi lùi về lớp nền).
                    options.addConfigEntry("session.disable_cpu_ep_fallback", "1")
                    options.addQnn(
                        mapOf(
                            "backend_path" to htpBackend.absolutePath,
                            // "burst": ưu tiên tốc độ tối đa cho phiên chạy ngắn (đúng use-case
                            // xử lý từng frame video), đánh đổi hao pin hơn so với "balanced".
                            "htp_performance_mode" to "burst"
                        )
                    )
                } catch (e: UnsupportedOperationException) {
                    throw e
                } catch (e: Exception) {
                    // QNN EP có thể ném lỗi native (UnsatisfiedLinkError, RuntimeException...)
                    // nếu chip không có Hexagon NPU tương thích hoặc driver máy quá cũ/mới so
                    // với bản QNN đóng gói — bọc lại thành 1 loại lỗi rõ ràng, nhất quán với
                    // hành vi cũ (throw UnsupportedOperationException) để UI xử lý đồng nhất.
                    throw UnsupportedOperationException(
                        "Máy này không chạy được QNN (Hexagon NPU): ${e.message}. " +
                        "Hãy dùng lớp nền (GPU/NPU tự động) thay thế.",
                        e
                    )
                }
            }
            HardwareTarget.CPU -> {
                // Không thêm EP nào -> ONNX Runtime mặc định chạy CPU.
            }
        }

        session = ortEnv.createSession(modelBytes, options)
    }

    /**
     * Kiểm tra khả năng chạy model trên phần cứng đã cấu hình, kèm ước lượng
     * % phép tính chạy được trên accelerator (GPU/NPU) so với CPU khi dùng lớp nền.
     * UI gọi hàm này khi người dùng bấm "Kiểm tra model" hoặc trước lần chạy đầu tiên,
     * để quyết định chấp nhận hiệu suất hay tìm model khác.
     */
    suspend fun checkCompatibility(): CompatibilityReport = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()
            session ?: throw IllegalStateException("Session chưa khởi tạo")

            // [THÊM 11/10/2026] đo thời gian chạy thật 1 lần trên đúng phần cứng đang chọn — để
            // người dùng tự so CPU với NPU trên CÙNG model thay vì tin vào lời quảng cáo.
            val timingNote = measureInferenceNote()

            when (config.hardwareTarget) {
                HardwareTarget.NPU_QNN_FORCED -> {
                    // Giờ CÓ THỂ tới được đây thật (trước đây throw ở loadSessionIfNeeded
                    // nên nhánh này chỉ là code chết). Không có API đếm % phép tính chạy
                    // trên Hexagon HTP như NNAPI profiling ở nhánh GPU_NPU_AUTO bên dưới —
                    // QNN EP của ONNX Runtime hiện chưa lộ thông tin breakdown này qua log
                    // profiling theo cùng định dạng, nên chỉ báo "chạy được", không có %.
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        message = "Model nạp thành công qua QNN (Hexagon NPU). Đã TẮT CPU fallback nên nạp được " +
                            "nghĩa là không có phép nào bị đẩy sang CPU (theo cấu hình ONNX Runtime).$timingNote"
                    )
                }
                HardwareTarget.GPU_NPU_AUTO -> {
                    val breakdown = estimateHardwareBreakdown()
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        percentOpsOnAccelerator = breakdown?.first,
                        percentOpsOnCpu = breakdown?.second,
                        message = if (breakdown != null) {
                            "Model chạy được. Ước tính ${breakdown.first}% phép tính qua GPU/NPU, ${breakdown.second}% qua CPU.$timingNote"
                        } else {
                            "Model chạy được qua NNAPI, nhưng không xác định được chi tiết tỉ lệ GPU/NPU vs CPU trên thiết bị này.$timingNote"
                        }
                    )
                }
                HardwareTarget.CPU -> {
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        percentOpsOnAccelerator = 0,
                        percentOpsOnCpu = 100,
                        message = "Chạy hoàn toàn trên CPU (không dùng accelerator).$timingNote"
                    )
                }
            }
        } catch (e: UnsupportedOperationException) {
            CompatibilityReport(
                hardwareTarget = config.hardwareTarget,
                loadSucceeded = false,
                message = e.message ?: "Chế độ phần cứng này chưa được hỗ trợ."
            )
        } catch (e: Exception) {
            val qnnHint = if (config.hardwareTarget == HardwareTarget.NPU_QNN_FORCED) {
                "\n\nỞ chế độ NPU ép buộc (đã tắt CPU fallback), lỗi này thường nghĩa là model có phép hoặc kiểu " +
                "dữ liệu mà NPU không nhận — vd model float chưa lượng tử hoá (QDQ) hoặc có kích thước đầu vào " +
                "động. NPU Hexagon chỉ chạy model đã lượng tử hoá, kích thước cố định."
            } else ""
            CompatibilityReport(
                hardwareTarget = config.hardwareTarget,
                loadSucceeded = false,
                message = "Model không tương thích hoặc lỗi khi nạp: ${e.message}$qnnHint"
            )
        }
    }

    /**
     * [THÊM 11/10/2026] Chạy thử 2 lần trên session ĐÃ NẠP (đúng phần cứng đã cấu hình) bằng đầu vào
     * GIẢ toàn số 0, đo mili-giây từng lần. Lần 1 có thể gồm chi phí khởi tạo/đồng bộ lần đầu nên
     * báo riêng. Chỉ hỗ trợ model có MỌI đầu vào là số thực (float); chiều ảnh động (<=0) ở vị trí
     * H/W của tensor 4 chiều đặt = TIMING_DYNAMIC_SPATIAL_SIZE (số đoán, KHÔNG phải kích thước
     * thật người dùng sẽ dùng — chỉ để có con số so sánh CPU/NPU trên cùng điều kiện); chiều động
     * khác đặt = 1. Mọi lỗi (kể cả lỗi lúc chạy trên NPU) được báo lại thành chữ, không ném ra ngoài.
     * 🔴 CHƯA CHẠY THỬ trên máy thật.
     */
    private fun measureInferenceNote(): String {
        val s = session ?: return ""
        val tensors = mutableListOf<OnnxTensor>()
        try {
            val inputs = mutableMapOf<String, OnnxTensor>()
            for ((name, info) in s.inputInfo) {
                val tensorInfo = info.info as? ai.onnxruntime.TensorInfo
                    ?: return "\n(Không đo được thời gian chạy thử: đầu vào '$name' không phải tensor.)"
                if (tensorInfo.type != ai.onnxruntime.OnnxJavaType.FLOAT) {
                    return "\n(Không đo được thời gian chạy thử: đầu vào '$name' không phải số thực float.)"
                }
                val shape = tensorInfo.shape
                // Vị trí H/W của tensor 4 chiều: NHWC ([1,H,W,3]) -> 1..2; còn lại (NCHW hoặc không rõ) -> 2..3.
                val isNhwc = shape.size == 4 && shape[1] != 3L && shape[3] == 3L
                val spatialRange = if (isNhwc) 1..2 else 2..3
                val dims = LongArray(shape.size) { i ->
                    val d = shape[i]
                    if (d > 0) d else if (shape.size == 4 && i in spatialRange) TIMING_DYNAMIC_SPATIAL_SIZE else 1L
                }
                val count = dims.fold(1L) { acc, d -> acc * d }
                if (count > TIMING_MAX_ELEMENTS) {
                    return "\n(Không đo được thời gian chạy thử: đầu vào '$name' quá lớn để chạy thử an toàn.)"
                }
                val tensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.allocate(count.toInt()), dims)
                tensors.add(tensor)
                inputs[name] = tensor
            }
            if (inputs.isEmpty()) return ""

            val t0 = System.nanoTime()
            s.run(inputs).close()
            val t1 = System.nanoTime()
            s.run(inputs).close()
            val t2 = System.nanoTime()
            return "\nChạy thử 2 lần với đầu vào giả (toàn số 0; chiều ảnh động đặt = $TIMING_DYNAMIC_SPATIAL_SIZE): " +
                "lần 1 ${(t1 - t0) / 1_000_000} ms, lần 2 ${(t2 - t1) / 1_000_000} ms. " +
                "Muốn biết NPU có nhanh hơn CPU không: bấm Kiểm tra với CHÍNH model này ở từng lựa chọn phần cứng rồi so lần 2."
        } catch (e: Exception) {
            return "\nChạy thử THẤT BẠI trên phần cứng này: ${e.message}"
        } finally {
            tensors.forEach { it.close() }
        }
    }

    /**
     * Chạy thử 1 lần suy luận với input rỗng (giá trị 0) để bật profiling, đọc lại
     * log profiling của ONNX Runtime nhằm ước lượng số phép tính chạy trên NNAPI EP
     * so với CPU EP fallback. Đây là ước lượng best-effort: nếu định dạng log
     * profiling thay đổi giữa các phiên bản ONNX Runtime, hàm sẽ trả null thay vì
     * báo số liệu sai.
     */
    private fun estimateHardwareBreakdown(): Pair<Int, Int>? {
        var profSession: OrtSession? = null
        val tensors = mutableListOf<OnnxTensor>()
        return try {
            val profilingOptions = OrtSession.SessionOptions().apply { addNnapi() }
            profilingOptions.enableProfiling("model_profile")
            profSession = ortEnv.createSession(readModelBytes(), profilingOptions)

            val inputs = mutableMapOf<String, OnnxTensor>()
            profSession.inputInfo.forEach { (name, info) ->
                val tensorInfo = info.info as? ai.onnxruntime.TensorInfo ?: return@forEach
                val fixedShape = tensorInfo.shape.map { if (it <= 0) 1L else it }.toLongArray()
                val size = fixedShape.fold(1L) { acc, d -> acc * d }.toInt()
                val tensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.allocate(size), fixedShape)
                tensors.add(tensor)
                inputs[name] = tensor
            }

            if (inputs.isNotEmpty()) {
                profSession.run(inputs)
            }
            val profileFilePath = profSession.endProfiling()

            val profileFile = File(profileFilePath)
            if (!profileFile.exists()) return null

            val json = JSONArray(profileFile.readText())
            var acceleratedCount = 0
            var cpuCount = 0
            for (i in 0 until json.length()) {
                val entry = json.optJSONObject(i) ?: continue
                val args = entry.optJSONObject("args") ?: continue
                val provider = args.optString("provider", "")
                when {
                    provider.contains("Nnapi", ignoreCase = true) -> acceleratedCount++
                    provider.contains("CPU", ignoreCase = true) -> cpuCount++
                }
            }
            profileFile.delete()

            val total = acceleratedCount + cpuCount
            if (total == 0) return null

            val acceleratedPercent = (acceleratedCount * 100) / total
            Pair(acceleratedPercent, 100 - acceleratedPercent)
        } catch (e: Exception) {
            null
        } finally {
            tensors.forEach { it.close() }
            profSession?.close()
        }
    }

    /**
     * Tự dò cấu trúc I/O của model upscale, KHÔNG hardcode bất kỳ model cụ thể nào —
     * áp dụng nguyên lý chung của mọi model super-resolution: nhận 1 ảnh, trả 1 ảnh
     * lớn hơn theo 1 hệ số cố định.
     *
     * Cách dò:
     * 1. Đọc shape input để biết bố cục NCHW ([1,3,H,W]) hay NHWC ([1,H,W,3]).
     * 2. Chạy thử với 1 ảnh giả kích thước cố định (dummy), so sánh kích thước
     *    output/input để tự tính hệ số upscale thực tế của MODEL ĐÓ (x2/x3/x4...),
     *    không cần người dùng khai báo tay, không cần biết trước tên/kiến trúc model.
     */
    suspend fun detectUpscaleModelSpec(): UpscaleModelSpec? = withContext(Dispatchers.Default) {
        val modelPath = config.localFilePath ?: return@withContext null
        var probeSession: OrtSession? = null
        val tensors = mutableListOf<OnnxTensor>()
        try {
            probeSession = ortEnv.createSession(readModelBytes(), OrtSession.SessionOptions())

            val inputEntry = probeSession.inputInfo.entries.firstOrNull() ?: return@withContext null
            val inputTensorInfo = inputEntry.value.info as? ai.onnxruntime.TensorInfo ?: return@withContext null
            val shape = inputTensorInfo.shape // vd [1,3,-1,-1] (NCHW) hoặc [1,-1,-1,3] (NHWC)

            val isNCHW = shape.size == 4 && shape[1] == 3L
            val isNHWC = shape.size == 4 && shape[3] == 3L
            if (!isNCHW && !isNHWC) return@withContext null // không nhận diện được bố cục -> báo không hỗ trợ, không đoán bừa

            // [SỬA 12/10/2026] Model có chiều ảnh CỐ ĐỊNH (vd model QDQ cho NPU) chỉ nhận đúng cỡ đó — dò bằng ảnh giả đúng cỡ
            // đó (trước đây luôn dùng 64x64 nên model tĩnh bị báo lỗi shape và coi như "không dò được"). Chiều động: vẫn 64.
            val hIdx = if (isNCHW) 2 else 1
            val wIdx = if (isNCHW) 3 else 2
            val fixedH = shape[hIdx].takeIf { it > 0 }?.toInt()
            val fixedW = shape[wIdx].takeIf { it > 0 }?.toInt()
            val probeH = fixedH ?: 64 // kích thước ảnh giả nhỏ để dò nhanh, không tốn tài nguyên
            val probeW = fixedW ?: 64
            val dummyShape = if (isNCHW) longArrayOf(1, 3, probeH.toLong(), probeW.toLong())
                              else longArrayOf(1, probeH.toLong(), probeW.toLong(), 3)
            val elementCount = dummyShape.fold(1L) { acc, d -> acc * d }.toInt()
            val dummyTensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.allocate(elementCount), dummyShape)
            tensors.add(dummyTensor)

            val outputs = probeSession.run(mapOf(inputEntry.key to dummyTensor))
            val outputTensorInfo = outputs[0].info as? ai.onnxruntime.TensorInfo ?: return@withContext null
            val outShape = outputTensorInfo.shape
            outputs.close()

            val outHeight = if (isNCHW) outShape.getOrNull(2) else outShape.getOrNull(1)
            val outWidth = if (isNCHW) outShape.getOrNull(3) else outShape.getOrNull(2)
            if (outHeight == null || outWidth == null || outHeight <= 0 || outWidth <= 0) return@withContext null

            val scaleFactor = (outHeight.toDouble() / probeH).let { Math.round(it).toInt() }
                .coerceAtLeast(1)

            val bothFixed = fixedH != null && fixedW != null
            UpscaleModelSpec(
                layout = if (isNCHW) TensorLayout.NCHW else TensorLayout.NHWC,
                detectedScaleFactor = scaleFactor,
                // "Linh hoạt" chỉ tính chiều ẢNH (H/W) — chiều batch động không giúp được gì cho việc đưa ảnh cỡ bất kỳ vào.
                supportsDynamicResolution = !bothFixed,
                fixedInputWidth = if (bothFixed) fixedW else null,
                fixedInputHeight = if (bothFixed) fixedH else null
            )
        } catch (e: Exception) {
            null
        } finally {
            tensors.forEach { it.close() }
            probeSession?.close()
        }
    }

    /**
     * Lý do thật của lần [upscaleFrame] gần nhất thất bại (null nếu lần đó thành công hoặc chưa gọi). [upscaleFrame] trả null
     * cho mọi lỗi — trước đây người dùng chỉ thấy "Model xử lý thất bại" mà không biết vì sao; UI nay hiển thị chuỗi này.
     */
    @Volatile
    var lastError: String? = null
        private set

    /**
     * Chạy upscale cho 1 frame ảnh bất kỳ, dùng ĐÚNG layout (NCHW/NHWC) đã tự dò được
     * từ chính model — không hardcode kiến trúc của bất kỳ model cụ thể nào.
     *
     * [SỬA 12/10/2026] Nếu model có chiều ảnh CỐ ĐỊNH (H và W đều > 0 trong shape đầu vào) thì khung hình được CHIA Ô đúng cỡ đó
     * (xem [TiledUpscale]) rồi ghép lại, thay vì đưa nguyên khung hình vào (sẽ sai shape). Model chiều ảnh động: giữ NGUYÊN
     * đường chạy cũ (cả khung hình 1 lần). 🔴 Đường chia ô CHƯA chạy trên máy thật; phần chia/ghép đã kiểm số học riêng.
     */
    suspend fun upscaleFrame(bitmap: android.graphics.Bitmap, layout: TensorLayout): android.graphics.Bitmap? =
        withContext(Dispatchers.Default) {
            lastError = null
            try {
                loadSessionIfNeeded()
                val currentSession = session ?: run {
                    lastError = "Session chưa khởi tạo"
                    return@withContext null
                }
                val inputName = currentSession.inputNames.first()

                val fixedTile = fixedSpatialSize(currentSession, inputName, layout)
                if (fixedTile != null) {
                    return@withContext upscaleTiled(
                        currentSession, inputName, bitmap, layout,
                        tileH = fixedTile.first, tileW = fixedTile.second,
                        isCancelled = { !isActive }
                    )
                }

                val inputTensor = ImageTensorUtils.bitmapToTensor(ortEnv, bitmap, layout)
                val results = currentSession.run(mapOf(inputName to inputTensor))
                inputTensor.close()

                val outputInfo = results[0].info as? ai.onnxruntime.TensorInfo
                val outShape = outputInfo?.shape
                @Suppress("UNCHECKED_CAST")
                val rawOutput = results[0].value

                val outHeight = (if (layout == TensorLayout.NCHW) outShape?.getOrNull(2) else outShape?.getOrNull(1))?.toInt() ?: run {
                    lastError = "Không đọc được chiều cao đầu ra của model"
                    return@withContext null
                }
                val outWidth = (if (layout == TensorLayout.NCHW) outShape?.getOrNull(3) else outShape?.getOrNull(2))?.toInt() ?: run {
                    lastError = "Không đọc được chiều rộng đầu ra của model"
                    return@withContext null
                }

                val flatArray = flattenOnnxOutput(rawOutput)
                results.close()

                if (flatArray == null) {
                    lastError = "Không đọc được dữ liệu số thực từ đầu ra của model"
                    return@withContext null
                }
                ImageTensorUtils.tensorToBitmap(flatArray, outWidth, outHeight, layout)
            } catch (e: CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                lastError = "Hết bộ nhớ khi xử lý khung hình ${bitmap.width}x${bitmap.height} — ảnh đầu ra quá lớn so với RAM máy."
                null
            } catch (e: Exception) {
                lastError = "${e.javaClass.simpleName}: ${e.message}"
                null
            }
        }

    /** (H, W) cố định của đầu vào model theo [layout], hoặc null nếu 1 trong 2 chiều ảnh là động / không phải tensor 4 chiều. */
    private fun fixedSpatialSize(s: OrtSession, inputName: String, layout: TensorLayout): Pair<Int, Int>? {
        val shape = (s.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo)?.shape ?: return null
        if (shape.size != 4) return null
        val h = shape[if (layout == TensorLayout.NCHW) 2 else 1]
        val w = shape[if (layout == TensorLayout.NCHW) 3 else 2]
        return if (h > 0 && w > 0) Pair(h.toInt(), w.toInt()) else null
    }

    /** Upscale 1 khung hình bằng cách chia ô đúng cỡ đầu vào cố định của model rồi ghép lõi các ô — xem [TiledUpscale]. */
    private fun upscaleTiled(
        s: OrtSession, inputName: String, bitmap: android.graphics.Bitmap, layout: TensorLayout,
        tileH: Int, tileW: Int, isCancelled: () -> Boolean
    ): android.graphics.Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val src = IntArray(w * h)
        bitmap.getPixels(src, 0, w, 0, 0, w, h)
        val pad = TiledUpscale.effectivePad(tileW, tileH)

        var out: android.graphics.Bitmap? = null
        val sink = object : TiledUpscale.Sink {
            override fun begin(outWidth: Int, outHeight: Int) {
                out = android.graphics.Bitmap.createBitmap(outWidth, outHeight, android.graphics.Bitmap.Config.ARGB_8888)
            }
            override fun write(x: Int, y: Int, width: Int, height: Int, pixels: IntArray) {
                out!!.setPixels(pixels, 0, width, x, y, width, height)
            }
        }
        try {
            TiledUpscale.run(
                src, w, h, tileW, tileH, pad,
                { tilePixels -> runOneTile(s, inputName, tilePixels, tileW, tileH, layout) },
                sink, isCancelled
            )
        } catch (e: Throwable) {
            out?.recycle()
            throw e
        }
        return out ?: throw IllegalStateException("Không có ô nào được xử lý")
    }

    /** Chạy model cho đúng 1 ô [tileW]x[tileH] (điểm ảnh ARGB) và trả kết quả đã phóng. */
    private fun runOneTile(
        s: OrtSession, inputName: String, tilePixels: IntArray, tileW: Int, tileH: Int, layout: TensorLayout
    ): TiledUpscale.TileResult {
        val inputTensor = ImageTensorUtils.pixelsToTensor(ortEnv, tilePixels, tileW, tileH, layout)
        try {
            val results = s.run(mapOf(inputName to inputTensor))
            try {
                val outTensor = results[0] as? OnnxTensor
                    ?: throw IllegalStateException("Đầu ra đầu tiên của model không phải tensor")
                val outShape = (outTensor.info as? ai.onnxruntime.TensorInfo)?.shape
                    ?: throw IllegalStateException("Không đọc được shape đầu ra")
                if (outShape.size != 4) throw IllegalStateException("Đầu ra có ${outShape.size} chiều, cần 4 chiều (ảnh)")
                val channels = outShape[if (layout == TensorLayout.NCHW) 1 else 3]
                if (channels != 3L) throw IllegalStateException("Đầu ra có $channels kênh, cần 3 (RGB)")
                val outH = outShape[if (layout == TensorLayout.NCHW) 2 else 1].toInt()
                val outW = outShape[if (layout == TensorLayout.NCHW) 3 else 2].toInt()
                val fb = outTensor.floatBuffer
                    ?: throw IllegalStateException("Đầu ra không phải số thực (float/fp16/bf16) nên không đọc được")
                val floats = FloatArray(fb.remaining())
                fb.get(floats)
                if (floats.size != 3 * outW * outH) {
                    throw IllegalStateException("Đầu ra có ${floats.size} số, không khớp 3x${outW}x$outH (batch > 1?)")
                }
                return TiledUpscale.TileResult(ImageTensorUtils.tensorToPixels(floats, outW, outH, layout), outW, outH)
            } finally {
                results.close()
            }
        } finally {
            inputTensor.close()
        }
    }

    /** ONNX Runtime trả output dạng mảng lồng nhau (float[][][][]) — làm phẳng thành FloatArray 1 chiều. */
    private fun flattenOnnxOutput(value: Any?): FloatArray? {
        val result = mutableListOf<Float>()
        fun recurse(v: Any?) {
            when (v) {
                is FloatArray -> v.forEach { result.add(it) }
                is Array<*> -> v.forEach { recurse(it) }
                else -> {}
            }
        }
        recurse(value)
        return if (result.isEmpty()) null else result.toFloatArray()
    }

    /**
     * Chạy inference thô cho model detection, trả về (mảng số phẳng, shape output).
     * Việc giải mã (decode YOLO-style, NMS...) làm ở lớp ngoài (DetectionUtils) để
     * LocalModelProvider chỉ lo phần "chạy model", không gắn cứng logic của 1 họ
     * model detection cụ thể nào vào đây.
     *
     * Giả định input vuông (WxW) theo đúng chuẩn phổ biến của model YOLO-style
     * (thường 640x640). Đọc kích thước thật từ chính model, không hardcode.
     */
    suspend fun runRawDetection(bitmap: android.graphics.Bitmap): Pair<FloatArray, LongArray>? =
        withContext(Dispatchers.Default) {
            try {
                loadSessionIfNeeded()
                val currentSession = session ?: return@withContext null
                val inputName = currentSession.inputNames.first()
                val inputInfo = currentSession.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo
                    ?: return@withContext null
                val shape = inputInfo.shape // vd [1,3,640,640]

                val isNCHW = shape.size == 4 && shape[1] == 3L
                val inputSize = (if (isNCHW) shape.getOrNull(2) else shape.getOrNull(1))?.toInt()?.takeIf { it > 0 } ?: 640

                val resized = android.graphics.Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
                val layout = if (isNCHW) TensorLayout.NCHW else TensorLayout.NHWC
                val inputTensor = ImageTensorUtils.bitmapToTensor(ortEnv, resized, layout)
                if (resized != bitmap) resized.recycle()

                val results = currentSession.run(mapOf(inputName to inputTensor))
                inputTensor.close()

                val outputInfo = results[0].info as? ai.onnxruntime.TensorInfo ?: return@withContext null
                val outShape = outputInfo.shape
                val flat = flattenOnnxOutput(results[0].value)
                results.close()

                if (flat == null) null else flat to outShape
            } catch (e: Exception) {
                null
            }
        }

    /**
     * [THÊM 11/10/2026] Trích vector đặc trưng (embedding) của 1 ảnh crop bằng model Re-ID/
     * embedding bất kỳ do người dùng nạp (TaskType.OBJECT_REID). Trả về vector đã L2-normalize
     * (để so khớp bằng tích vô hướng = cosine similarity), hoặc null nếu model không chạy
     * được / không đúng dạng hỗ trợ.
     *
     * KHÔNG hardcode model cụ thể — mọi thông số đọc từ chính model:
     * - Bố cục: NCHW nếu shape[1]==3, NHWC nếu shape[3]==3; dạng khác -> trả null (không đoán bừa).
     * - Kích thước H×W: lấy từ shape của model; nếu chiều đó là động (<=0) thì dùng
     *   EMBEDDING_FALLBACK_SIZE (224) — số đoán, chỉ dùng khi model không nói rõ.
     * - Resize KÉO GIÃN thẳng về H×W (không letterbox) — cách các model Re-ID thường được train.
     * - Quy ước chuẩn hoá pixel: theo `config.inputNormalization` do người dùng chọn.
     * - Output: lấy output đầu tiên, làm phẳng toàn bộ thành 1 vector (vd [1,512] -> 512 số).
     *
     * 🔴 CHƯA TEST VỚI MODEL RE-ID THẬT trên máy.
     */
    suspend fun runEmbedding(bitmap: android.graphics.Bitmap): FloatArray? =
        withContext(Dispatchers.Default) {
            var resized: android.graphics.Bitmap? = null
            var inputTensor: OnnxTensor? = null
            try {
                loadSessionIfNeeded()
                val currentSession = session ?: return@withContext null
                val inputName = currentSession.inputNames.first()
                val inputInfo = currentSession.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo
                    ?: return@withContext null
                val shape = inputInfo.shape
                if (shape.size != 4) return@withContext null

                val isNCHW = shape[1] == 3L
                val isNHWC = shape[3] == 3L
                if (!isNCHW && !isNHWC) return@withContext null
                val layout = if (isNCHW) TensorLayout.NCHW else TensorLayout.NHWC

                val targetH = (if (isNCHW) shape[2] else shape[1]).toInt().takeIf { it > 0 } ?: EMBEDDING_FALLBACK_SIZE
                val targetW = (if (isNCHW) shape[3] else shape[2]).toInt().takeIf { it > 0 } ?: EMBEDDING_FALLBACK_SIZE

                val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
                resized = scaled
                val tensor = ImageTensorUtils.bitmapToTensor(ortEnv, scaled, layout, config.inputNormalization)
                inputTensor = tensor

                val results = currentSession.run(mapOf(inputName to tensor))
                val flat = try {
                    flattenOnnxOutput(results[0].value)
                } finally {
                    results.close()
                }
                if (flat == null || flat.size < 2) return@withContext null

                var sumSq = 0.0
                for (v in flat) sumSq += v.toDouble() * v.toDouble()
                val norm = Math.sqrt(sumSq)
                if (!(norm > 1e-12)) return@withContext null // chặn cả norm=0 lẫn NaN
                FloatArray(flat.size) { (flat[it] / norm).toFloat() }
            } catch (e: Exception) {
                null
            } finally {
                inputTensor?.close()
                resized?.let { if (it !== bitmap) it.recycle() }
            }
        }

    /** Kích thước input vuông thật của model (để lớp ngoài biết cách scale toạ độ box về ảnh gốc). */
    suspend fun getSquareInputSize(): Int = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()
            val currentSession = session ?: return@withContext 640
            val inputName = currentSession.inputNames.first()
            val inputInfo = currentSession.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo ?: return@withContext 640
            val shape = inputInfo.shape
            val isNCHW = shape.size == 4 && shape[1] == 3L
            (if (isNCHW) shape.getOrNull(2) else shape.getOrNull(1))?.toInt()?.takeIf { it > 0 } ?: 640
        } catch (e: Exception) {
            640
        }
    }

    override suspend fun isReady(): Boolean = withContext(Dispatchers.IO) {
        try {
            loadSessionIfNeeded()
            true
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun runInference(input: InferenceInput): InferenceOutput = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()

            // TODO (bước tiếp theo - riêng theo từng TaskType):
            // Mỗi tác vụ (upscale / detect / segment) có tiền xử lý (resize, normalize)
            // và hậu xử lý (decode bounding box, ghép ảnh...) khác nhau.
            // Đây là chỗ sẽ cắm logic cụ thể cho từng loại model.

            InferenceOutput(
                success = false,
                errorMessage = "Chưa cài đặt logic xử lý cho tác vụ ${input.taskType} (sẽ bổ sung ở các bước tiếp theo)."
            )
        } catch (e: Exception) {
            InferenceOutput(success = false, errorMessage = e.message)
        }
    }

    override fun release() {
        session?.close()
        session = null
    }

    private companion object {
        /** Kích thước dự phòng cho chiều ảnh động (<=0) trong runEmbedding — số đoán, xem chú thích hàm đó. */
        const val EMBEDDING_FALLBACK_SIZE = 224
        /** Kích thước H/W giả cho chiều ảnh động khi đo thời gian chạy thử (measureInferenceNote) — số đoán. */
        const val TIMING_DYNAMIC_SPATIAL_SIZE = 256L
        /** Trần số phần tử 1 tensor đầu vào giả (~64 MB float) để chạy thử không làm hết RAM. */
        const val TIMING_MAX_ELEMENTS = 16_000_000L
    }
}
