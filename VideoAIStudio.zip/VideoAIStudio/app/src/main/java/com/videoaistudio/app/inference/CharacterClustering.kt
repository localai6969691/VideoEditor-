package com.videoaistudio.app.inference

import java.io.File
import java.util.BitSet
import kotlin.math.sqrt

/**
 * [THÊM 11/10/2026] Phần THUẬT TOÁN THUẦN (không phụ thuộc Android/ONNX) của tính năng "phân
 * loại nhân vật + giữ N ảnh tốt nhất mỗi nhân vật" — tách riêng khỏi ObjectExtractActivity
 * để có thể biên dịch + chạy thử độc lập bằng Kotlin thường (không cần Android SDK).
 *
 * Luồng: tracker IoU cho ra nhiều "track" (đoạn xuất hiện liên tục của 1 object) -> mỗi track
 * có 1 vector đặc trưng trung bình (từ model Re-ID) -> gom các track có vector GIỐNG NHAU
 * thành cùng 1 NHÂN VẬT (CharacterClustering.cluster) -> trong mỗi nhân vật chọn N ảnh có
 * điểm chất lượng cao nhất (CropQuality.score).
 */

/** 1 ảnh crop ứng viên của 1 track tại 1 frame mẫu. `embedding` đã L2-normalize, hoặc null. */
class CropCandidate(
    val trackId: Int,
    val frameIdx: Int,
    val classId: Int,
    val confidence: Float,
    val width: Int,
    val height: Int,
    val sharpness: Double,
    val quality: Double,
    val file: File,
    val embedding: FloatArray?
)

/**
 * Tóm tắt 1 track để gom nhóm.
 * - `frames`: TẤT CẢ chỉ số frame mẫu mà track này xuất hiện (kể cả frame crop bị loại vì
 *   mờ) — dùng cho ràng buộc "2 track cùng xuất hiện trong 1 frame thì KHÔNG THỂ là cùng 1
 *   nhân vật".
 * - `embedding`: vector trung bình đã L2-normalize, null nếu track không có vector nào.
 */
class TrackSummary(
    val trackId: Int,
    val classId: Int,
    val frames: BitSet,
    val embedding: FloatArray?
)

object CropQuality {
    /**
     * Điểm chất lượng 1 ảnh crop = độ nét × √(diện tích crop) × độ tin cậy của detection.
     * - độ nét: phương sai Laplacian (ImageSharpness.computeScore) — ảnh nét hơn điểm cao hơn.
     * - √(diện tích): ưu tiên crop lớn (nhiều chi tiết hơn) nhưng tăng tuyến tính theo
     *   cạnh chứ không theo diện tích để crop to-mờ không lấn át crop vừa-nét.
     * - độ tin cậy: ưu tiên detection chắc chắn đúng loại object.
     *
     * 🔴 Công thức này là HEURISTIC tự đặt, CHƯA hiệu chỉnh bằng dữ liệu thật — chỉ dùng để
     * XẾP HẠNG tương đối các ảnh của cùng 1 nhân vật, con số tuyệt đối không có ý nghĩa.
     */
    fun score(sharpness: Double, width: Int, height: Int, confidence: Float): Double =
        sharpness * sqrt(width.toDouble() * height.toDouble()) * confidence
}

object CharacterClustering {

    /** L2-normalize; trả null nếu vector toàn 0 hoặc chứa NaN/Infinity. */
    fun l2Normalize(v: FloatArray): FloatArray? {
        var sumSq = 0.0
        for (x in v) sumSq += x.toDouble() * x.toDouble()
        val norm = sqrt(sumSq)
        if (!(norm > 1e-12) || norm.isInfinite()) return null
        return FloatArray(v.size) { (v[it] / norm).toFloat() }
    }

    /** Trung bình các vector (cùng chiều) rồi L2-normalize lại. Bỏ qua vector lệch chiều. */
    fun meanEmbedding(embeddings: List<FloatArray>): FloatArray? {
        if (embeddings.isEmpty()) return null
        val dim = embeddings.first().size
        val sum = FloatArray(dim)
        var used = 0
        for (e in embeddings) {
            if (e.size != dim) continue
            for (i in 0 until dim) sum[i] += e[i]
            used++
        }
        if (used == 0) return null
        return l2Normalize(sum)
    }

    private fun dot(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size)
        var s = 0f
        for (i in 0 until n) s += a[i] * b[i]
        return s
    }

    /**
     * Gom các track thành "nhân vật" bằng agglomerative clustering, liên kết TRUNG BÌNH
     * (average linkage / UPGMA) theo cosine similarity — 2 cụm chỉ được gộp khi độ giống
     * trung bình >= `similarityThreshold`.
     *
     * Ràng buộc cứng (không phụ thuộc model, không có ngưỡng):
     * - Chỉ gộp track CÙNG classId (người không gộp với chó).
     * - KHÔNG gộp 2 cụm nếu có frame mẫu nào cả 2 cùng xuất hiện (2 người khác nhau đứng
     *   cạnh nhau trong cùng 1 frame không bao giờ bị nhập làm 1, dù vector gần giống).
     *
     * Track KHÔNG có embedding (model không chạy được trên mọi crop của nó, hoặc người dùng
     * không dùng Re-ID) không so sánh được -> mỗi track tự thành 1 nhân vật riêng.
     *
     * Độ phức tạp ~O(n²) bộ nhớ và ~O(n²)–O(n³) thời gian với n = số track có embedding
     * (dùng bộ nhớ đệm "đối tác tốt nhất" mỗi hàng để tránh quét lại toàn bộ sau mỗi lần gộp).
     *
     * @return danh sách các nhân vật, mỗi nhân vật là danh sách trackId thành viên.
     */
    fun cluster(tracks: List<TrackSummary>, similarityThreshold: Float): List<List<Int>> {
        val result = mutableListOf<List<Int>>()
        tracks.filter { it.embedding == null }.forEach { result.add(listOf(it.trackId)) }

        val withEmb = tracks.filter { it.embedding != null }
        val n = withEmb.size
        if (n == 0) return result

        val sim = Array(n) { FloatArray(n) }
        for (i in 0 until n) {
            val ei = withEmb[i].embedding!!
            for (j in i + 1 until n) {
                val s = dot(ei, withEmb[j].embedding!!)
                sim[i][j] = s
                sim[j][i] = s
            }
        }

        val members = Array(n) { mutableListOf(withEmb[it].trackId) }
        val frames = Array(n) { withEmb[it].frames.clone() as BitSet }
        val classIds = IntArray(n) { withEmb[it].classId }
        val size = IntArray(n) { 1 }
        val active = BooleanArray(n) { true }
        val bestJ = IntArray(n) { -1 }
        val bestS = FloatArray(n) { Float.NEGATIVE_INFINITY }

        fun canMerge(i: Int, j: Int): Boolean =
            i != j && active[j] && classIds[i] == classIds[j] && !frames[i].intersects(frames[j])

        fun recomputeBest(i: Int) {
            var bj = -1
            var bs = Float.NEGATIVE_INFINITY
            for (j in 0 until n) {
                if (!canMerge(i, j)) continue
                if (sim[i][j] > bs) {
                    bs = sim[i][j]
                    bj = j
                }
            }
            bestJ[i] = bj
            bestS[i] = bs
        }

        for (i in 0 until n) recomputeBest(i)

        while (true) {
            var a = -1
            for (i in 0 until n) {
                if (!active[i] || bestJ[i] < 0 || bestS[i] < similarityThreshold) continue
                if (a < 0 || bestS[i] > bestS[a]) a = i
            }
            if (a < 0) break
            val b = bestJ[a]

            // Gộp b vào a, cập nhật độ giống theo công thức average linkage (trọng số = số track mỗi cụm)
            val sa = size[a]
            val sb = size[b]
            for (k in 0 until n) {
                if (!active[k] || k == a || k == b) continue
                val s = (sa * sim[a][k] + sb * sim[b][k]) / (sa + sb)
                sim[a][k] = s
                sim[k][a] = s
            }
            members[a].addAll(members[b])
            frames[a].or(frames[b])
            size[a] = sa + sb
            active[b] = false

            // Chỉ các hàng có "đối tác tốt nhất" là a hoặc b mới cần tính lại: với average
            // linkage, cụm gộp không bao giờ giống hàng k hơn max(giống(k,a), giống(k,b)),
            // và nó chỉ còn gộp được với k khi CẢ a lẫn b đều gộp được với k.
            recomputeBest(a)
            for (k in 0 until n) {
                if (!active[k] || k == a) continue
                if (bestJ[k] == a || bestJ[k] == b) recomputeBest(k)
            }
        }

        for (i in 0 until n) {
            if (active[i]) result.add(members[i])
        }
        return result
    }

    /** Chọn tối đa `n` ứng viên có điểm chất lượng cao nhất (điểm bằng nhau: frame sớm hơn trước). */
    fun selectTopN(candidates: List<CropCandidate>, n: Int): List<CropCandidate> =
        candidates.sortedWith(compareByDescending<CropCandidate> { it.quality }.thenBy { it.frameIdx }).take(n)
}
