package com.videoaistudio.app.inference

import android.graphics.Bitmap
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import java.nio.FloatBuffer

/**
 * Chuyển đổi Bitmap <-> Tensor theo ĐÚNG QUY ƯỚC CHUNG mà đại đa số model
 * super-resolution ONNX (ESRGAN, Real-ESRGAN, SRCNN và các biến thể) sử dụng:
 * - Giá trị pixel chuẩn hoá về [0,1] (chia 255), không phải [0,255] hay [-1,1].
 * - Thứ tự kênh màu RGB (không phải BGR).
 *
 * Đây KHÔNG phải hardcode riêng cho 1 model — đây là quy ước phổ biến nhất của
 * CẢ THỂ LOẠI model upscale ảnh, áp dụng chung cho mọi model theo layout mà
 * detectUpscaleModelSpec() đã tự dò được (NCHW hoặc NHWC).
 *
 * Giới hạn thành thật: một số ít model dùng quy ước khác ([-1,1] hoặc [0,255]).
 * Nếu ảnh ra bị sai màu/quá sáng/quá tối, đó là dấu hiệu model thuộc nhóm thiểu số
 * này — cần bổ sung tuỳ chọn normalization khác ở bản sau, không phải lỗi code.
 */
object ImageTensorUtils {

    /**
     * [SỬA 11/10/2026] Thêm tham số `normalization` (mặc định ZERO_ONE = ĐÚNG hành vi cũ, nên
     * Upscale/Detection gọi hàm này không đổi gì cũng không bị ảnh hưởng). Chỉ OBJECT_REID
     * truyền giá trị khác — xem InputNormalization.
     */
    fun bitmapToTensor(
        env: OrtEnvironment,
        bitmap: Bitmap,
        layout: TensorLayout,
        normalization: InputNormalization = InputNormalization.ZERO_ONE
    ): OnnxTensor {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        return pixelsToTensor(env, pixels, width, height, layout, normalization)
    }

    /**
     * [THÊM 12/10/2026] Như [bitmapToTensor] nhưng nhận THẲNG mảng điểm ảnh ARGB (width*height) — để chia ô (TiledUpscale)
     * không phải tạo Bitmap trung gian cho từng ô. [bitmapToTensor] gọi lại hàm này nên số học y hệt như trước.
     */
    fun pixelsToTensor(
        env: OrtEnvironment,
        pixels: IntArray,
        width: Int,
        height: Int,
        layout: TensorLayout,
        normalization: InputNormalization = InputNormalization.ZERO_ONE
    ): OnnxTensor {
        require(pixels.size == width * height) { "pixels.size=${pixels.size} không khớp ${width}x$height" }

        val floatArray = FloatArray(3 * width * height)

        // Giá trị cuối = (pixel/255 - mean[kênh]) / std[kênh]; ZERO_ONE: mean=0, std=1 -> chỉ còn pixel/255 như cũ.
        // (dùng `when` dạng BIỂU THỨC — bắt buộc phủ đủ mọi giá trị enum, tránh lỗi biên dịch "biến chưa gán")
        val (mean, std) = when (normalization) {
            InputNormalization.ZERO_ONE ->
                floatArrayOf(0f, 0f, 0f) to floatArrayOf(1f, 1f, 1f)
            InputNormalization.IMAGENET_MEAN_STD ->
                floatArrayOf(0.485f, 0.456f, 0.406f) to floatArrayOf(0.229f, 0.224f, 0.225f)
            InputNormalization.MINUS_ONE_ONE ->
                floatArrayOf(0.5f, 0.5f, 0.5f) to floatArrayOf(0.5f, 0.5f, 0.5f)
        }

        if (layout == TensorLayout.NCHW) {
            // [1,3,H,W]: từng kênh liền mạch nhau
            val channelSize = width * height
            for (i in pixels.indices) {
                val p = pixels[i]
                floatArray[i] = (((p shr 16) and 0xFF) / 255f - mean[0]) / std[0]                  // R
                floatArray[channelSize + i] = (((p shr 8) and 0xFF) / 255f - mean[1]) / std[1]     // G
                floatArray[2 * channelSize + i] = ((p and 0xFF) / 255f - mean[2]) / std[2]         // B
            }
        } else {
            // [1,H,W,3]: xen kẽ R,G,B liên tiếp theo từng pixel
            for (i in pixels.indices) {
                val p = pixels[i]
                floatArray[i * 3] = (((p shr 16) and 0xFF) / 255f - mean[0]) / std[0]
                floatArray[i * 3 + 1] = (((p shr 8) and 0xFF) / 255f - mean[1]) / std[1]
                floatArray[i * 3 + 2] = ((p and 0xFF) / 255f - mean[2]) / std[2]
            }
        }

        val shape = if (layout == TensorLayout.NCHW) {
            longArrayOf(1, 3, height.toLong(), width.toLong())
        } else {
            longArrayOf(1, height.toLong(), width.toLong(), 3)
        }

        return OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArray), shape)
    }

    fun tensorToBitmap(floatArray: FloatArray, width: Int, height: Int, layout: TensorLayout): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = tensorToPixels(floatArray, width, height, layout)
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return bitmap
    }

    /**
     * [THÊM 12/10/2026] Tách phần đổi số thực -> điểm ảnh ARGB ra khỏi [tensorToBitmap] (cùng công thức: kẹp [0,1] rồi ×255,
     * cắt phần thập phân) để TiledUpscale dùng cho từng ô mà không cần Bitmap.
     */
    fun tensorToPixels(floatArray: FloatArray, width: Int, height: Int, layout: TensorLayout): IntArray {
        require(floatArray.size >= 3 * width * height) { "Tensor có ${floatArray.size} số, cần ${3 * width * height} cho ${width}x$height" }
        val pixels = IntArray(width * height)
        val channelSize = width * height

        for (i in 0 until width * height) {
            val r: Float
            val g: Float
            val b: Float
            if (layout == TensorLayout.NCHW) {
                r = floatArray[i]
                g = floatArray[channelSize + i]
                b = floatArray[2 * channelSize + i]
            } else {
                r = floatArray[i * 3]
                g = floatArray[i * 3 + 1]
                b = floatArray[i * 3 + 2]
            }
            val ri = (r.coerceIn(0f, 1f) * 255).toInt()
            val gi = (g.coerceIn(0f, 1f) * 255).toInt()
            val bi = (b.coerceIn(0f, 1f) * 255).toInt()
            pixels[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
        }
        return pixels
    }
}
