package com.videoaistudio.app.video

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * [THÊM 16/11/2026] Ném khi ổ đĩa không đủ chỗ cho bản copy video — thay vì copy vài GB rồi để hệ
 * thống dọn mất / ghi dở (xem PROJECT_SPEC.md mục 6, 16/11/2026).
 */
class InsufficientStorageException(val requiredBytes: Long, val availableBytes: Long) :
    IOException(
        "Không đủ dung lượng trống để sao chép video: cần khoảng ${SafeCopy.formatGb(requiredBytes)} " +
            "(đã gồm phần đệm an toàn), máy chỉ còn ${SafeCopy.formatGb(availableBytes)}. Hãy giải phóng bộ nhớ rồi chọn lại."
    )

/**
 * [THÊM 16/11/2026] Phần LOGIC THUẦN (không phụ thuộc Android — chạy/kiểm được bằng kotlinc thường) của việc
 * copy video vào bộ nhớ làm việc của app. Tách riêng khỏi [FileUtils] (cần Context/Uri) để có test thật.
 *
 * Giải quyết 2 lỗi thật thấy trong log người dùng gửi 16/11/2026 (chi tiết: PROJECT_SPEC.md mục 6):
 *  (1) Copy xong báo "0 byte" (file không còn ở đường dẫn đích dù copy 3.69GB vừa chạy xong) — nguyên nhân
 *      khả dĩ trong code: nút "Chọn video" gọi clearVideoInputCache() (đổi tên thư mục + xoá nền) đúng lúc
 *      lần copy trước còn đang ghi. => [isCopying] cho phép chặn việc xoá khi có copy đang chạy, và [copyStream]
 *      KIỂM LẠI file đích sau khi ghi xong (không còn / sai kích thước => ném lỗi rõ ràng thay vì để lọt).
 *  (2) File biến mất ~55 giây sau khi copy xong (ENOENT) dù app không gọi xoá — chưa chứng minh được nguyên
 *      nhân. => [describeState] ghi trạng thái ổ đĩa/thư mục vào log để lần sau có bằng chứng, và [checkFreeSpace]
 *      từ chối copy khi sắp hết chỗ (một khả năng: hệ thống dọn bộ nhớ đệm khi máy thiếu dung lượng).
 */
object SafeCopy {
    /**
     * Phần đệm giữ lại khi kiểm tra dung lượng trống: phải còn ít nhất (kích thước file + đệm) mới cho copy.
     * 512MB là CON SỐ HEURISTIC của người viết (để máy không rơi vào trạng thái "sắp đầy" ngay sau khi copy),
     * KHÔNG phải ngưỡng chính thức nào của Android.
     */
    const val FREE_SPACE_MARGIN_BYTES: Long = 512L * 1024 * 1024

    private val activeCopies = AtomicInteger(0)

    /** true nếu đang có ít nhất 1 lần copy video chạy — việc xoá thư mục video_input PHẢI bỏ qua lúc này. */
    fun isCopying(): Boolean = activeCopies.get() > 0

    /** Đánh dấu "đang copy" trong suốt [block] (kể cả khi ném lỗi). */
    fun <T> tracking(block: () -> T): T {
        activeCopies.incrementAndGet()
        try {
            return block()
        } finally {
            activeCopies.decrementAndGet()
        }
    }

    /**
     * Ném [InsufficientStorageException] nếu ổ chứa [dir] còn trống < [expectedSize] + [marginBytes].
     * [expectedSize] <= 0 (không biết kích thước) => không kiểm. [dir] được tạo nếu chưa có (thư mục không
     * tồn tại thì usableSpace luôn trả 0 — sẽ báo thiếu chỗ oan).
     */
    fun checkFreeSpace(dir: File, expectedSize: Long, marginBytes: Long = FREE_SPACE_MARGIN_BYTES) {
        if (expectedSize <= 0L) return
        dir.mkdirs()
        val available = dir.usableSpace
        val required = expectedSize + marginBytes
        if (available < required) throw InsufficientStorageException(required, available)
    }

    /**
     * Copy [input] -> [dest] theo khối 1MB, báo tiến độ (tổng byte đã ghi), kiểm huỷ mỗi khối. Trả tổng byte đã ghi.
     * SAU KHI ghi xong KIỂM LẠI: file đích còn tồn tại và đúng bằng số byte đã ghi, và không rỗng — nếu không
     * thì ném [IOException] (file bị xoá/đổi tên/cắt cụt giữa lúc copy). Mọi lỗi => xoá file đích dở dang.
     */
    fun copyStream(
        input: InputStream,
        dest: File,
        onProgress: ((Long) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): Long {
        var total = 0L
        try {
            dest.outputStream().use { output ->
                val buffer = ByteArray(1 shl 20)
                while (true) {
                    if (isCancelled()) throw java.util.concurrent.CancellationException("Đã huỷ sao chép")
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                    total += n
                    onProgress?.invoke(total)
                }
            }
            if (total <= 0L) throw IOException("Đọc được 0 byte từ file nguồn (file rỗng hoặc không đọc được).")
            if (!dest.exists() || dest.length() != total) {
                throw IOException(
                    "File sao chép không còn nguyên vẹn sau khi ghi xong: đã ghi $total byte nhưng file đích " +
                        "${if (dest.exists()) "chỉ có ${dest.length()} byte" else "không còn tồn tại"} " +
                        "(bị xoá/đổi tên giữa chừng?)."
                )
            }
        } catch (e: Exception) {
            dest.delete() // không để lại file dở dang
            throw e
        }
        return total
    }

    /**
     * Mô tả trạng thái thư mục làm việc để ghi vào log khi gặp lỗi mất file: file đích còn không, thư mục còn
     * không, liệt kê vài mục bên trong, các thư mục cùng gốc có tiền tố [dir].name (vd `video_input_trash_*` =>
     * chính app đã đổi tên để xoá), dung lượng trống/tổng của ổ chứa nó.
     */
    fun describeState(dir: File, target: File? = null): String {
        val sb = StringBuilder()
        if (target != null) {
            sb.append("file: exists=${target.exists()}, length=${target.length()}; ")
        }
        sb.append("thư mục ${dir.name}: exists=${dir.exists()}")
        val items = dir.listFiles()
        if (items != null) {
            sb.append(", ${items.size} mục")
            if (items.isNotEmpty()) {
                sb.append(" [")
                sb.append(items.take(6).joinToString(", ") { "${it.name.take(32)}=${if (it.isFile) it.length().toString() + "B" else "thư mục"}" })
                if (items.size > 6) sb.append(", …")
                sb.append("]")
            }
        }
        val parent = dir.parentFile
        if (parent != null) {
            val related = parent.list()?.filter { it.startsWith(dir.name) && it != dir.name }
            if (!related.isNullOrEmpty()) sb.append("; thư mục cùng gốc tiền tố '${dir.name}': ${related.take(5)}")
            sb.append("; ổ đĩa: trống ${formatGb(parent.usableSpace)} / tổng ${formatGb(parent.totalSpace)}")
        }
        return sb.toString()
    }

    fun formatGb(bytes: Long): String = String.format(Locale.US, "%.2fGB", bytes / (1024.0 * 1024.0 * 1024.0))
}
