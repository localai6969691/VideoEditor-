package com.videoaistudio.app.video

import java.util.Locale

/**
 * [THÊM 16/11/2026] Dòng chữ cho người dùng biết ĐIỂM CẮT THẬT khác điểm họ đã chọn bao nhiêu.
 *
 * TẠI SAO: cắt nhanh `-c copy` chỉ có thể bắt đầu ở KHUNG KHOÁ (xem FileUtils.findPrecedingKeyframeSec). Trước đây
 * các nút tua ±1/5/15s tự "nhích" thumb về khung khoá ngay khi bấm — với video khung khoá thưa (log thật: cách nhau
 * 5–8 giây) nút "-1s" nhảy cả 5–8 giây còn "+1s" đứng yên, và người dùng báo đúng điều đó. Giờ các nút tua đi ĐÚNG
 * bước (preview cũng đúng chỗ) và sự chênh lệch với điểm cắt thật được HIỆN RA bằng dòng chữ này — để không tái
 * phát lỗi 17/09/2026 ("file cắt lệch đằng trước vài giây mà người dùng không được báo trước").
 *
 * Logic thuần (không Android) để test bằng kotlinc thường.
 */
object CutPointHint {
    /** Chênh lệch nhỏ hơn mức này coi như TRÙNG khung khoá (đủ lớn hơn sai số Float của thanh trượt ~5e-4s). */
    const val SAME_TOLERANCE_SEC = 0.03

    /** "H:MM:SS.s" (1 chữ số thập phân), luôn dấu chấm (Locale.US). */
    fun formatTime(sec: Double): String {
        val s = if (sec < 0.0) 0.0 else sec
        val tenths = Math.round(s * 10.0)
        val whole = tenths / 10
        val frac = (tenths % 10).toInt()
        val h = whole / 3600
        val m = (whole % 3600) / 60
        val ss = whole % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d.%d", h, m, ss, frac)
        else String.format(Locale.US, "%d:%02d.%d", m, ss, frac)
    }

    /** [chosenSec] = điểm bắt đầu đang chọn; [keyframeSec] = khung khoá mà FFmpeg thật sự sẽ bắt đầu từ đó. */
    fun describe(chosenSec: Double, keyframeSec: Double): String {
        val diff = chosenSec - keyframeSec
        return when {
            Math.abs(diff) <= SAME_TOLERANCE_SEC ->
                "Điểm bắt đầu đang trùng khung khoá: file cắt sẽ bắt đầu đúng chỗ này."
            diff > 0.0 ->
                "Điểm cắt thật: ${formatTime(keyframeSec)} — SỚM hơn điểm bạn chọn ${String.format(Locale.US, "%.1f", diff)}s " +
                    "(cắt nhanh chỉ bắt đầu được tại khung khoá)."
            else ->
                "Điểm cắt thật: ${formatTime(keyframeSec)} — muộn hơn điểm bạn chọn ${String.format(Locale.US, "%.1f", -diff)}s " +
                    "(khung khoá ngay sau, trong dung sai làm tròn)."
        }
    }

    /**
     * [THÊM 17/11/2026] Dòng chữ khi bật "Cắt chính xác" (SmartCut): file sẽ bắt đầu ĐÚNG điểm chọn; khung khoá trước đó
     * chỉ là điểm quay về nếu cắt chính xác không làm được (xem SmartCut.decide + VideoEngine.cutSegmentExact).
     */
    fun describeExact(chosenSec: Double, keyframeSec: Double): String {
        val diff = chosenSec - keyframeSec
        return when {
            Math.abs(diff) <= SAME_TOLERANCE_SEC ->
                "Điểm bắt đầu đang trùng khung khoá: file cắt ra bắt đầu đúng chỗ này, cắt nhanh, giữ nguyên chất lượng."
            diff > 0.0 ->
                "Cắt chính xác: file bắt đầu ĐÚNG ${formatTime(chosenSec)}. App mã hoá lại vài giây đầu (tới khung khoá kế tiếp), " +
                    "phần còn lại giữ nguyên. Nếu video không hỗ trợ, sẽ quay về cắt nhanh tại khung khoá ${formatTime(keyframeSec)} " +
                    "(SỚM hơn ${String.format(Locale.US, "%.1f", diff)}s) và báo rõ lý do."
            else -> describe(chosenSec, keyframeSec)
        }
    }

    const val UNKNOWN = "Chưa xác định được điểm cắt thật (không đọc được khung khoá của file nguồn)."
}
