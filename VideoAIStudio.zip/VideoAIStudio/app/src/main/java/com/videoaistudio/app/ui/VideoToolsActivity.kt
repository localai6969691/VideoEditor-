package com.videoaistudio.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.DragEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import com.videoaistudio.app.databinding.ActivityVideoToolsBinding
import com.videoaistudio.app.debug.DebugLog
import com.videoaistudio.app.video.CompressService
import com.videoaistudio.app.video.CutPointHint
import com.videoaistudio.app.video.FileUtils
import com.videoaistudio.app.video.HardsubExtractor
import com.videoaistudio.app.video.InsufficientStorageException
import com.videoaistudio.app.video.SubtitleUtils
import com.videoaistudio.app.video.VideoEngine
import com.videoaistudio.app.video.VideoOpResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class VideoToolMode(val label: String) {
    TRIM_SPLIT("Cắt / Tách video"),
    REMOVE_MIDDLE("Xoá đoạn giữa, ghép phần còn lại"),
    MERGE("Ghép video"),
    EXTRACT_AUDIO("Tách âm thanh"),
    COMPRESS("Nén dung lượng"),
    EXTRACT_HARDSUB("Tách phụ đề từ video (OCR, thử nghiệm)"),
    CONVERT_TO_MP4("Convert sang MP4 (kể cả m3u8/HLS)");

    override fun toString(): String = label
}

/**
 * Màn hình gộp Trim/Cut + Split thành 1, cộng Merge/Extract Audio/Compress.
 * Trim/Split có preview video thật (Media3 ExoPlayer) + RangeSlider để chọn đoạn
 * trực quan, kèm ô nhập giờ:phút:giây cho video dài (dễ theo dõi hơn số giây thô).
 */
class VideoToolsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoToolsBinding
    private val selectedFilePaths = mutableListOf<String>()
    private var currentMode: VideoToolMode = VideoToolMode.TRIM_SPLIT
    private var player: ExoPlayer? = null
    private var videoDurationSec: Float = 100f

    // [DỜI TỪ BIẾN LOCAL TRONG loadPreview() LÊN THÀNH THUỘC TÍNH LỚP — 25/10/2026] để releasePlayer()
    // huỷ được chúng khi nạp video mới / đóng màn hình (trước đây job + listener của video CŨ vẫn sống).
    private var scrubController: ScrubSeekController? = null
    private var keyframeSnapJob: Job? = null
    private var trimTextWatcher: android.text.TextWatcher? = null

    // [THÊM 25/10/2026] Hàng đợi import video (copy vào cache chạy NỀN, tuần tự theo thứ tự chọn).
    private val importMutex = Mutex()
    private var pendingImports = 0
    private var runButtonDisabledByImport = false

    // [THÊM 16/11/2026] Tự khôi phục khi file video trong thư mục làm việc biến mất (ENOENT) — xem
    // recoverMissingInput(). Uri gốc đã chọn (để copy lại), thời điểm copy xong (để ghi log "mất sau bao lâu"),
    // số lần tự khôi phục do lỗi player (chặn vòng lặp copy-mất-copy), và job tính "điểm cắt thật".
    private val sourceUriByPath = HashMap<String, Uri>()
    private val copyFinishedAtMs = HashMap<String, Long>()
    private val autoRecoveries = HashMap<String, Int>()
    private var recovering = false
    private var realStartHintJob: Job? = null

    private val pickSingleVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importUri(it) }
    }

    private val pickMultipleVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.forEach { importUri(it) }
    }

    // [THÊM 06/09/2026] Ghép cứng phụ đề — xem giải thích đầy đủ ở
    // VideoEngine.trimWithBurnedSubtitles(). "*/*" vì Android không có MIME type chuẩn được
    // công nhận rộng rãi cho .srt/.ass/.vtt — dùng picker mở rộng, không lọc theo MIME, để
    // tránh trường hợp trình quản lý file lọc nhầm không cho chọn file phụ đề hợp lệ.
    private var selectedSubtitlePath: String? = null
    private val pickSubtitleFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val name = FileUtils.queryDisplayName(this, it)
                val file = FileUtils.copySubtitleToCache(this, it, name)
                selectedSubtitlePath = file.absolutePath
                binding.txtSelectedSubtitle.text = "Đã chọn: $name"
            } catch (e: Exception) {
                Toast.makeText(this, "Không đọc được file phụ đề: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * [THÊM tính năng Convert sang MP4, 16/09/2026] Riêng cho input m3u8/HLS — dùng
     * OpenDocumentTree (chọn THƯ MỤC) thay vì OpenDocument (chọn 1 file) như mọi định
     * dạng khác. Xem giải thích đầy đủ LÝ DO KỸ THUẬT bắt buộc phải làm vậy tại
     * `FileUtils.importM3u8FolderToCache()` — tóm tắt: file .m3u8 chỉ là danh sách tên
     * các đoạn .ts CÙNG THƯ MỤC, chọn thẳng 1 file .m3u8 qua trình chọn file đơn sẽ
     * KHÔNG cấp quyền đọc được các đoạn đó.
     */
    private val pickM3u8FolderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri: Uri? ->
        treeUri?.let { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val playlistFile = FileUtils.importM3u8FolderToCache(this, uri)
                if (playlistFile == null) {
                    Toast.makeText(this, "Không tìm thấy file .m3u8/.m3u nào trong thư mục đã chọn.", Toast.LENGTH_LONG).show()
                    return@let
                }
                selectedFilePaths.clear()
                selectedFilePaths.add(playlistFile.absolutePath)
                updateSelectedFilesText()
                Toast.makeText(this, "Đã nhập: ${playlistFile.name} (kèm các đoạn .ts cùng thư mục)", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Lỗi khi đọc thư mục m3u8: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private var lastSingleOutputPath: String? = null
    private var lastMultiOutputPaths: List<String>? = null

    /** Khoá nút Lưu + hiện tiến độ trong lúc copy file kết quả ra nơi người dùng chọn (chạy nền). */
    private fun setSaveBusy(busy: Boolean, message: String = "") {
        binding.btnSaveAs.isEnabled = !busy
        binding.btnSaveAllAs.isEnabled = !busy
        if (busy) {
            binding.progressBar.visibility = View.VISIBLE
            binding.progressBar.isIndeterminate = true
            binding.txtProgress.text = message
        } else {
            binding.progressBar.isIndeterminate = false
            binding.progressBar.visibility = View.GONE
            binding.txtProgress.text = ""
        }
    }

    private val saveAsLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        uri?.let { destUri ->
            val sourcePath = lastSingleOutputPath ?: return@let
            // [SỬA 25/10/2026 — NGUYÊN NHÂN ANR, bằng chứng từ MainThreadWatchdog] Copy file kết quả (hàng trăm MB
            // tới GB) ra nơi người dùng chọn trước đây chạy THẲNG trong callback ActivityResult = trên luồng chính
            // => UI treo cả chục giây. Giờ chạy ở Dispatchers.IO, UI chỉ hiện tiến độ.
            lifecycleScope.launch {
                setSaveBusy(true, "Đang lưu file ra vị trí đã chọn...")
                try {
                    withContext(Dispatchers.IO) {
                        contentResolver.openOutputStream(destUri)?.use { out ->
                            File(sourcePath).inputStream().use { input -> input.copyTo(out, 1 shl 20) }
                        }
                    }
                    // Hỏi có muốn xoá bản trong app không, tránh chiếm gấp đôi dung lượng
                    AlertDialog.Builder(this@VideoToolsActivity)
                        .setTitle("Đã lưu thành công")
                        .setMessage("File đã được lưu vào vị trí bạn chọn. Xoá bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                        .setPositiveButton("Xoá bản trong app") { _, _ ->
                            // [SỬA 17/11/2026 — bằng chứng MainThreadWatchdog] Xoá file kết quả hàng trăm MB tới GB
                            // THẲNG trong onClick (luồng chính) làm UI treo 7.1s (ngăn xếp: Linux.remove <-
                            // File.delete <- saveAsLauncher). Ẩn nút + báo ngay, xoá thật ở luồng nền.
                            binding.btnSaveAs.visibility = View.GONE
                            Toast.makeText(this@VideoToolsActivity, "Đang xoá bản trong app...", Toast.LENGTH_SHORT).show()
                            val toDelete = File(sourcePath)
                            lifecycleScope.launch(Dispatchers.IO) { try { toDelete.delete() } catch (e: Exception) { /* best-effort */ } }
                        }
                        .setNegativeButton("Giữ cả 2 bản", null)
                        .show()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Toast.makeText(this@VideoToolsActivity, "Lưu thất bại: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    if (!isDestroyed) setSaveBusy(false)
                }
            }
        }
    }

    /**
     * FIX: trước đây khi có NHIỀU file kết quả (vd tách audio nhiều đoạn), app chỉ
     * lưu chúng trong thư mục riêng của app (Android/data/com.videoaistudio.app/...)
     * và không có cách nào để người dùng chuyển chúng ra vị trí công khai (Tải xuống,
     * Nhạc, thư mục tự chọn...) — nếu gỡ app, xoá cache, hoặc dùng trình quản lý file
     * không thấy được thư mục "Android/data" (bị Android giới hạn từ Android 11), coi
     * như MẤT file. Đây chính là "lỗi lưu file" khi tách được nhiều đoạn audio.
     *
     * Dùng ACTION_OPEN_DOCUMENT_TREE để người dùng chọn 1 thư mục (vd Tải xuống, hoặc
     * tự tạo thư mục mới), rồi copy TOÀN BỘ các file kết quả vào đó bằng DocumentFile.
     */
    private val saveAllAsLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri: Uri? ->
        treeUri?.let { uri ->
            val paths = lastMultiOutputPaths ?: return@let
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            val destTree = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)
            if (destTree == null) {
                Toast.makeText(this, "Không mở được thư mục đã chọn.", Toast.LENGTH_LONG).show()
                return@let
            }
            // [SỬA 25/10/2026 — NGUYÊN NHÂN ANR THẬT, bằng chứng từ MainThreadWatchdog: ngăn xếp luồng chính treo
            // 15 giây tại `saveAllAsLauncher` -> `copyTo` -> FileInputStream.read/FileOutputStream.write] Vòng
            // lặp copy TOÀN BỘ file kết quả (2 đoạn ≈ 1.2GB) chạy THẲNG trên luồng chính. Giờ chạy ở Dispatchers.IO,
            // cập nhật "file i/N" trên UI giữa các file.
            lifecycleScope.launch {
                var savedCount = 0
                var failedCount = 0
                try {
                    for ((index, path) in paths.withIndex()) {
                        setSaveBusy(true, "Đang lưu file ${index + 1}/${paths.size}...")
                        val ok = withContext(Dispatchers.IO) {
                            try {
                                val srcFile = File(path)
                                val mime = android.webkit.MimeTypeMap.getSingleton()
                                    .getMimeTypeFromExtension(srcFile.extension) ?: "application/octet-stream"
                                val destDoc = destTree.createFile(mime, srcFile.name)
                                if (destDoc != null) {
                                    contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                                        srcFile.inputStream().use { input -> input.copyTo(out, 1 shl 20) }
                                    }
                                    true
                                } else {
                                    false
                                }
                            } catch (e: kotlinx.coroutines.CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                false
                            }
                        }
                        if (ok) savedCount++ else failedCount++
                    }
                } finally {
                    if (!isDestroyed) setSaveBusy(false)
                }
                val summary = if (failedCount == 0) {
                    "Đã lưu $savedCount/$savedCount file vào thư mục đã chọn."
                } else {
                    "Đã lưu $savedCount file, LỖI $failedCount file — thử lại nếu cần."
                }
                AlertDialog.Builder(this@VideoToolsActivity)
                    .setTitle("Kết quả lưu")
                    .setMessage("$summary\n\nXoá các bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                    .setPositiveButton("Xoá bản trong app") { _, _ ->
                        // [SỬA 17/11/2026] Cùng lý do với saveAsLauncher: xoá nhiều file lớn không được chạy ở luồng chính.
                        binding.btnSaveAllAs.visibility = View.GONE
                        Toast.makeText(this@VideoToolsActivity, "Đang xoá bản trong app...", Toast.LENGTH_SHORT).show()
                        val toDelete = paths.toList()
                        lifecycleScope.launch(Dispatchers.IO) {
                            toDelete.forEach { p -> try { File(p).delete() } catch (e: Exception) { /* best-effort */ } }
                        }
                    }
                    .setNegativeButton("Giữ cả 2 bản", null)
                    .show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.log(this, "VideoToolsActivity", "onCreate() — Activity instance MỚI được tạo (savedInstanceState=${savedInstanceState != null})")
        binding = ActivityVideoToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val requestedModeName = intent.getStringExtra(EXTRA_MODE)
        currentMode = VideoToolMode.values().firstOrNull { it.name == requestedModeName } ?: VideoToolMode.TRIM_SPLIT
        // [THÊM 09/09/2026] Lối tắt "Ghép phụ đề vào video" ở màn hình chính — mở thẳng
        // TRIM_SPLIT với checkbox ghép phụ đề đã tick sẵn, để người dùng không phải tự
        // biết checkbox này nằm ở đâu trong khu Cắt/Tách.
        val autoBurnSubtitle = intent.getBooleanExtra(EXTRA_AUTO_BURN_SUBTITLE, false)

        FileUtils.clearVideoInputCache(applicationContext)

        binding.spinnerMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, VideoToolMode.values())
        binding.spinnerMode.setSelection(VideoToolMode.values().indexOf(currentMode))
        binding.spinnerMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentMode = VideoToolMode.values()[position]
                onModeChanged()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.spinnerCompressPreset.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Nhẹ (nén nhiều, nhỏ nhất)", "Vừa (cân bằng)", "Nét (nén ít, giữ chất lượng)")
        )
        binding.spinnerCompressPreset.setSelection(1) // mặc định "Vừa"
        binding.spinnerCompressPreset.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = updateCompressEstimate()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.btnPickVideo.setOnClickListener {
            // [THÊM 16/11/2026] Đang sao chép video thì KHÔNG cho chọn lại: nhánh 1-file bên dưới gọi
            // clearVideoInputCache() (đổi tên thư mục + xoá nền) — làm đúng lúc copy trước còn đang ghi sẽ khiến
            // file đích biến mất (log thật: copy 3.69GB xong báo "0 byte"). Xem PROJECT_SPEC.md mục 6, 16/11/2026.
            if (pendingImports > 0 || recovering) {
                Toast.makeText(this, "Đang sao chép video, vui lòng đợi xong rồi chọn lại.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            selectedFilePaths.clear()
            updateSelectedFilesText()
            if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) {
                // KHÔNG xoá cache vật lý ở đây — nhánh này cho chọn NHIỀU video cùng lúc
                // (Ghép/Nén), các file cần cùng tồn tại trong cache, không phải thay thế
                // nhau như nhánh else bên dưới.
                pickMultipleVideos.launch(arrayOf("video/*"))
            } else {
                // [FIX 17/09/2026 — LỖI THẬT người dùng báo: "cắt video 1 xong, thêm video
                // 2 vào thì bộ nhớ đệm lấy dung lượng 2 video cộng lại"] Trước đây chỉ
                // clear() DANH SÁCH TRONG RAM — KHÔNG xoá file thật đã copy vào cache ở
                // lần chọn TRƯỚC (copyUriToCache() dùng ĐÚNG TÊN GỐC của file làm tên đích,
                // 2 video khác tên -> không ghi đè nhau -> cả 2 cùng tồn tại vĩnh viễn
                // trong cache mỗi lần đổi video trong CÙNG 1 lần mở màn hình này, không
                // cần đóng app). Xoá cache vật lý NGAY TRƯỚC khi mở trình chọn video mới,
                // đảm bảo tối đa 1 video nằm trong cache tại 1 thời điểm cho nhánh 1-file.
                FileUtils.clearVideoInputCache(applicationContext)
                pickSingleVideo.launch(arrayOf("video/*"))
            }
        }

        binding.btnAddMoreVideo.setOnClickListener {
            pickMultipleVideos.launch(arrayOf("video/*"))
        }

        // [THÊM tính năng Convert sang MP4] Chỉ hiện ở chế độ CONVERT_TO_MP4, dành riêng
        // cho input m3u8/HLS — xem lý do bắt buộc dùng trình chọn THƯ MỤC (không phải
        // file đơn) tại FileUtils.importM3u8FolderToCache().
        binding.btnPickM3u8Folder.setOnClickListener {
            if (pendingImports > 0 || recovering) { // [16/11/2026] cùng lý do với btnPickVideo
                Toast.makeText(this, "Đang sao chép video, vui lòng đợi xong rồi chọn lại.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            selectedFilePaths.clear()
            updateSelectedFilesText()
            // [FIX 17/09/2026 — cùng lỗi/cùng nguyên nhân với btnPickVideo ở trên]
            // importM3u8FolderToCache() tạo 1 thư mục "m3u8_bundle_<timestamp>" MỚI mỗi
            // lần import — đổi bundle m3u8 nhiều lần trong CÙNG 1 lần mở màn hình này sẽ
            // cộng dồn y hệt, vì thư mục timestamp cũ không tự dọn. Xoá cache vật lý trước
            // khi mở trình chọn thư mục mới.
            FileUtils.clearVideoInputCache(applicationContext)
            pickM3u8FolderLauncher.launch(null)
        }

        // [THÊM 17/11/2026] Công tắc "Cắt chính xác điểm bắt đầu" (SmartCut) — mặc định BẬT, nhớ lựa chọn giữa các lần mở.
        // Đặt isChecked TRƯỚC khi gắn listener để việc nạp lại giá trị đã lưu không kích hoạt listener.
        val toolPrefs = getSharedPreferences("video_tools_prefs", MODE_PRIVATE)
        binding.chkExactCut.isChecked = try { toolPrefs.getBoolean("exact_cut", true) } catch (e: Exception) { true }
        binding.chkExactCut.setOnCheckedChangeListener { _, checked ->
            try { toolPrefs.edit().putBoolean("exact_cut", checked).apply() } catch (e: Exception) { /* nhớ lựa chọn là tiện ích, bỏ qua lỗi */ }
            DebugLog.log(this, "VideoToolsActivity", "Công tắc 'Cắt chính xác' = $checked")
            val v = binding.rangeSlider.values
            if (v.size >= 2) scheduleRealStartHint(v.first()) // đổi chế độ => đổi nội dung dòng "điểm cắt thật"
        }
        binding.btnAddSelectedRange.setOnClickListener { addSelectedRangeToList() }
        binding.btnRun.setOnClickListener { runCurrentAction() }
        binding.btnViewDebugLog.setOnClickListener { showDebugLogDialog() }
        // Lối tắt gần khu Trim, xem giải thích ở layout XML (chỗ khai báo nút này) — cùng
        // gọi thẳng 1 hàm showDebugLogDialog() y hệt nút gốc, không phải luồng riêng.
        binding.btnViewDebugLogShortcut.setOnClickListener { showDebugLogDialog() }
        // [THÊM 06/09/2026] Ghép cứng phụ đề — chỉ hiện phần chọn file khi tick chọn.
        binding.checkboxBurnSubtitle.setOnCheckedChangeListener { _, checked ->
            binding.groupBurnSubtitle.visibility = if (checked) View.VISIBLE else View.GONE
        }
        binding.btnPickSubtitle.setOnClickListener { pickSubtitleFile.launch(arrayOf("*/*")) }
        // Chỉ hiện ô nhập "bắt đầu ở giây nào trong video gốc" khi chọn đúng chế độ (B) —
        // video đang chọn ĐÃ LÀ đoạn cắt sẵn, không cần ô này khi ở chế độ (A) (dùng
        // RangeSlider/danh sách đoạn phía trên để xác định đoạn cắt như bình thường).
        binding.radioSubtitleMode.setOnCheckedChangeListener { _, checkedId ->
            binding.groupSubtitleOffset.visibility =
                if (checkedId == binding.radioSubModeAlreadyCut.id) View.VISIBLE else View.GONE
        }
        binding.btnCancelRunning.setOnClickListener {
            val cancelled = VideoEngine.cancelCurrentSession()
            if (cancelled) {
                Toast.makeText(this, "Đã gửi yêu cầu huỷ — chờ vài giây để dừng hẳn.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Không có tác vụ nào đang chạy để huỷ.", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnSaveAs.setOnClickListener {
            val path = lastSingleOutputPath ?: return@setOnClickListener
            saveAsLauncher.launch(File(path).name)
        }
        binding.btnSaveAllAs.setOnClickListener {
            saveAllAsLauncher.launch(null)
        }

        setupDragAndDrop()

        onModeChanged()
        // Đặt SAU onModeChanged() để groupTrimSplit (chứa checkboxBurnSubtitle) đã ở trạng
        // thái VISIBLE trước khi tick — tick trước khi group hiện ra vẫn set đúng giá trị
        // isChecked, nhưng đặt sau cho chắc chắn thứ tự, tránh phụ thuộc ngầm vào việc
        // View đã inflate/visible hay chưa.
        if (autoBurnSubtitle) {
            binding.checkboxBurnSubtitle.isChecked = true
        }
    }

    /**
     * Cho phép kéo file trực tiếp từ File Manager (chế độ chia đôi màn hình / cửa sổ
     * thu nhỏ — Android multi-window drag-and-drop) thả thẳng vào màn hình này, THAY
     * VÌ bắt buộc phải bấm nút "Chọn video" rồi duyệt thư mục thủ công trước. Gắn vào
     * `binding.root` (toàn màn hình) để thả ở bất kỳ chỗ nào cũng nhận được, không
     * cần nhắm chính xác vào 1 nút nhỏ.
     *
     * Tái sử dụng đúng `importUri()` đã có sẵn (dùng chung với luồng bấm nút chọn
     * file) — nhờ vậy hành vi sau khi thả (copy vào cache, cập nhật danh sách, load
     * preview...) giống hệt như chọn file qua nút bấm, không viết logic riêng dễ lệch.
     */
    private fun setupDragAndDrop() {
        val originalBackground = binding.root.background
        binding.root.setOnDragListener { view, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    // Chấp nhận rộng rãi, không lọc gắt theo MIME "video/*" ở bước này
                    // — nhiều app File Manager không luôn khai báo đúng MIME khi bắt
                    // đầu kéo. Định dạng sai sẽ tự bị ExoPlayer/FFmpeg báo lỗi ở bước xử
                    // lý sau, không cần chặn sớm ở đây.
                    true
                }
                DragEvent.ACTION_DRAG_ENTERED -> {
                    view.setBackgroundColor(0x332196F3) // xanh dương mờ — gợi ý đang ở đúng vùng thả
                    true
                }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                    view.background = originalBackground
                    true
                }
                DragEvent.ACTION_DROP -> {
                    view.background = originalBackground
                    val clipData = event.clipData
                    if (clipData == null || clipData.itemCount == 0) {
                        Toast.makeText(this, "Không nhận được file từ thao tác kéo-thả", Toast.LENGTH_SHORT).show()
                        return@setOnDragListener true
                    }
                    // [16/11/2026] Đang copy thì không nhận thả thêm (nhánh 1-file xoá cache — xem btnPickVideo).
                    if ((pendingImports > 0 || recovering) && currentMode != VideoToolMode.MERGE && currentMode != VideoToolMode.COMPRESS) {
                        Toast.makeText(this, "Đang sao chép video, vui lòng đợi xong rồi thả lại.", Toast.LENGTH_SHORT).show()
                        return@setOnDragListener true
                    }
                    // BẮT BUỘC xin quyền đọc URI đến từ app khác qua kéo-thả — khác với
                    // URI trả về từ file picker (OpenDocument) vốn đã tự động có quyền,
                    // URI từ kéo-thả liên-app cần xin quyền tường minh kiểu này, nếu
                    // không đọc file sẽ bị SecurityException.
                    val permissions = requestDragAndDropPermissions(event)
                    val isMultiMode = currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS
                    if (!isMultiMode) {
                        // Chế độ chỉ nhận 1 file: thả file mới = THAY THẾ file đang chọn,
                        // giống hệt hành vi nút "Chọn video" (không phải "Thêm video").
                        selectedFilePaths.clear()
                        updateSelectedFilesText()
                        // Giống nút "Chọn video": bỏ file cache cũ (đổi tên + xoá nền, tức thì) để không cộng dồn dung lượng.
                        FileUtils.clearVideoInputCache(applicationContext)
                    }
                    val droppedUris = ArrayList<Uri>()
                    for (i in 0 until clipData.itemCount) {
                        if (!isMultiMode && droppedUris.size >= 1) break // chế độ 1 file: chỉ lấy file đầu tiên nếu lỡ kéo nhiều file cùng lúc
                        val uri = clipData.getItemAt(i).uri ?: continue
                        droppedUris.add(uri)
                    }
                    val addedCount = droppedUris.size
                    // [SỬA 25/10/2026] Copy giờ chạy NỀN nên KHÔNG được release quyền đọc URI ngay sau vòng
                    // lặp như trước (copy chưa xong sẽ bị SecurityException) — release sau khi file cuối copy xong.
                    importUris(droppedUris) { permissions?.release() }
                    if (addedCount > 0) {
                        Toast.makeText(this, "Đã thêm $addedCount file từ kéo-thả", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun currentPreset(): VideoEngine.CompressPreset = when (binding.spinnerCompressPreset.selectedItemPosition) {
        0 -> VideoEngine.CompressPreset.NHE
        2 -> VideoEngine.CompressPreset.NET
        else -> VideoEngine.CompressPreset.VUA
    }

    private fun updateCompressEstimate() {
        if (selectedFilePaths.isEmpty()) {
            binding.txtCompressEstimate.text = "Chọn video để xem ước tính dung lượng"
            return
        }
        val preset = currentPreset()
        var totalOriginal = 0L
        var totalEstimated = 0L
        var validCount = 0
        for (path in selectedFilePaths) {
            val originalBitrate = FileUtils.calculateActualBitrateBps(path)
            val durationSec = FileUtils.getVideoDurationSec(path)
            if (originalBitrate <= 0 || durationSec <= 0) continue
            validCount++
            totalOriginal += File(path).length()
            val estimatedBitrate = (originalBitrate * preset.bitrateMultiplier).toLong()
            totalEstimated += (estimatedBitrate * durationSec / 8).toLong()
        }
        binding.txtCompressEstimate.text = if (validCount == 0) {
            "Không đọc được thông tin video để ước tính"
        } else {
            val prefix = if (selectedFilePaths.size > 1) "Tổng ${selectedFilePaths.size} file — " else ""
            "${prefix}Dung lượng gốc: ${FileUtils.formatBytes(totalOriginal)} → Ước tính sau nén: ~${FileUtils.formatBytes(totalEstimated)}"
        }
    }

    /** Bật/tắt trạng thái "đang sao chép video" trên thanh tiến độ chung; khoá nút Chạy trong lúc sao chép. */
    private fun setImportBusy(busy: Boolean) {
        if (busy) {
            binding.progressBar.visibility = View.VISIBLE
            binding.progressBar.isIndeterminate = true
            binding.txtProgress.text = "Đang sao chép video vào bộ nhớ đệm..."
            if (binding.btnRun.isEnabled) {
                binding.btnRun.isEnabled = false
                runButtonDisabledByImport = true
            }
        } else {
            binding.progressBar.isIndeterminate = false
            binding.progressBar.visibility = View.GONE
            binding.txtProgress.text = ""
            if (runButtonDisabledByImport) {
                binding.btnRun.isEnabled = true
                runButtonDisabledByImport = false
            }
        }
    }

    /**
     * [SỬA 25/10/2026 — NGUYÊN NHÂN ANR "Video AI Studio không phản hồi", log thật: video 1.79GB]
     * Trước đây hàm này copy NGUYÊN file vào cache NGAY TRÊN LUỒNG CHÍNH (`copyUriToCache` đồng bộ,
     * được gọi thẳng từ callback chọn file/kéo-thả) — 1.8GB mất hàng chục giây (log: onCreate 16:37:07 →
     * nạp preview xong 16:37:39) trong lúc UI hoàn toàn đứng => hệ thống hiện hộp thoại ANR. Giờ: copy ở
     * Dispatchers.IO (có % tiến độ, huỷ được khi rời màn hình), chỉ phần cập nhật UI + nạp preview chạy trên
     * luồng chính. Mutex (công bằng, FIFO) giữ nguyên THỨ TỰ các file khi chọn nhiều file (Ghép/Nén) và
     * không copy song song (tránh tranh chấp ổ đĩa).
     */
    private fun isPreviewMode(): Boolean =
        currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE

    /** Đọc thời lượng video (giây) bằng MediaMetadataRetriever — gọi từ luồng nền (parse moov file GB tốn thời gian). */
    private fun readDurationSecBlocking(path: String): Float? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            (durationMs / 1000f).coerceAtLeast(1f)
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    /**
     * [THÊM 25/10/2026 — LỖI người dùng báo: "mục thêm đoạn cũ vẫn còn nguyên, không bị reset => cắt nhầm"]
     * `getEffectiveSegments()` ƯU TIÊN danh sách đoạn trong ô văn bản nếu nó không rỗng, chỉ khi rỗng mới dùng
     * thanh trượt. Nạp video MỚI mà không xoá danh sách => Run sẽ cắt video mới theo mốc giây của video CŨ
     * (kể cả khi người dùng chỉ kéo thanh trượt). Giờ reset ngay khi bắt đầu nạp video mới. Đồng thời thả
     * player cũ TRƯỚC khi copy: nếu cùng tên file (nạp lại đúng video), copy mới ghi đè (cắt cụt) chính file mà
     * player cũ đang đọc dở.
     */
    private fun resetPreviewStateForNewVideo() {
        releasePlayer()
        binding.edtSegments.setText("")
    }

    private fun importUri(uri: Uri) {
        if (pendingImports == 0 && isPreviewMode()) resetPreviewStateForNewVideo()
        pendingImports++
        if (pendingImports == 1) setImportBusy(true)
        lifecycleScope.launch {
            importMutex.withLock {
                try {
                    val name = withContext(Dispatchers.IO) { FileUtils.queryDisplayName(this@VideoToolsActivity, uri) }
                    val totalSize = withContext(Dispatchers.IO) { FileUtils.queryDisplaySize(this@VideoToolsActivity, uri) }
                    val startedAt = android.os.SystemClock.uptimeMillis()
                    var lastUiAt = 0L
                    val file = withContext(Dispatchers.IO) {
                        FileUtils.copyUriToCache(
                            this@VideoToolsActivity, uri, name,
                            onProgress = { copied ->
                                val now = android.os.SystemClock.uptimeMillis()
                                if (now - lastUiAt > 300L) {
                                    lastUiAt = now
                                    runOnUiThread {
                                        if (totalSize > 0L) {
                                            binding.progressBar.isIndeterminate = false
                                            binding.progressBar.progress = (copied * 100L / totalSize).toInt().coerceIn(0, 100)
                                            binding.txtProgress.text = "Đang sao chép video vào bộ nhớ đệm... ${FileUtils.formatBytes(copied)} / ${FileUtils.formatBytes(totalSize)}"
                                        } else {
                                            binding.txtProgress.text = "Đang sao chép video vào bộ nhớ đệm... ${FileUtils.formatBytes(copied)}"
                                        }
                                    }
                                }
                            },
                            isCancelled = { !isActive },
                            expectedSize = totalSize
                        )
                    }
                    // [THÊM 16/11/2026] Ghi nhớ Uri gốc + thời điểm copy xong (để tự khôi phục nếu file biến mất —
                    // xem recoverMissingInput — và để log "mất sau bao lâu"), kèm dung lượng trống sau khi copy
                    // (bằng chứng cho giả thuyết "máy thiếu chỗ nên hệ thống dọn").
                    sourceUriByPath[file.absolutePath] = uri
                    copyFinishedAtMs[file.absolutePath] = android.os.SystemClock.uptimeMillis()
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "Sao chép video vào cache (luồng nền) xong: ${file.name}, ${file.length()} byte, ${android.os.SystemClock.uptimeMillis() - startedAt}ms; " +
                            "kích thước nguồn khai báo=$totalSize; thư mục làm việc=${FileUtils.videoInputDir(this@VideoToolsActivity).parentFile?.name}/video_input; " +
                            "ổ đĩa trống sau copy=${com.videoaistudio.app.video.SafeCopy.formatGb(FileUtils.videoInputDir(this@VideoToolsActivity).usableSpace)}" +
                            (if (totalSize > 0L && file.length() != totalSize) "; ⚠️ SỐ BYTE KHÁC kích thước nguồn khai báo" else "")
                    )
                    // Đọc thời lượng ở NỀN (parse moov của file GB trên luồng chính từng làm UI giật khi nạp video).
                    val preloadedDuration = if (isPreviewMode() && selectedFilePaths.isEmpty()) {
                        withContext(Dispatchers.IO) { readDurationSecBlocking(file.absolutePath) }
                    } else null
                    selectedFilePaths.add(file.absolutePath)
                    updateSelectedFilesText()

                    if (isPreviewMode() && selectedFilePaths.size == 1) {
                        loadPreview(file, preloadedDuration)
                    }
                    if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e // rời màn hình giữa chừng: copy dở đã được dọn trong copyUriToCache()
                } catch (e: InsufficientStorageException) {
                    // [THÊM 16/11/2026] Thiếu chỗ: báo thẳng, không copy dở. Thông báo đã là câu hoàn chỉnh.
                    DebugLog.log(this@VideoToolsActivity, "VideoToolsActivity", "Sao chép video bị TỪ CHỐI — ${e.message}")
                    Toast.makeText(this@VideoToolsActivity, e.message ?: "Không đủ dung lượng trống", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    // [THÊM 16/11/2026] Trước đây chỉ hiện Toast, log không có dấu vết — giờ ghi lỗi + trạng thái thư mục/ổ đĩa.
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "Sao chép video LỖI: ${e.javaClass.simpleName}: ${e.message}; ${FileUtils.describeInputState(this@VideoToolsActivity, null)}"
                    )
                    Toast.makeText(this@VideoToolsActivity, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    pendingImports--
                    if (pendingImports <= 0) {
                        pendingImports = 0
                        if (!isDestroyed) setImportBusy(false)
                    }
                }
            }
        }
    }

    /** Import nhiều URI theo thứ tự; [onAllDone] chạy SAU KHI file cuối cùng đã copy xong (hoặc lỗi). */
    private fun importUris(uris: List<Uri>, onAllDone: (() -> Unit)? = null) {
        uris.forEach { importUri(it) }
        if (onAllDone != null) {
            lifecycleScope.launch { importMutex.withLock { onAllDone() } }
        }
    }

    /** Định dạng giây -> "H:MM:SS" để dễ theo dõi với video dài. */
    private fun secondsToHms(totalSec: Float): String {
        val total = totalSec.toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    /** Đọc "H:MM:SS" hoặc "MM:SS" hoặc chỉ số giây -> tổng số giây (float). Trả null nếu sai định dạng. */
    private fun hmsToSeconds(text: String): Float? {
        val parts = text.trim().split(":")
        return try {
            when (parts.size) {
                1 -> parts[0].toFloat()
                2 -> parts[0].toInt() * 60f + parts[1].toFloat()
                3 -> parts[0].toInt() * 3600f + parts[1].toInt() * 60f + parts[2].toFloat()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Nạp video vào player xem trước + đọc thời lượng thật để đặt giới hạn RangeSlider. */
    // @OptIn(UnstableApi::class): cần cho SeekParameters bên dưới. LƯU Ý quan trọng (rút
    // kinh nghiệm từ lần nâng media3 lên 1.10.1 bị lỗi build compileSdk 36): `SeekParameters`
    // được đánh dấu @UnstableApi nhưng đây KHÔNG phải API mới — nó tồn tại từ những bản
    // ExoPlayer/Media3 đầu tiên (Media3 gắn @UnstableApi cho rất nhiều API tầng thấp ngay từ
    // 1.0.0, không đồng nghĩa "mới ra"). KHÔNG cần đổi version media3 (vẫn 1.4.1 như cũ) —
    // `androidx.media3.common.util.UnstableApi` đã có sẵn từ `media3-common` (dependency có
    // sẵn từ trước), không kéo theo yêu cầu compileSdk nào mới.
    @OptIn(UnstableApi::class)
    private fun loadPreview(file: File, preloadedDurationSec: Float? = null) {
        releasePlayer()
        val loadPreviewStartedAt = android.os.SystemClock.uptimeMillis()

        try {
            if (preloadedDurationSec != null) {
                videoDurationSec = preloadedDurationSec
            } else {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(file.absolutePath)
                    val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    videoDurationSec = (durationMs / 1000f).coerceAtLeast(1f)
                } finally {
                    retriever.release()
                }
            }

            // [SỬA 25/10/2026 — LỖI THẬT, độc lập với lỗi ticker] Mỗi lần loadPreview() chạy (chọn/đổi
            // video trong CÙNG 1 phiên mở màn hình) code bên dưới GẮN THÊM listener mới vào
            // RangeSlider + 2 ô nhập giờ mà KHÔNG gỡ listener của lần trước. Listener cũ vẫn sống,
            // giữ tham chiếu tới ExoPlayer ĐÃ release + đường dẫn file CŨ, và mỗi closure có cờ
            // syncingFromCode RIÊNG nên cờ của closure này không chặn được closure kia -> mỗi lần kéo
            // slider chạy N bộ xử lý chồng nhau (N = số video đã nạp), chúng tự kích nhau qua
            // setText/TextWatcher và có thể ghi đè giá trị slider bằng keyframe của file cũ.
            // Gỡ sạch trước khi gắn mới.
            binding.rangeSlider.clearOnChangeListeners()
            binding.rangeSlider.clearOnSliderTouchListeners()
            trimTextWatcher?.let {
                binding.edtStartSec.removeTextChangedListener(it)
                binding.edtEndSec.removeTextChangedListener(it)
            }
            trimTextWatcher = null

            binding.rangeSlider.valueFrom = 0f
            binding.rangeSlider.valueTo = videoDurationSec
            binding.rangeSlider.values = listOf(0f, videoDurationSec)
            binding.txtRangeLabel.text = "Kéo 2 đầu để chọn đoạn (0:00 - ${secondsToHms(videoDurationSec)})"
            binding.edtStartSec.setText(secondsToHms(0f))
            binding.edtEndSec.setText(secondsToHms(videoDurationSec))

            val exoPlayer = ExoPlayer.Builder(this).build()
            // FIX QUAN TRỌNG (báo qua chat, LẦN THỨ 3 cho đúng 1 bug — đọc hết trước khi
            // đụng vào đoạn này lần nữa): "kéo slider thì frame KHÔNG di chuyển, thả tay ra
            // mới nhảy tới đúng chỗ".
            //
            // Nguyên nhân gốc (phần này đúng, không đổi): RangeSlider bắn addOnChangeListener
            // RẤT NHIỀU LẦN trong 1 lần kéo (gần như mỗi pixel), mỗi lần gọi thẳng
            // exoPlayer.seekTo() mới -> ExoPlayer huỷ seek đang xử lý dở mỗi khi nhận seek
            // mới -> nếu gọi nhanh hơn tốc độ decode+render, không khung hình nào kịp hiển
            // thị cho tới khi luồng seekTo dừng lại (= lúc thả tay).
            //
            // [SỬA LẦN 1 — 02/09/2026 — ĐÃ GIAO NHƯNG SAI, GHI LẠI LÝ DO ĐỂ KHÔNG LẶP LẠI]
            // Bản trước dựng cơ chế "tối đa 1 seek đang bay" + đợi
            // onPositionDiscontinuity(reason=SEEK) báo "xong" mới bắn lệnh tiếp theo. Test
            // tay thật báo lại NGUYÊN VĂN triệu chứng cũ — cơ chế "đợi" không có tác dụng
            // gì. Tra tài liệu chính thức Media3
            // (developer.android.com/media/media3/exoplayer/listening-to-player-events) mới
            // rõ lý do: onPositionDiscontinuity(SEEK) được bắn ra NGAY LẬP TỨC như hệ quả
            // trực tiếp của lời gọi seekTo() (cơ chế "position masking" — ExoPlayer cập nhật
            // vị trí báo cáo ra ngoài tức thì để currentPosition đúng ngay, KHÔNG chờ khung
            // hình thật sự được decode+render lên Surface). Nghĩa là tín hiệu mình dùng để
            // "biết khi nào an toàn bắn seek tiếp theo" thật ra không hề tương ứng với việc
            // nặng (render hình) — nó tương ứng với việc nhẹ (cập nhật con số vị trí) — nên
            // lệnh seekTo() thứ 2 vẫn được bắn đi gần như ngay sau lệnh thứ nhất, y hệt lúc
            // chưa sửa gì. Bài học: dùng 1 callback để suy luận "việc nặng xong chưa" thì
            // phải xác minh đúng là callback đó gắn với việc nặng, không phải chỉ tình cờ đi
            // kèm.
            //
            // [SỬA LẦN 2 — 04/09/2026, ĐÃ THỬ, TỰ HUỶ TRONG PHIÊN NÀY — GHI LẠI ĐỂ KHÔNG AI
            // LẶP LẠI] Ban đầu định dùng "Scrubbing Mode" chính thức của ExoPlayer
            // (setScrubbingModeEnabled(), Media3 >= 1.8.0) — API CHÍNH XÁC cho use-case này
            // (nguồn: android-developers.googleblog.com/2025/08/media3-180-whats-new.html).
            // ĐÃ nâng media3 lên 1.10.1 và đẩy build qua GitHub Actions để thử — build LỖI
            // BIÊN DỊCH (không phải lỗi runtime): media3 1.10.1 yêu cầu compileSdk >= 36,
            // mà project đang compileSdk 34 với AGP 8.5.0 (chỉ hỗ trợ tối đa 34). Tra tiếp
            // thì AGP hỗ trợ compileSdk 36 sớm nhất là bản 9.0 — nhưng AGP 9.0/9.1 là BẢN
            // MAJOR, đổi hẳn kiến trúc DSL nội bộ, MẶC ĐỊNH bật "Built-in Kotlin" đòi hỏi
            // Kotlin Gradle Plugin >= 2.2.10 (project đang khai 1.9.24 — cách nhau rất xa),
            // bỏ hẳn nhiều API cũ (variantFilter, sdkDirectory/ndkDirectory/adbExecutable...).
            // Đây không còn là "tăng 1 số version thư viện" nữa mà là nâng cấp lớn cả toolchain
            // — không có mạng để build-thử trong môi trường sửa code này, nên KHÔNG đánh cược
            // tiếp bằng 1 lần build thật nữa của bạn. ĐÃ HUỶ hướng này, quay về media3 1.4.1
            // như cũ (xem app/build.gradle.kts) — nếu sau này chủ động muốn nâng cả AGP lên
            // 9.x (việc đáng làm về lâu dài, nhưng cần làm RIÊNG, có kiểm tra kỹ riêng,
            // không lồng vào 1 bug fix nhỏ thế này), thì lúc đó mở lại API scrubbing mode.
            //
            // [SỬA LẦN 3 — CƠ CHẾ TỰ VIẾT, KHÔNG PHỤ THUỘC VERSION/CALLBACK NÀO CỦA EXOPLAYER]
            // Thay vì suy luận "ExoPlayer báo xong seek chưa" (2 lần trước đều sai vì chọn
            // nhầm tín hiệu, hoặc tín hiệu đúng nhưng kéo theo nâng cấp quá rủi ro), đổi hẳn
            // cách tiếp cận: dùng 1 "nhịp" (ticker) cố định bằng Handler.postDelayed(), CHỈ
            // chạy trong lúc đang kéo — mỗi 90ms bắn seekTo() ĐÚNG 1 LẦN tới vị trí ngón tay
            // MỚI NHẤT tại thời điểm đó (không quan tâm ExoPlayer đã "xử lý xong" seek trước
            // hay chưa). Bản chất: tự giới hạn cứng tốc độ gọi seekTo() bằng đồng hồ, KHÔNG
            // dựa vào bất kỳ callback/trạng thái nội bộ nào của ExoPlayer — nên không thể tái
            // diễn kiểu lỗi "chọn nhầm tín hiệu" như 2 lần trước, và không cần thư viện nào
            // mới. Đánh đổi: preview lúc kéo cập nhật theo nhịp cố định bên dưới (mượt vừa đủ
            // để mắt thấy hình di chuyển theo tay, không phải mọi frame), thay vì "mượt tuyệt
            // đối" như scrubbing mode thật sự — chấp nhận được để đổi lấy KHÔNG rủi ro build vỡ.
            //
            // [BỔ SUNG — phản hồi "vẫn trễ hơn hồi trước"] Ticker chỉ trị được 1 trong 2 nguồn
            // trễ: tốc độ GỌI seekTo(). Nguồn trễ còn lại là tốc độ MỖI LẦN seek tự nó chạy
            // bao lâu — mặc định ExoPlayer seek chính xác tuyệt đối (`SeekParameters.EXACT`),
            // với video nén phải decode tuần tự từ keyframe gần nhất tới đúng vị trí, có thể
            // tốn hàng chục-hàng trăm ms/lần tuỳ khoảng cách tới keyframe. Đã thêm
            // `exoPlayer.setSeekParameters(SeekParameters.CLOSEST_SYNC)` lúc bắt đầu kéo (xem
            // `addOnSliderTouchListener` bên dưới) — nhảy thẳng tới keyframe gần nhất, gần như
            // tức thời, đổi lấy hình có thể lệch chút so với đúng mili-giây (chấp nhận được
            // khi đang xem trước, trả lại `EXACT` ngay khi thả tay cho lần seek chốt cuối).
            //
            // [ĐIỀU CHỈNH 04/09/2026, phản hồi hộp thoại đòi đóng app xuất hiện liên tục khi
            // test] Log debug thật (người dùng gửi) cho thấy nhiều lần kéo kéo dài LIÊN TỤC
            // 8-14 GIÂY, mỗi lần bắn 100-211 lệnh seekTo() THẬT (không phải giả định — đếm
            // được), tức là chỉ trong 1 lần kéo tay đã yêu cầu ExoPlayer decode+hiển thị
            // 100-200 khung hình khác nhau liên tiếp — nặng hơn nhiều so với 1 cú vuốt ngắn
            // thông thường. CHƯA CHẮC đây là nguyên nhân của hộp thoại đòi đóng app (cần biết
            // ĐÚNG chữ trong hộp thoại đó mới kết luận được — có thể là ANR thật của Android,
            // cũng có thể là tính năng "tự đóng app tốn pin" riêng của hãng máy, không liên
            // quan gì tới đoạn code này) — nhưng tăng nhịp lên 100ms (giảm ~40% tổng số lệnh
            // seek cho cùng 1 thời lượng kéo) là biện pháp giảm tải hợp lý trong lúc chờ xác
            // định đúng nguyên nhân, không cần đợi biết chắc mới hành động.
            // [SỬA LẦN 5 — 25/10/2026] TICKER MỞ VÒNG (Handler.postDelayed 100ms, seek mỗi nhịp kể cả khi
            // vị trí không đổi) ĐÃ BỊ THAY bằng `ScrubSeekController` (seek VÒNG KÍN: chỉ seek tiếp khi
            // seek trước đã ra khung hình). Lý do + phân tích log: xem doc comment của
            // ScrubSeekController.kt và PROJECT_SPEC.md mục 6 ngày 25/10/2026. KHÔNG khôi phục ticker.
            var lastErrorToastAtMs = 0L
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    // [SỬA 25/10/2026] Log thật cho thấy: lỗi này làm player CHẾT (state=IDLE) giữa lúc kéo và
                    // KHÔNG AI hồi sinh nó -> mọi lần kéo sau đó đều "bắn seek" vào player chết = preview đứng
                    // hình mãi ("lúc đầu theo, lúc sau không theo"). Trước đây handler chỉ hiện 1 Toast.
                    // Ghi CHUỖI NGUYÊN NHÂN + vị trí phát sinh (lớp extractor nào ném lỗi) + vị trí/đích seek, để
                    // phân biệt "file hỏng đúng vùng đó" (lặp lại ở cùng vị trí) với "lỗi ngẫu nhiên khi seek dồn".
                    val rootCause = generateSequence<Throwable>(error) { it.cause }.last()
                    val topFrames = (error.cause ?: error).stackTrace.take(6).joinToString(" <- ") {
                        "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}"
                    }
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "ExoPlayer onPlayerError — ${error.errorCodeName}(${error.errorCode}): ${error.message}; " +
                            "nguyên nhân gốc=${rootCause.javaClass.simpleName}: ${rootCause.message}; nơi phát sinh=$topFrames; " +
                            "pos=${exoPlayer.currentPosition}ms, đích seek gần nhất=${scrubController?.lastIssuedTargetMs ?: -1}ms, " +
                            "file=${file.name} (${file.length()} byte)"
                    )
                    scrubController?.onPlayerFailed()
                    // [THÊM 16/11/2026 — LỖI THẬT người dùng báo "không xem trước và cắt được"] Log thật: ENOENT
                    // ~55 giây sau khi copy xong (file 2.15GB), app đang ở foreground, không có đường xoá nào của app
                    // được ghi log. Đây KHÔNG phải "file hỏng đúng vùng đó" như Toast bên dưới nói — file không còn
                    // nữa. (1) Ghi bằng chứng (trạng thái thư mục/ổ đĩa, thời gian từ lúc copy xong, có thư mục
                    // `video_input_trash_*` không => chính app đổi tên để xoá) để lần sau KẾT LUẬN được nguyên nhân
                    // thay vì phỏng đoán. (2) Tự copy lại từ Uri gốc (nếu còn quyền đọc), tối đa 2 lần/file/phiên
                    // để không vòng lặp copy-mất-copy nếu máy liên tục xoá.
                    if (!file.exists() || file.length() <= 0L) {
                        val sinceCopyMs = copyFinishedAtMs[file.absolutePath]?.let { android.os.SystemClock.uptimeMillis() - it }
                        DebugLog.log(
                            this@VideoToolsActivity, "VideoToolsActivity",
                            "⚠️ FILE NGUỒN KHÔNG CÒN (${error.errorCodeName}): " +
                                (if (sinceCopyMs != null) "${sinceCopyMs / 1000}s sau khi copy xong" else "không rõ thời điểm copy") +
                                "; pendingImports=$pendingImports, recovering=$recovering, isDestroyed=$isDestroyed; " +
                                FileUtils.describeInputState(this@VideoToolsActivity, file.absolutePath)
                        )
                        val tries = autoRecoveries[file.absolutePath] ?: 0
                        if (tries < 2) {
                            autoRecoveries[file.absolutePath] = tries + 1
                            recoverMissingInput(file.absolutePath, thenRun = false)
                        } else {
                            Toast.makeText(
                                this@VideoToolsActivity,
                                "File video liên tục bị mất khỏi bộ nhớ tạm của app (đã tự khôi phục $tries lần). Kiểm tra dung lượng trống của máy hoặc app dọn dẹp bộ nhớ, rồi chọn lại video.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        return
                    }
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastErrorToastAtMs > 4000L) { // chống spam Toast khi lỗi lặp theo từng lần seek
                        lastErrorToastAtMs = now
                        Toast.makeText(
                            this@VideoToolsActivity,
                            "Preview gặp lỗi đọc file ở vị trí này (file có thể hỏng/ghép thô ở đoạn đó). Kéo sang vị trí khác để preview tự thử lại — việc cắt vẫn dùng được bình thường.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            })
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exoPlayer.playWhenReady = false
            exoPlayer.prepare()
            DebugLog.log(
                this@VideoToolsActivity, "VideoToolsActivity",
                "loadPreview — phần chạy trên LUỒNG CHÍNH tới lúc prepare() mất ${android.os.SystemClock.uptimeMillis() - loadPreviewStartedAt}ms (thời lượng ${if (preloadedDurationSec != null) "đọc sẵn ở nền" else "đọc đồng bộ"})"
            )
            // [THÊM 25/10/2026] Ghi định dạng container THẬT của file (không tin đuôi .mp4): file ráp thô từ HLS
            // thường là MPEG-TS đội lốt .mp4 (format_name=mpegts, start_time lệch 0, không có chỉ mục seek) —
            // ExoPlayer phải seek bằng dò nhị phân theo PCR nên dễ ném PARSING_CONTAINER_MALFORMED ở vùng timestamp
            // gián đoạn. Chạy nền, chỉ đọc header, chỉ để ghi log.
            lifecycleScope.launch {
                val probeInfo = withContext(Dispatchers.IO) {
                    try {
                        val s = com.arthenica.ffmpegkit.FFprobeKit.execute(
                            "-v error -show_entries format=format_name,start_time,duration,bit_rate:stream=index,codec_type,codec_name,width,height,avg_frame_rate,start_time -of compact=p=0:nk=0 \"${file.absolutePath}\""
                        )
                        (s.allLogsAsString ?: "(ffprobe không trả kết quả)").trim().replace("\n", " ; ")
                    } catch (e: Throwable) {
                        "ffprobe lỗi: ${e.message}"
                    }
                }
                DebugLog.log(
                    this@VideoToolsActivity, "VideoToolsActivity",
                    "Nạp preview — file=${file.name} (${file.length()} byte); ffprobe: $probeInfo"
                )
            }
            // [SỬA 02/09/2026] BỎ HẲN controller mặc định của Media3 (use_controller=false
            // trong layout) — controller đó đi kèm 1 thanh tiến độ (TimeBar) nội bộ. Thay
            // vào đó: tự làm 1 nút play/pause riêng (`btnPlayPause`, ảnh hệ thống Android có
            // sẵn, không cần drawable riêng) — bấm vào khung preview để hiện/ẩn nút, bấm vào
            // nút để play/pause thật.
            // [GHI CHÚ THÊM — phiên sửa scrubbing mode]: người dùng báo "thanh trượt trên
            // preview player không phản ứng nữa" — ĐÃ KIỂM TRA layout
            // (activity_video_tools.xml): `use_controller="false"` nghĩa là KHÔNG có TimeBar
            // nội bộ nào tồn tại trên màn hình này cả — RangeSlider (ngay bên dưới khung
            // preview) là thanh kéo DUY NHẤT. Nhiều khả năng "thanh trượt trên preview
            // player" người dùng nói tới CHÍNH LÀ RangeSlider (nó nằm sát preview) — nên bản
            // sửa scrubbing mode áp cho RangeSlider ở dưới đây nhắm đúng vào phản hồi này.
            // Nếu build lại rồi vẫn thấy có 1 thanh trượt KHÁC không phản ứng (không phải
            // RangeSlider) thì đó là điều CHƯA ai xác nhận lại — cần chụp màn hình rõ chỗ đó
            // để xác định chính xác, đừng đoán tiếp.
            // (Media3 >= 1.8.0 cũng hỗ trợ scrubbing mode ngay trong TimeBar mặc định của
            // PlayerControlView qua `time_bar_scrubbing_enabled="true"` — nhưng dùng được nó
            // cũng cần đúng bản media3 đó, tức là dính đúng bức tường compileSdk 36 / AGP 9.x
            // đã gặp và lùi lại ở trên. Nên hiện tại việc bật lại controller mặc định KHÔNG
            // khả thi hơn gì so với lúc quyết định bỏ nó ở mục 02/09/2026 — giữ nguyên quyết
            // định "chỉ 1 chỗ kéo-thả duy nhất" (RangeSlider) cho tới khi có đợt nâng cấp
            // AGP/Kotlin riêng, làm cẩn thận, không lồng vào bug fix nhỏ thế này.)
            binding.playerView.player = exoPlayer
            player = exoPlayer

            fun updatePlayPauseIcon() {
                binding.btnPlayPause.setImageResource(
                    if (exoPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
            // [THÊM 04/09/2026] Cập nhật chữ "hiện tại / tổng" trong khung preview — xem giải
            // thích đầy đủ ở khai báo layout (txtCurrentPreviewTime). currentSec lấy từ NGOÀI
            // truyền vào (không tự đọc exoPlayer.currentPosition ở đây) vì lúc đang kéo,
            // exoPlayer.currentPosition có thể chưa kịp cập nhật đúng bằng giá trị ngón tay
            // mới nhất (đang xử lý CLOSEST_SYNC) — dùng thẳng giá trị slider/nút bấm cho khớp
            // với những gì người dùng đang thao tác, không lệch 1 nhịp.
            fun updateCurrentTimeText(currentSec: Float) {
                binding.txtCurrentPreviewTime.text =
                    "${secondsToHms(currentSec.coerceIn(0f, videoDurationSec))} / ${secondsToHms(videoDurationSec)}"
            }
            updateCurrentTimeText(0f) // giá trị ban đầu khi vừa nạp preview
            // Giữ vị trí seek trong khoảng phát được: kéo thumb cuối tới đúng valueTo (= thời lượng) mà
            // seek thẳng tới đó có thể đẩy player sang STATE_ENDED (không còn khung hình để vẽ).
            fun clampPlayableMs(ms: Long): Long {
                val d = exoPlayer.duration
                return if (d != androidx.media3.common.C.TIME_UNSET && d > 0L) {
                    ms.coerceIn(0L, (d - 200L).coerceAtLeast(0L))
                } else ms.coerceAtLeast(0L)
            }
            // [THÊM 25/10/2026] Player đã CHẾT (onPlayerError -> STATE_IDLE, playerError != null) thì seekTo()
            // một mình KHÔNG làm gì cả — phải prepare() lại. Gọi trước MỌI seekTo do người dùng gây ra: kéo
            // sang vị trí khác là preview tự sống lại (nếu vị trí đó đọc được); nếu vùng đó hỏng thật thì lỗi
            // lặp lại ở đúng vùng đó (đã ghi log) và preview lại sống khi kéo ra khỏi vùng hỏng.
            fun revivePlayerIfDead() {
                if (exoPlayer.playerError != null || exoPlayer.playbackState == androidx.media3.common.Player.STATE_IDLE) {
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "Player đang chết (state=${exoPlayer.playbackState}, lỗi=${exoPlayer.playerError?.errorCodeName}) — prepare() lại trước khi seek"
                    )
                    exoPlayer.prepare()
                }
            }
            val scrub = ScrubSeekController(
                handler = android.os.Handler(android.os.Looper.getMainLooper()),
                doSeek = { ms ->
                    revivePlayerIfDead()
                    exoPlayer.seekTo(clampPlayableMs(ms))
                    updateCurrentTimeText(ms / 1000f)
                }
            )
            scrubController = scrub
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    // READY = seek đang bay đã ra khung hình (xem ScrubSeekController).
                    if (playbackState == androidx.media3.common.Player.STATE_READY) scrub.onSeekSettled()
                }
                override fun onRenderedFirstFrame() { scrub.noteFrameRendered() }
            })
            // [THÊM 04/09/2026, sửa bug "kéo nút 2 (điểm cuối) rồi bấm nút tua thì lại nhảy
            // về nút 1 (điểm đầu)"] Nhớ THUMB NÀO (đầu hay cuối) người dùng vừa thao tác gần
            // nhất trên RangeSlider — xem chỗ gán giá trị này trong addOnChangeListener bên
            // dưới để rõ cách suy luận. Phải khai báo Ở ĐÂY (trước các nút tua bên dưới) vì
            // biến local trong Kotlin phải khai báo trước mới dùng được trong closure, dù
            // closure đó chỉ thực sự chạy sau này.
            var lastActiveThumbIsEnd = false
            // Cập nhật đúng thumb đang thao tác (không phải lúc nào cũng thumb đầu — đó
            // chính là bug vừa báo) rồi đồng bộ lại chữ thời gian. Dùng chung cho cả 4 nút
            // tua (5s/15s/1s) bên dưới để khỏi lặp lại 4 lần.
            // [THÊM 06/09/2026, phòng ngừa thêm 1 khả năng gây ANR] 4 nút tua (5s/15s/1s) gọi
            // seekTo() KHÔNG qua ticker/hàng đợi nào — nếu bấm rất nhanh liên tục (như lúc
            // đang test kỹ), mỗi lần bấm là 1 lệnh seekTo() CHÍNH XÁC (SeekParameters.EXACT,
            // đã trả lại sau khi thả tay khỏi RangeSlider) bắn ngay, không chờ lệnh trước xong
            // — với video dài/GOP thưa, dồn dập vài lệnh EXACT liên tiếp CÓ THỂ là 1 nguồn
            // ANR khác chưa loại trừ được. Thêm 1 khoảng cách tối thiểu 150ms giữa 2 lần bấm
            // được chấp nhận — bấm nhanh hơn thì bỏ qua lần bấm đó (không xếp hàng, không dồn
            // lại) thay vì cố xử lý hết. Đủ nhanh với thao tác bấm tay thật, không cần tinh vi
            // hơn cho use-case nút bấm rời rạc (khác hẳn kéo liên tục cần ticker).
            // [THÊM 04/09/2026, ĐANG NGHI VẤN LÀ NGUYÊN NHÂN THẬT CỦA ANR] Biến này lưu lại
            // coroutine (Job) của lần tìm-keyframe GẦN NHẤT — xem lý do ngay tại chỗ dùng nó
            // trong onStopTrackingTouch bên dưới. [DỜI LÊN ĐÂY 17/09/2026] để
            // seekAndSyncActiveThumb() (nút tua 1s/5s/15s, ngay dưới đây) DÙNG CHUNG được
            // biến này với onStopTrackingTouch — đảm bảo tại 1 thời điểm chỉ có TỐI ĐA 1
            // lần đọc keyframe đang chạy, DÙ đến từ nút tua hay kéo slider, bấm/kéo xen kẽ
            // nhanh giữa 2 cách vẫn không mở nhiều MediaExtractor cùng lúc (xem lý do gốc:
            // nguy cơ ANR/rò tài nguyên khi mở nhiều MediaExtractor chồng lấn).
            // (keyframeSnapJob giờ là thuộc tính của lớp — khai báo ở đầu class, 25/10/2026)
            // [DỜI LÊN ĐÂY 17/09/2026, cùng lý do với keyframeSnapJob] Trước đây khai báo
            // sau các nút tua — seekAndSyncActiveThumb() (ngay dưới) giờ CŨNG cần dùng biến
            // này (để tắt việc addOnChangeListener hiểu nhầm lần set slider.values DO CODE
            // gây ra là do người dùng kéo tay), nên phải khai báo TRƯỚC nó.
            var syncingFromCode = false
            var lastButtonSeekAtMs = 0L
            fun seekAndSyncActiveThumb(targetMs: Long) {
                val now = System.currentTimeMillis()
                if (now - lastButtonSeekAtMs < 150L) return
                // [SỬA LẠI 17/09/2026 — LỖI THẬT do chính bản fix 17/09/2026 trước đó gây
                // ra, người dùng báo đúng: nút tua "loạn xì ngầu", điểm cắt lệch NHIỀU
                // HƠN TRƯỚC] Nguyên nhân: 4 nút tua đọc `exoPlayer.currentPosition` NGAY
                // TẠI THỜI ĐIỂM BẤM để tính mục tiêu tiếp theo — nhưng bản snap-khung-khoá
                // thêm ở trên làm việc CẬP NHẬT VỊ TRÍ THẬT trở thành BẤT ĐỒNG BỘ (phải
                // đọc file trước, mất vài chục-vài trăm ms). Nếu bấm nút LẦN 2 TRƯỚC KHI
                // lần 1 kịp cập nhật xong `exoPlayer`/slider, lần 2 đọc phải
                // `currentPosition` CŨ (CHƯA snap) để tính tiếp -> ra đúng 2 triệu chứng:
                // có lúc 2 lần bấm tính RA CÙNG 1 MỤC TIÊU (cảm giác như không hoạt động —
                // job trước bị job sau huỷ, kết quả không đổi), có lúc dồn nhiều lần bấm
                // liên tiếp vào cùng 1 lần cập nhật rồi giật 1 phát NHIỀU GIÂY. Vị trí
                // cuối cùng người dùng dừng lại (để rồi bấm "Thêm đoạn"/Run) vì vậy SAI
                // LỆCH nhiều hơn ý định thật — đây chính là lý do độ lệch khi cắt tăng lên
                // so với trước khi có bản fix này, KHÔNG phải lỗi ở phần snap trước lúc
                // gọi FFmpeg (phần đó vẫn cắt đúng theo giá trị nó NHẬN ĐƯỢC — vấn đề là
                // giá trị nhận được đã sai từ trước).
                //
                // Cách sửa: CHẶN HẲN, không cho bấm tiếp trong lúc còn 1 lần snap TRƯỚC ĐÓ
                // chưa xong (`keyframeSnapJob?.isActive == true`) — thay vì cố đoán/suy ra
                // vị trí "lẽ ra phải là" từ nhiều biến riêng dễ lệch pha nhau. Đảm bảo khi
                // được phép bấm tiếp, `exoPlayer`/slider CHẮC CHẮN đã ở đúng giá trị mới
                // nhất, không còn đọc nhầm giá trị cũ. Đánh đổi: bấm dồn dập sẽ có phần
                // bị "nuốt" (không phải mỗi lần bấm đều có hiệu lực) thay vì chạy loạn —
                // ưu tiên ĐÚNG hơn PHẢN HỒI TỨC THÌ.
                if (keyframeSnapJob?.isActive == true) return
                lastButtonSeekAtMs = now
                val targetSec = targetMs / 1000f
                val values = binding.rangeSlider.values
                // [FIX 17/09/2026 — LỖI THẬT người dùng báo, và báo ĐÚNG là lỗi hay gặp
                // nhất qua đúng đường này] Trước đây set thẳng targetSec vào slider —
                // KHÔNG qua snap khung khoá nào cả, khác hẳn đường kéo slider (đã snap từ
                // 01/09/2026). Vì "-c copy" chỉ ĐIỂM BẮT ĐẦU cần trùng khung khoá (điểm
                // KẾT THÚC không có ràng buộc — xem giải thích gốc ở onStopTrackingTouch
                // bên dưới), CHỈ áp snap khi đang định vị thumb ĐẦU (!lastActiveThumbIsEnd).
                // [SỬA LẠI 16/11/2026 — LỖI THẬT người dùng báo: "+1/-1 xem trước khi nhấn vào thì nó nhảy hơn 1"]
                // Log thật (81 lần bấm ±1S, video khung khoá cách nhau 5–8 giây): "+1S" ĐỨNG YÊN 47/47 lần
                // (mục tiêu = vị trí + 1s bị snap ngược về ĐÚNG khung khoá cũ) và "-1S" nhảy nguyên 1 khoảng
                // khung khoá (≈5.0s / ≈8.34s) 34/34 lần — không lần nào đi 1s. Không phải lỗi tính toán: đúng là
                // bản snap 17/09/2026 (bên trên) chạy đúng thiết kế trên video khung khoá thưa.
                // Giờ nút tua đi ĐÚNG bước (thumb đầu + preview), KHÔNG snap. Đánh đổi (đã biết): điểm bắt
                // đầu hiển thị có thể KHÁC điểm cắt thật vì `-c copy` chỉ bắt đầu được ở khung khoá — để KHÔNG tái
                // phát lỗi 17/09/2026 ("file lệch đằng trước mà không ai báo"), dòng chữ dưới nút tua
                // (scheduleRealStartHint) luôn hiện ĐIỂM CẮT THẬT + độ lệch; "Thêm đoạn" vẫn ghi mốc đã snap
                // (addSelectedRangeToList) và Chạy vẫn snap lần chốt trước khi gọi FFmpeg. Không còn việc async
                // ở đường này nên cũng không còn khả năng 2 lần bấm đọc nhầm vị trí cũ (lỗi 17/09/2026).
                if (!lastActiveThumbIsEnd && values.size >= 2) {
                    val currentEnd = values.last()
                    val safeMax = (currentEnd - 0.1f).coerceAtLeast(0f)
                    val exactStart = targetSec.coerceIn(0f, safeMax)
                    revivePlayerIfDead()
                    exoPlayer.seekTo(clampPlayableMs((exactStart * 1000).toLong()))
                    updateCurrentTimeText(exactStart)
                    syncingFromCode = true
                    binding.rangeSlider.values = listOf(exactStart, currentEnd)
                    binding.edtStartSec.setText(secondsToHms(exactStart))
                    syncingFromCode = false
                    scheduleRealStartHint(exactStart, 250L) // chờ 250ms: bấm dồn chỉ đọc khung khoá 1 lần ở lần bấm cuối
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "seekAndSyncActiveThumb (đúng bước, không snap) — targetSec=$targetSec, start=$exactStart, values sau=${binding.rangeSlider.values}"
                    )
                } else {
                    revivePlayerIfDead()
                    exoPlayer.seekTo(targetMs)
                    updateCurrentTimeText(targetSec)
                    if (values.size >= 2) {
                        binding.rangeSlider.values = listOf(values.first(), targetSec.coerceIn(values.first(), videoDurationSec))
                    }
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "seekAndSyncActiveThumb — targetSec=$targetSec, lastActiveThumbIsEnd=$lastActiveThumbIsEnd, values sau=${binding.rangeSlider.values}"
                    )
                }
            }
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayPauseIcon() }
            })
            binding.playerView.setOnClickListener {
                // Bấm vào khung preview -> hiện/ẩn CẢ HÀNG nút play/pause + tua lùi/tới cùng
                // lúc (giống hành vi controller mặc định trước đây: bấm vào preview mới thấy
                // nút, bấm ra ngoài thì ẩn). Chữ thời gian KHÔNG nằm trong nhóm này — hiện
                // liên tục, không cần bấm mới thấy (giống TimeBar cũ).
                binding.groupPlaybackButtons.visibility =
                    if (binding.groupPlaybackButtons.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                if (binding.groupPlaybackButtons.visibility == View.VISIBLE) updatePlayPauseIcon()
            }
            binding.btnPlayPause.setOnClickListener {
                try {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            // [THÊM 04/09/2026 — khôi phục lại, xem giải thích ở layout XML] 2 nút này TỪNG
            // có sẵn trong controller mặc định của Media3 (rewind_increment=5000,
            // fastforward_increment=15000) — bị mất khi gỡ hẳn controller ở 02/09/2026, không
            // ai chủ ý bỏ. Cập nhật cả RangeSlider (để không bị lệch với vị trí preview thật)
            // lẫn chữ thời gian sau khi tua.
            binding.btnRewind5s.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition - 5000L).coerceAtLeast(0L))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            binding.btnForward15s.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition + 15000L).coerceAtMost((videoDurationSec * 1000).toLong()))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            // [THÊM 04/09/2026] Cặp nút -1s/+1s NGOÀI khung preview — xem giải thích ở layout
            // XML (chỗ khai báo btnStep1sBack/btnStep1sForward). Dùng chung logic với 2 nút
            // tua trong preview ở trên, chỉ khác bước nhảy (1000ms thay vì 5000/15000ms).
            binding.btnStep1sBack.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition - 1000L).coerceAtLeast(0L))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            binding.btnStep1sForward.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition + 1000L).coerceAtMost((videoDurationSec * 1000).toLong()))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }

            // (syncingFromCode đã khai báo phía trên, trước seekAndSyncActiveThumb — dùng
            // chung, không khai báo lại ở đây nữa, xem 17/09/2026)
            // (Số liệu mỗi lần kéo — số seek bắn, số lần player báo xong, độ trễ — do
            // ScrubSeekController tự đếm và ghi ở onStopTrackingTouch bên dưới, 25/10/2026.)
            // (lastActiveThumbIsEnd đã khai báo phía trên, trước các nút tua — dùng lại ở
            // đây, không khai báo lần 2)

            // [SỬA 25/10/2026 — "khá lag khi kéo nút tua preview"] Trước đây MỖI sự kiện kéo (gần như mỗi pixel,
            // 60–120 lần/giây) gọi setText() cho CẢ 2 ô giờ dù chữ không đổi — mỗi lần dựng lại Editable + Layout
            // + gọi TextWatcher trên luồng chính, cộng với seek/UI khác nên khung hình bị rớt. Giờ: chỉ setText ô
            // nào THỰC SỰ đổi chữ, và khi đang kéo thì tối đa ~20 lần/giây (giá trị cuối luôn được đồng bộ lại ở
            // onStopTrackingTouch qua syncTrimTexts()).
            var lastTrimTextAtMs = 0L
            fun syncTrimTexts(values: List<Float>) {
                if (values.size < 2) return
                val startText = secondsToHms(values.first())
                val endText = secondsToHms(values.last())
                val wasSyncing = syncingFromCode
                syncingFromCode = true
                if (binding.edtStartSec.text.toString() != startText) binding.edtStartSec.setText(startText)
                if (binding.edtEndSec.text.toString() != endText) binding.edtEndSec.setText(endText)
                syncingFromCode = wasSyncing
            }
            binding.rangeSlider.addOnChangeListener { slider, value, fromUser ->
                if (syncingFromCode) return@addOnChangeListener
                val values = slider.values
                if (values.size >= 2) {
                    val nowMs = android.os.SystemClock.uptimeMillis()
                    if (!fromUser || nowMs - lastTrimTextAtMs >= 50L) {
                        lastTrimTextAtMs = nowMs
                        syncTrimTexts(values)
                    }
                    if (fromUser) {
                        // CHỈ ghi lại vị trí mới nhất của NÚT VỪA KÉO (value), không phải
                        // luôn luôn là điểm cuối — đây là lỗi khiến kéo nút đầu không xem
                        // trước được, chỉ kéo nút sau mới thấy hình (đã sửa từ trước).
                        // KHÔNG gọi seekTo() trực tiếp ở đây nữa — addOnChangeListener bắn ra
                        // quá nhiều lần trong 1 lần kéo (gần như mỗi pixel), gọi seekTo()
                        // ngay tại đây là NGUYÊN NHÂN GỐC của bug này. Việc bắn seekTo() thật
                        // sự do ScrubSeekController (seek vòng kín, xem doc comment của lớp đó)
                        // đảm nhiệm — ở đây chỉ báo vị trí ngón tay mới nhất cho nó.
                        scrub.update((value * 1000f).toLong())
                        lastActiveThumbIsEnd = (value == values.last())
                        // Seek sắp tới đến từ NGOÀI khung preview (kéo slider) -> ẩn CẢ HÀNG
                        // nút (không che khung hình). BUG ĐÃ SỬA (04/09/2026, báo "nút play
                        // pause bị nuốt"): trước đây dòng này set riêng
                        // `btnPlayPause.visibility = GONE` — nhưng từ khi btnPlayPause nằm
                        // TRONG `groupPlaybackButtons` (thêm cùng đợt với nút tua 5s/15s),
                        // set visibility RIÊNG cho nó sẽ làm nó bị "kẹt ẩn" mãi mãi độc lập
                        // với trạng thái của cả nhóm — lần đầu kéo RangeSlider là nút play/
                        // pause biến mất vĩnh viễn (dù bấm vào preview vẫn hiện lại được 2 nút
                        // tua vì chúng không bị đụng tới). Phải ẩn đúng View cha
                        // (groupPlaybackButtons), không phải từng nút con riêng lẻ.
                        binding.groupPlaybackButtons.visibility = View.GONE
                    }
                }
            }

            // QUAN TRỌNG: khi cắt bằng "-c copy" (không encode lại), FFmpeg BẮT BUỘC bắt
            // đầu file output đúng tại 1 khung hình khoá — không thể cắt giữa chừng vì
            // không giải mã lại được. Trong lúc kéo, preview tua chính xác tới đúng giây
            // bạn thả tay, NHƯNG video output thật có thể lùi về khung hình khoá gần nhất
            // trước đó -> đây là nguyên nhân số giây/preview "khớp lúc xem nhưng ra file
            // lại lệch". Để loại bỏ hẳn sự lệch này: ngay khi THẢ TAY khỏi slider, làm
            // tròn điểm bắt đầu về ĐÚNG khung hình khoá đó luôn (cùng cơ chế FFmpeg dùng
            // bên trong) — từ lúc này, số giây + khung hình xem trước hiển thị chính là
            // những gì sẽ có trong file output, không còn khác biệt.
            // (keyframeSnapJob đã khai báo phía trên, trước seekAndSyncActiveThumb — dùng
            // chung với đường nút tua, không khai báo lại ở đây nữa, xem 17/09/2026)
            binding.rangeSlider.addOnSliderTouchListener(object :
                com.google.android.material.slider.RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {
                    // Seek lúc kéo giờ do ScrubSeekController điều phối VÒNG KÍN (xem doc comment
                    // của lớp đó) — thay cho ticker 100ms cũ.
                    // SeekParameters.CLOSEST_SYNC (từ 04/09/2026, GIỮ NGUYÊN): lúc đang kéo nhảy thẳng
                    // tới khung khoá gần nhất (không decode tuần tự) cho nhanh; trả EXACT khi thả tay.
                    try {
                        exoPlayer.setSeekParameters(SeekParameters.CLOSEST_SYNC)
                    } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                    scrub.begin()
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "RangeSlider.onStartTrackingTouch — seek vòng kín + CLOSEST_SYNC, playerState=${exoPlayer.playbackState}, values=${slider.values}"
                    )
                }
                override fun onStopTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {
                    // Ghi SỐ LIỆU THẬT của lần kéo vừa xong. Cách đọc nhanh:
                    //  - "xong (READY)" ≈ "bắn" và "khung hình vẽ" > 0  => player vẽ kịp, preview phải chạy theo.
                    //  - "xong" = 0 và "timeout" > 0                      => player KHÔNG BAO GIỜ về READY sau seek
                    //    (lỗi ở tầng player/decoder, không phải ở nhịp seek) — gửi dòng này + dòng
                    //    "ExoPlayer onPlayerError" (nếu có) để chẩn đoán.
                    //  - "trễ tối đa" lớn (hàng trăm ms) => đúng cơ chế đã suy ra: ticker cũ 100ms sẽ đói khung hình.
                    val stats = scrub.end()
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "RangeSlider.onStopTrackingTouch — $stats; playerState=${exoPlayer.playbackState}, pos=${exoPlayer.currentPosition}ms, values=${slider.values}, " +
                            "fileNguồn tồn tại=${file.exists()} (${file.length()} byte)" // [THÊM 17/11/2026] preview đứng + file mất => thấy ngay ở dòng này
                    )
                    try {
                        exoPlayer.setSeekParameters(SeekParameters.EXACT) // trả lại chính xác tuyệt đối cho lần seek chốt cuối cùng bên dưới
                    } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                    val values = slider.values
                    if (values.size < 2) return
                    syncTrimTexts(values) // giá trị cuối cùng luôn đúng dù lúc kéo chữ bị giới hạn tần suất cập nhật
                    // [SỬA QUAN TRỌNG 06/09/2026, GIỮ NGUYÊN Ý] Chỉ ĐIỂM BẮT ĐẦU cần trùng khung khoá khi
                    // cắt "-c copy"; điểm KẾT THÚC không có ràng buộc đó. Vừa kéo thumb CUỐI thì KHÔNG
                    // snap và KHÔNG ép player về thumb đầu (đó là lỗi "nút tua sync nhầm thumb").
                    if (!lastActiveThumbIsEnd) {
                        val requestedStart = values.first().toDouble()
                        val currentEnd = values.last()
                        val safeMax = (currentEnd - 0.1f).coerceAtLeast(slider.valueFrom)
                        // [THÊM 17/11/2026] "Cắt chính xác" BẬT (chỉ chế độ Cắt/Tách): KHÔNG nhích thumb về khung khoá nữa —
                        // file cắt ra sẽ bắt đầu đúng chỗ người dùng chọn (SmartCut), nên preview dừng đúng chỗ đó.
                        // Khung khoá trước đó chỉ còn là điểm QUAY VỀ khi cắt chính xác không làm được (đọc lại lúc bấm Chạy).
                        if (binding.chkExactCut.isChecked && currentMode == VideoToolMode.TRIM_SPLIT) {
                            keyframeSnapJob?.cancel()
                            keyframeSnapJob = null
                            val exactStart = requestedStart.toFloat().coerceIn(slider.valueFrom, safeMax)
                            try {
                                revivePlayerIfDead()
                                exoPlayer.seekTo(clampPlayableMs((exactStart * 1000).toLong()))
                                updateCurrentTimeText(exactStart)
                                binding.groupPlaybackButtons.visibility = View.GONE
                            } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                            scheduleRealStartHint(exactStart)
                            return
                        }
                        // Đọc khung khoá ở thread nền, tối đa 1 job tại 1 thời điểm (vá ANR 04/09/2026, giữ nguyên).
                        keyframeSnapJob?.cancel()
                        keyframeSnapJob = lifecycleScope.launch {
                            val snappedStart = withContext(Dispatchers.IO) {
                                FileUtils.findPrecedingKeyframeSec(file.absolutePath, requestedStart)
                            }.toFloat().coerceIn(slider.valueFrom, safeMax)
                            // [THÊM 25/10/2026] Nếu người dùng ĐÃ BẮT ĐẦU kéo lần mới trong lúc job đọc file
                            // còn chạy (log thật: có lần chỉ cách 0.6s), TUYỆT ĐỐI không ghi đè
                            // slider.values / không seek giữa chừng lần kéo mới — làm vậy sẽ giật thumb
                            // dưới tay người dùng và tranh seek với scrub. Điểm cắt thật vẫn đúng nhờ
                            // snapToPrecedingKeyframe() ở chốt cuối ngay trước khi gọi FFmpeg.
                            if (scrub.isActive) return@launch
                            if (kotlin.math.abs(snappedStart - requestedStart.toFloat()) > 0.03f) {
                                syncingFromCode = true
                                slider.values = listOf(snappedStart, currentEnd)
                                binding.edtStartSec.setText(secondsToHms(snappedStart))
                                syncingFromCode = false
                            }
                            // [SỬA 25/10/2026] LUÔN seek chốt tới điểm đầu (trước đây CHỈ seek khi vừa
                            // snap dịch > 0.03s): với seek vòng kín, vị trí ngón tay cuối cùng có thể
                            // CHƯA kịp được bắn tới player trước lúc thả tay — không seek chốt thì
                            // preview có thể đứng ở 1 vị trí cũ hơn thumb.
                            try {
                                revivePlayerIfDead()
                                exoPlayer.seekTo(clampPlayableMs((snappedStart * 1000).toLong()))
                                updateCurrentTimeText(snappedStart)
                                binding.groupPlaybackButtons.visibility = View.GONE // xem giải thích lỗi "nút play/pause bị nuốt" ở addOnChangeListener phía trên
                            } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                            scheduleRealStartHint(snappedStart) // [16/11/2026] thả tay đã snap => dòng chữ xác nhận "trùng khung khoá"
                        }
                    } else {
                        // Vừa kéo thumb CUỐI — không đụng thumb đầu. [THÊM 25/10/2026] Seek chốt CHÍNH XÁC
                        // tới đúng thumb cuối (điểm kết thúc không bị ràng buộc khung khoá) để preview
                        // dừng đúng ở khung hình người dùng vừa chọn, kể cả khi vị trí cuối cùng chưa
                        // kịp bắn qua vòng kín. (Nút tua đọc exoPlayer.currentPosition sau đó sẽ đúng thumb cuối.)
                        try {
                            revivePlayerIfDead()
                            exoPlayer.seekTo(clampPlayableMs((values.last() * 1000).toLong()))
                            updateCurrentTimeText(values.last())
                        } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                        binding.groupPlaybackButtons.visibility = View.GONE
                    }
                }
            })

            val textWatcher = object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    if (syncingFromCode) return
                    val start = hmsToSeconds(binding.edtStartSec.text.toString()) ?: return
                    val end = hmsToSeconds(binding.edtEndSec.text.toString()) ?: return
                    // Ép giới hạn an toàn trong [valueFrom, valueTo] — RangeSlider sẽ
                    // âm thầm bỏ qua (không di chuyển) nếu giá trị nằm ngoài khoảng
                    // hoặc start >= end, đây là nguyên nhân "gõ số nhưng slider không nhích".
                    val safeStart = start.coerceIn(0f, videoDurationSec)
                    val safeEnd = end.coerceIn(0f, videoDurationSec)
                    if (safeStart >= safeEnd) return
                    syncingFromCode = true
                    try {
                        binding.rangeSlider.values = listOf(safeStart, safeEnd)
                        binding.rangeSlider.invalidate()
                    } catch (e: Exception) { /* giá trị tạm thời không hợp lệ khi đang gõ dở, bỏ qua */ }
                    syncingFromCode = false
                    scheduleRealStartHint(safeStart, 600L) // [16/11/2026] gõ tay: chờ 600ms sau lần gõ cuối rồi mới đọc khung khoá
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            }
            trimTextWatcher = textWatcher
            binding.edtStartSec.addTextChangedListener(textWatcher)
            binding.edtEndSec.addTextChangedListener(textWatcher)
        } catch (e: Exception) {
            Toast.makeText(this, "Không nạp được video xem trước: ${e.message}. Vẫn có thể nhập giờ:phút:giây thủ công.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addSelectedRangeToList() {
        val values = binding.rangeSlider.values
        if (values.size < 2) return
        val end = values.last()
        val requestedStart = values.first().toDouble()
        val currentFile = selectedFilePaths.firstOrNull()
        // Làm tròn lần cuối về khung hình khoá gần nhất trước khi ghi vào danh sách —
        // phòng trường hợp giá trị đang có chưa được làm tròn (vd người dùng gõ tay số
        // giây rồi bấm "Thêm đoạn" luôn, chưa từng chạm/thả slider để kích hoạt làm tròn
        // ở addOnSliderTouchListener). Nhờ vậy con số ghi vào danh sách LUÔN khớp đúng
        // với điểm bắt đầu thật của file output (xem giải thích chi tiết ở loadPreview()).
        // Đọc file (MediaExtractor) tốn thời gian -> đẩy ra thread nền, tránh khựng UI
        // ngay lúc bấm nút (cùng nguyên nhân/cách sửa như addOnSliderTouchListener).
        val exactMode = binding.chkExactCut.isChecked && currentMode == VideoToolMode.TRIM_SPLIT // [17/11/2026] không snap khi cắt chính xác
        lifecycleScope.launch {
            val start = if (currentFile != null && !exactMode) {
                withContext(Dispatchers.IO) {
                    FileUtils.findPrecedingKeyframeSec(currentFile, requestedStart)
                }.toFloat()
            } else requestedStart.toFloat()
            val currentText = binding.edtSegments.text.toString()
            // Vẫn lưu nội bộ theo giây (để lệnh FFmpeg dùng), chỉ hiển thị cho người dùng theo giờ:phút:giây
            // FIX QUAN TRỌNG: "%.1f".format() không có Locale sẽ dùng Locale mặc định của máy.
            // Ở Locale Tiếng Việt (vi_VN), dấu thập phân là DẤU PHẨY (vd 10.5 -> "10,5"), khiến
            // dòng ghi ra thành "10,5,20,3" thay vì "10.5,20.3" — dấu "," ngăn cách giây bị LẪN
            // với dấu "," thập phân. parseSegments() tách theo "," sẽ ra 4 phần thay vì 2, dòng
            // bị coi là KHÔNG HỢP LỆ và bị bỏ qua -> segments rỗng -> app tưởng người dùng
            // "không chọn đoạn nào" -> tự động tách/lấy audio TOÀN BỘ video dù đã chọn đoạn.
            // Đây chính là nguyên nhân lỗi "lấy audio toàn bộ video khi chỉ muốn lấy vài đoạn"
            // trên máy để Locale Tiếng Việt. Ép Locale.US để luôn ra dấu chấm.
            // [SỬA 25/10/2026 — LỖI "cắt ra trôi về TRƯỚC chỗ cắt vài giây"] TRƯỚC ĐÂY ghi "%.1f" (làm tròn 0.1s):
            // khung khoá thật 1123.222 bị ghi thành "1123.2" (THẤP hơn khung khoá 22ms) => FFmpeg ("-ss" thấp hơn
            // khung khoá dù 0.1ms đã đủ) và snap lần 2 đều lùi về khung khoá TRƯỚC, cách vài giây. Đo bằng
            // FFmpeg thật: -ss 63.2 cho khung khoá 63.233 => output bắt đầu ở 55.9. Giữ 3 chữ số (mili-giây);
            // sai số còn lại (<0.5ms) đã được hấp thụ bởi dung sai snap + đệm "-ss" (xem
            // FileUtils.findPrecedingKeyframeSec và VideoEngine.copySeekArg).
            val newLine = "${"%.3f".format(java.util.Locale.US, start)},${"%.3f".format(java.util.Locale.US, end)}"
            binding.edtSegments.setText(if (currentText.isBlank()) newLine else "$currentText\n$newLine")
        }
    }

    private fun releasePlayer() {
        // [SỬA 25/10/2026] Dừng điều phối seek + huỷ job đọc keyframe TRƯỚC khi release player, để
        // không còn callback nào chạm vào player đã release / video cũ.
        scrubController?.end()
        scrubController = null
        keyframeSnapJob?.cancel()
        keyframeSnapJob = null
        realStartHintJob?.cancel() // [16/11/2026]
        realStartHintJob = null
        setRealStartHint(null)
        player?.release()
        player = null
    }

    private val hintMutex = Mutex()

    /**
     * [THÊM 16/11/2026] Cập nhật dòng "Điểm cắt thật" dưới cụm nút ±1s: khung khoá FFmpeg thật sự sẽ bắt đầu từ
     * đó khi cắt `-c copy` từ [startSec], và lệch bao nhiêu (xem [CutPointHint]). Chỉ ở chế độ Cắt/Tách. Đọc
     * khung khoá ở luồng nền, TỐI ĐA 1 lần đọc tại 1 thời điểm ([hintMutex] — giữ tinh thần vá ANR 04/09/2026:
     * không mở nhiều MediaExtractor chồng nhau), và chờ [delayMs] để bấm dồn dập chỉ đọc 1 lần ở lần bấm cuối.
     * Nếu file nguồn đã mất thì nói thẳng thay vì báo "trùng khung khoá" oan (findPrecedingKeyframeSec nuốt lỗi).
     */
    private fun scheduleRealStartHint(startSec: Float, delayMs: Long = 0L) {
        val path = selectedFilePaths.firstOrNull()
        if (path == null || currentMode != VideoToolMode.TRIM_SPLIT) {
            setRealStartHint(null)
            return
        }
        realStartHintJob?.cancel()
        realStartHintJob = lifecycleScope.launch {
            if (delayMs > 0L) kotlinx.coroutines.delay(delayMs)
            val f = File(path)
            val text = if (!f.exists() || f.length() <= 0L) {
                "Không đọc được file nguồn (đã bị xoá khỏi bộ nhớ tạm?) — bấm Chạy để app thử khôi phục, hoặc chọn lại video."
            } else {
                val keyframeSec = hintMutex.withLock {
                    withContext(Dispatchers.IO) { FileUtils.findPrecedingKeyframeSecOrNull(path, startSec.toDouble()) }
                }
                when {
                    keyframeSec == null -> CutPointHint.UNKNOWN
                    // [17/11/2026] Bật "Cắt chính xác": file bắt đầu ĐÚNG điểm chọn; khung khoá chỉ là điểm quay về.
                    binding.chkExactCut.isChecked -> CutPointHint.describeExact(startSec.toDouble(), keyframeSec)
                    else -> CutPointHint.describe(startSec.toDouble(), keyframeSec)
                }
            }
            setRealStartHint(text)
        }
    }

    private fun setRealStartHint(text: String?) {
        if (text.isNullOrEmpty()) {
            binding.txtRealStartHint.text = ""
            binding.txtRealStartHint.visibility = View.GONE
        } else {
            binding.txtRealStartHint.text = text
            binding.txtRealStartHint.visibility = View.VISIBLE
        }
    }

    /**
     * [THÊM 16/11/2026 — LỖI THẬT "không xem trước và cắt được"] File video trong thư mục làm việc biến mất
     * (log: ENOENT ~55s sau khi copy xong, app ở foreground, không đường xoá nào của app được ghi log; nguyên nhân
     * CHƯA chứng minh được — xem PROJECT_SPEC.md mục 6, 16/11/2026). Dù nguyên nhân là gì, đây là LƯỚI AN TOÀN:
     * copy lại từ Uri gốc người dùng đã chọn (quyền đọc của OpenDocument còn hiệu lực trong phiên), nạp lại preview
     * và KHÔI PHỤC khoảng đã chọn trên thanh trượt (danh sách đoạn trong ô văn bản không bị đụng tới). Nếu
     * [thenRun] thì tự chạy lại tác vụ người dùng vừa bấm. Không có Uri gốc (vd thả file từ app khác — quyền đã
     * trả sau khi copy) thì báo rõ để chọn lại, KHÔNG làm gì mù. Việc xoá/ghi đè vẫn đi qua importMutex +
     * pendingImports như mọi lần import nên không giẫm lên nhau.
     */
    private fun recoverMissingInput(path: String, thenRun: Boolean) {
        if (recovering || pendingImports > 0) {
            Toast.makeText(this, "Đang sao chép video, vui lòng đợi xong.", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = sourceUriByPath[path]
        if (uri == null) {
            DebugLog.log(this, "VideoToolsActivity", "Không khôi phục được ${File(path).name}: app không còn nhớ Uri gốc (vd file thả từ app khác)")
            Toast.makeText(
                this,
                "File video đã bị mất khỏi bộ nhớ tạm và app không còn bản gốc để copy lại. Hãy chọn lại video.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        recovering = true
        pendingImports++
        setImportBusy(true)
        val savedValues = binding.rangeSlider.values.toList()
        lifecycleScope.launch {
            var recovered = false
            importMutex.withLock {
                try {
                    val name = File(path).name
                    val totalSize = withContext(Dispatchers.IO) { FileUtils.queryDisplaySize(this@VideoToolsActivity, uri) }
                    val startedAt = android.os.SystemClock.uptimeMillis()
                    DebugLog.log(this@VideoToolsActivity, "VideoToolsActivity", "Khôi phục file nguồn: copy lại $name từ Uri gốc (kích thước khai báo=$totalSize)")
                    val file = withContext(Dispatchers.IO) {
                        FileUtils.copyUriToCache(
                            this@VideoToolsActivity, uri, name,
                            isCancelled = { !isActive },
                            expectedSize = totalSize
                        )
                    }
                    copyFinishedAtMs[file.absolutePath] = android.os.SystemClock.uptimeMillis()
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "Khôi phục file nguồn xong: ${file.name}, ${file.length()} byte, ${android.os.SystemClock.uptimeMillis() - startedAt}ms"
                    )
                    if (isPreviewMode() && selectedFilePaths.firstOrNull() == path) {
                        val duration = withContext(Dispatchers.IO) { readDurationSecBlocking(file.absolutePath) }
                        loadPreview(file, duration)
                        // loadPreview() đặt lại thanh trượt về [0, hết video] => trả lại khoảng người dùng đã chọn.
                        if (savedValues.size >= 2) {
                            val from = binding.rangeSlider.valueFrom
                            val to = binding.rangeSlider.valueTo
                            val s = savedValues.first().coerceIn(from, to)
                            val e = savedValues.last().coerceIn(from, to)
                            if (s < e) {
                                try { binding.rangeSlider.values = listOf(s, e) } catch (ex: Exception) { /* giữ nguyên [0, hết video] */ }
                            }
                        }
                    }
                    recovered = true
                    Toast.makeText(this@VideoToolsActivity, "Đã khôi phục lại file video bị mất khỏi bộ nhớ tạm.", Toast.LENGTH_SHORT).show()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: InsufficientStorageException) {
                    DebugLog.log(this@VideoToolsActivity, "VideoToolsActivity", "Khôi phục file nguồn bị TỪ CHỐI — ${e.message}")
                    Toast.makeText(this@VideoToolsActivity, e.message ?: "Không đủ dung lượng trống", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "Khôi phục file nguồn LỖI: ${e.javaClass.simpleName}: ${e.message}; ${FileUtils.describeInputState(this@VideoToolsActivity, path)}"
                    )
                    Toast.makeText(
                        this@VideoToolsActivity,
                        "Không khôi phục được file video (${e.message}). Hãy chọn lại video.",
                        Toast.LENGTH_LONG
                    ).show()
                } finally {
                    recovering = false
                    pendingImports--
                    if (pendingImports <= 0) {
                        pendingImports = 0
                        if (!isDestroyed) setImportBusy(false)
                    }
                }
            }
            if (recovered && thenRun && !isDestroyed) runCurrentAction()
        }
    }

    private fun updateSelectedFilesText() {
        binding.txtSelectedFiles.text = if (selectedFilePaths.isEmpty()) {
            "Chưa chọn video nào"
        } else {
            "Đã chọn ${selectedFilePaths.size} file (bấm 'Xoá' nếu chọn nhầm):"
        }

        binding.containerFileList.removeAllViews()
        for (path in selectedFilePaths.toList()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = 4 }
            }
            val nameView = TextView(this).apply {
                text = path.substringAfterLast("/")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(0, 8, 8, 8)
            }
            val removeBtn = Button(this).apply {
                text = "Xoá"
                setOnClickListener {
                    selectedFilePaths.remove(path)
                    updateSelectedFilesText()
                    if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
                    if (selectedFilePaths.isEmpty()) releasePlayer()
                }
            }
            row.addView(nameView)
            row.addView(removeBtn)
            binding.containerFileList.addView(row)
        }
    }

    private fun onModeChanged() {
        val showTrimGroup = currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE
        binding.groupTrimSplit.visibility = if (showTrimGroup) View.VISIBLE else View.GONE
        setRealStartHint(null) // [16/11/2026] dòng "điểm cắt thật" chỉ có nghĩa ở chế độ Cắt/Tách; đổi chế độ thì xoá
        binding.chkExactCut.visibility = if (currentMode == VideoToolMode.TRIM_SPLIT) View.VISIBLE else View.GONE // [17/11/2026]
        binding.groupCompress.visibility = if (currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        binding.btnAddMoreVideo.visibility = if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        // [THÊM tính năng Convert sang MP4] Nút + gợi ý riêng cho input m3u8/HLS, xem
        // FileUtils.importM3u8FolderToCache() để biết lý do cần trình chọn thư mục riêng.
        val isConvert = currentMode == VideoToolMode.CONVERT_TO_MP4
        binding.btnPickM3u8Folder.visibility = if (isConvert) View.VISIBLE else View.GONE
        binding.txtM3u8Hint.visibility = if (isConvert) View.VISIBLE else View.GONE
        binding.txtResult.text = ""
        binding.txtProgress.text = ""
        binding.btnSaveAs.visibility = View.GONE
        binding.btnSaveAllAs.visibility = View.GONE
        if (!showTrimGroup) releasePlayer()
        if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
        binding.edtSegments.hint = if (currentMode == VideoToolMode.REMOVE_MIDDLE)
            "Đoạn muốn XOÁ (bắt_đầu,kết_thúc theo giây)" else "0,30\n30,90"
        binding.txtSegmentsHelp.text = when (currentMode) {
            VideoToolMode.REMOVE_MIDDLE -> "Đoạn nhập vào sẽ bị XOÁ khỏi video, 2 phần còn lại (đầu + cuối) sẽ được ghép lại thành 1 file."
            VideoToolMode.EXTRACT_AUDIO -> "Để trống = tách toàn bộ audio. Nhập 1 đoạn = chỉ tách audio trong đoạn đó."
            else -> "1 dòng = Cắt lấy 1 đoạn (Trim). Nhiều dòng = Tách thành nhiều file (Split)."
        }
    }

    /**
     * Nếu người dùng đã kéo thanh trượt chọn 1 đoạn nhưng QUÊN bấm "Thêm đoạn đã chọn
     * vào danh sách" (dễ xảy ra, đúng lỗi đã báo: "chọn đoạn nhưng vẫn tách toàn bộ"),
     * tự động dùng đúng vị trí thanh trượt hiện tại làm đoạn xử lý — thay vì im lặng
     * coi là "không chọn gì" rồi xử lý toàn bộ video.
     */
    /**
     * [FIX 17/09/2026] Snap 1 THỜI ĐIỂM về khung hình khoá gần nhất TRƯỚC nó — dùng
     * ĐÚNG TRƯỚC KHI đưa vào bất kỳ lệnh FFmpeg "-c copy" nào cần điểm đó làm ĐIỂM BẮT
     * ĐẦU của 1 đoạn output (input-seeking + stream copy chỉ có thể bắt đầu tại khung
     * khoá — xem `FileUtils.findPrecedingKeyframeSec()` để biết đầy đủ nguyên lý).
     *
     * TẠI SAO CẦN THÊM Ở ĐÂY, DÙ ĐÃ CÓ SNAP KHI KÉO SLIDER (`onStopTrackingTouch`) VÀ
     * KHI BẤM "Thêm đoạn đã chọn vào danh sách" — lỗi THẬT đã tìm ra: người dùng GÕ TAY
     * số giây vào ô nhập (`edtStartSec`/`edtEndSec`, qua TextWatcher chỉ set thẳng
     * `rangeSlider.values`, KHÔNG gọi snap) RỒI BẤM CHẠY (Run) TRỰC TIẾP mà KHÔNG bấm
     * "Thêm đoạn" — `getEffectiveSegments()` khi đó đọc thẳng `rangeSlider.values` CHƯA
     * TỪNG được snap qua bất kỳ checkpoint nào ở trên — FFmpeg tự snap output về khung
     * khoá TRƯỚC đó, có thể cách xa vài giây so với số người dùng gõ, mà UI KHÔNG hề
     * cho thấy trước (không giống đường kéo slider, nơi handle tự "nhích" về đúng chỗ
     * để người dùng THẤY trước khi chạy) — đúng triệu chứng người dùng báo: "video cắt
     * ra lệch đằng trước vài giây so với chỗ cắt".
     *
     * Đặt snap Ở ĐÂY (ngay trước khi gọi VideoEngine, tại ĐIỂM CHỐT CUỐI CÙNG) thay vì
     * cố rà từng đường UI có thể tạo ra segment (kéo slider / gõ tay / danh sách nhiều
     * đoạn) — đảm bảo ĐÚNG bất kể đi đường nào, kể cả đường mới phát sinh sau này.
     */
    private suspend fun snapToPrecedingKeyframe(filePath: String, targetSec: Double): Double =
        withContext(Dispatchers.IO) { FileUtils.findPrecedingKeyframeSec(filePath, targetSec) }

    /**
     * [THÊM 25/10/2026] Tự kiểm sau khi Trim: với "-c copy" + "-ss X -t D", nếu FFmpeg lùi nhầm về khung khoá
     * TRƯỚC điểm đã snap thì file output bị DÀI hơn D đúng bằng khoảng lùi (đoạn cắt "trôi về trước" mà đuôi giữ
     * nguyên). So thời lượng thật với kỳ vọng và ghi vào DebugLog — lần sau có số liệu thật thay vì đoán.
     */
    private suspend fun logTrimCheck(requestedStart: Double, snappedStart: Double, end: Double, result: VideoOpResult) {
        val outPath = result.outputPaths.firstOrNull()
        val expected = end - snappedStart
        val actual = if (result.success && outPath != null) {
            withContext(Dispatchers.IO) { FileUtils.getVideoDurationSec(outPath) }
        } else -1.0
        val excess = actual - expected
        val warn = if (actual > 0 && excess > 0.75) " ⚠ NGHI OUTPUT BẮT ĐẦU SỚM HƠN ĐIỂM CHỌN ~${"%.1f".format(java.util.Locale.US, excess)}s" else ""
        DebugLog.log(
            this, "VideoToolsActivity",
            "TRIM — start chọn=${"%.3f".format(java.util.Locale.US, requestedStart)}s → khung khoá snap=${"%.3f".format(java.util.Locale.US, snappedStart)}s " +
                "(chênh ${"%.3f".format(java.util.Locale.US, requestedStart - snappedStart)}s), end=${"%.3f".format(java.util.Locale.US, end)}s; " +
                "thời lượng output kỳ vọng ${"%.2f".format(java.util.Locale.US, expected)}s, thật ${"%.2f".format(java.util.Locale.US, actual)}s " +
                "(dư ${"%.2f".format(java.util.Locale.US, excess)}s)$warn" +
                (if (result.note.isNotBlank()) " | ghi chú cắt: ${result.note}" else "")
        )
    }

    private fun getEffectiveSegments(): List<Pair<Double, Double>> {
        val rawText = binding.edtSegments.text.toString()
        if (rawText.isNotBlank()) return parseSegments(rawText)

        val values = binding.rangeSlider.values
        if (values.size < 2) return emptyList()
        val start = values.first()
        val end = values.last()
        // Chỉ coi là "có chọn đoạn" nếu khác biệt rõ so với toàn bộ video (tránh việc
        // slider ở đúng [0, duration] mặc định bị hiểu nhầm thành "có chọn đoạn").
        val isFullRange = start <= 0.05f && end >= videoDurationSec - 0.05f
        return if (isFullRange) emptyList() else listOf(start.toDouble() to end.toDouble())
    }

    /**
     * Callback tiến độ dùng cho trim/split/merge/tách audio/xoá đoạn giữa. FFmpegKit gọi
     * callback thống kê từ THREAD NỀN (không phải main thread), nên phải post qua
     * runOnUiThread trước khi đụng vào View, nếu không sẽ crash
     * (CalledFromWrongThreadException).
     */
    private fun updateRunProgress(percent: Int) {
        runOnUiThread {
            binding.progressBar.progress = percent
            binding.txtProgress.text = "Đang xử lý... $percent%"
        }
    }

    private fun runCurrentAction() {
        if (selectedFilePaths.isEmpty()) {
            Toast.makeText(this, "Vui lòng chọn video trước", Toast.LENGTH_SHORT).show()
            return
        }

        // [THÊM 16/11/2026 — LỖI THẬT "không cắt được"] Log thật: file nguồn đã biến mất khỏi thư mục làm việc,
        // vậy mà bấm Chạy vẫn đi tiếp — snap khung khoá nuốt lỗi (ghi "chênh 0.000s"), FFmpeg chạy trên file
        // không tồn tại rồi báo kết quả "thật -1.00s". Giờ KIỂM TRƯỚC: thiếu file thì thử copy lại từ Uri gốc
        // (recoverMissingInput) rồi tự chạy lại; không khôi phục được thì báo rõ, KHÔNG chạy mù.
        val missingInput = selectedFilePaths.firstOrNull { p -> val f = File(p); !f.exists() || f.length() <= 0L }
        if (missingInput != null) {
            DebugLog.log(
                this, "VideoToolsActivity",
                "Run: file nguồn KHÔNG CÒN — ${File(missingInput).name}; ${FileUtils.describeInputState(this, missingInput)}"
            )
            recoverMissingInput(missingInput, thenRun = true)
            return
        }

        if (currentMode == VideoToolMode.COMPRESS) {
            runCompressBatch()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""
        binding.txtProgress.text = "Đang xử lý..."

        lifecycleScope.launch {
            val outputDir = FileUtils.getOutputDir(this@VideoToolsActivity).absolutePath

            val result: VideoOpResult = when (currentMode) {
                VideoToolMode.TRIM_SPLIT -> {
                    val segments = getEffectiveSegments()
                    val subtitlePath = selectedSubtitlePath
                    val burnSubtitleChecked = binding.checkboxBurnSubtitle.isChecked
                    // (B) Video đang chọn ĐÃ LÀ đoạn cắt sẵn — không cắt gì thêm, chỉ dịch
                    // giờ phụ đề rồi ghép thẳng. Xem giải thích đầy đủ ở
                    // SubtitleUtils.shiftSubtitleFile() / VideoEngine.burnSubtitlesOntoAlreadyCutVideo().
                    val useAlreadyCutMode = burnSubtitleChecked && binding.radioSubModeAlreadyCut.isChecked
                    if (burnSubtitleChecked && subtitlePath == null) {
                        // Đã tick ghép phụ đề nhưng quên chọn file — báo rõ thay vì âm thầm
                        // bỏ qua chạy xử lý thường (dễ khiến người dùng tưởng đã ghép mà không).
                        VideoOpResult(false, log = "Đã tick 'Ghép cứng phụ đề' nhưng chưa chọn file phụ đề — bấm 'Chọn file phụ đề' trước.")
                    } else if (useAlreadyCutMode) {
                        val offsetText = binding.edtSubtitleOffsetStart.text.toString()
                        val startOffset = hmsToSeconds(offsetText)
                        if (startOffset == null) {
                            VideoOpResult(false, log = "Chưa nhập đúng mốc bắt đầu trong video gốc (định dạng giờ:phút:giây hoặc số giây, ví dụ 12:35 hoặc 755).")
                        } else {
                            try {
                                // videoDurationSec: độ dài THẬT của video đang chọn (đã là
                                // đoạn cắt sẵn) — đọc lúc nạp preview, dùng để tự tính điểm
                                // kết thúc trong video gốc = bắt đầu + độ dài đoạn này, KHÔNG
                                // bắt người dùng phải tự tính/nhập thêm 1 số nữa.
                                val endOffset = startOffset + videoDurationSec
                                val ext = File(subtitlePath!!).extension
                                val shiftedContent = withContext(Dispatchers.IO) {
                                    SubtitleUtils.shiftSubtitleFile(File(subtitlePath), ext, startOffset.toDouble(), endOffset.toDouble())
                                }
                                val shiftedFile = File(outputDir, "subtitle_shifted_${System.currentTimeMillis()}.$ext")
                                withContext(Dispatchers.IO) { shiftedFile.writeText(shiftedContent, Charsets.UTF_8) }
                                VideoEngine.burnSubtitlesOntoAlreadyCutVideo(selectedFilePaths.first(), shiftedFile.absolutePath, outputDir, ::updateRunProgress)
                            } catch (e: Exception) {
                                VideoOpResult(false, log = "Lỗi khi dịch giờ phụ đề: ${e.message}")
                            }
                        }
                    } else if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn 1 đoạn khác toàn bộ video (hoặc bấm 'Thêm đoạn' để tách nhiều đoạn)")
                    } else if (burnSubtitleChecked) {
                        // (A) Video đang chọn LÀ video gốc — cắt (theo segments) + ghép phụ
                        // đề trong 1 bước.
                        if (segments.size == 1) {
                            VideoEngine.trimWithBurnedSubtitles(selectedFilePaths.first(), subtitlePath!!, outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                        } else {
                            VideoEngine.splitWithBurnedSubtitles(selectedFilePaths.first(), subtitlePath!!, outputDir, segments, ::updateRunProgress)
                        }
                    } else if (segments.size == 1) {
                        // [FIX 17/09/2026] Snap điểm BẮT ĐẦU về khung khoá gần nhất NGAY
                        // TẠI ĐÂY — xem giải thích đầy đủ ở snapToPrecedingKeyframe() phía
                        // trên: không phụ thuộc segment tới từ đâu (gõ tay + Run thẳng là
                        // đường CHƯA từng được snap) đã đúng hay chưa.
                        val snappedStart = snapToPrecedingKeyframe(selectedFilePaths.first(), segments[0].first)
                        // [THÊM 17/11/2026] "Cắt chính xác" BẬT: bắt đầu ĐÚNG điểm chọn (SmartCut), khung khoá snappedStart chỉ là
                        // điểm QUAY VỀ nếu video không hỗ trợ / bước nào hỏng. TẮT: đúng cách cũ (cắt nhanh tại khung khoá).
                        val exact = binding.chkExactCut.isChecked
                        val trimResult = if (exact) {
                            VideoEngine.trimExact(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, snappedStart, videoDurationSec.toDouble(), ::updateRunProgress)
                        } else {
                            VideoEngine.trim(selectedFilePaths.first(), outputDir, snappedStart, segments[0].second, ::updateRunProgress)
                        }
                        // Điểm bắt đầu THẬT của file: đúng điểm chọn nếu cắt chính xác thành công, ngược lại là khung khoá.
                        val effectiveStart = if (exact && !trimResult.fellBack) segments[0].first else snappedStart
                        logTrimCheck(segments[0].first, effectiveStart, segments[0].second, trimResult)
                        trimResult
                    } else {
                        val snappedSegments = segments.map { (start, end) ->
                            val snapped = snapToPrecedingKeyframe(selectedFilePaths.first(), start)
                            DebugLog.log(
                                this@VideoToolsActivity, "VideoToolsActivity",
                                "SPLIT — start chọn=${"%.3f".format(java.util.Locale.US, start)}s → khung khoá snap=${"%.3f".format(java.util.Locale.US, snapped)}s, end=${"%.3f".format(java.util.Locale.US, end)}s"
                            )
                            snapped to end
                        }
                        if (binding.chkExactCut.isChecked) {
                            // [THÊM 17/11/2026] Mỗi đoạn bắt đầu ĐÚNG mốc chọn; khung khoá snap là điểm quay về RIÊNG của từng đoạn.
                            VideoEngine.splitExact(selectedFilePaths.first(), outputDir, segments, snappedSegments.map { it.first }, videoDurationSec.toDouble(), ::updateRunProgress)
                        } else {
                            VideoEngine.split(selectedFilePaths.first(), outputDir, snappedSegments, ::updateRunProgress)
                        }
                    }
                }
                VideoToolMode.REMOVE_MIDDLE -> {
                    val segments = getEffectiveSegments()
                    if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn đoạn muốn xoá (khác toàn bộ video)")
                    } else {
                        // [FIX 17/09/2026] Cùng lỗi/cùng nguyên nhân với Trim/Split, NHƯNG
                        // ở REMOVE_MIDDLE, điểm cần snap là "removeEnd" (segments[0].second)
                        // — vì đó là điểm BẮT ĐẦU của "phần B" (removeEnd -> hết video),
                        // đoạn NÀY mới dùng "-c copy" input-seeking, không phải removeStart
                        // (điểm KẾT THÚC của "phần A", phần A luôn bắt đầu từ 0 nên không
                        // bị ràng buộc này) — xem removeSegmentAndJoin() trong VideoEngine.kt.
                        val snappedRemoveEnd = snapToPrecedingKeyframe(selectedFilePaths.first(), segments[0].second)
                        VideoEngine.removeSegmentAndJoin(selectedFilePaths.first(), outputDir, segments[0].first, snappedRemoveEnd, videoDurationSec.toDouble(), ::updateRunProgress)
                    }
                }
                VideoToolMode.MERGE -> VideoEngine.merge(selectedFilePaths, outputDir, ::updateRunProgress)
                VideoToolMode.EXTRACT_AUDIO -> {
                    val segments = getEffectiveSegments()
                    when {
                        segments.isEmpty() -> VideoEngine.extractAudio(selectedFilePaths.first(), outputDir, ::updateRunProgress)
                        segments.size == 1 -> VideoEngine.extractAudioSegment(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                        else -> VideoEngine.extractAudioMultipleSegments(selectedFilePaths.first(), outputDir, segments, ::updateRunProgress)
                    }
                }
                VideoToolMode.COMPRESS -> throw IllegalStateException("Đã xử lý riêng ở nhánh trên")
                VideoToolMode.EXTRACT_HARDSUB -> {
                    val r = HardsubExtractor.extractHardsubToSrt(selectedFilePaths.first(), File(outputDir), onProgress = ::updateRunProgress)
                    if (!r.success) {
                        VideoOpResult(false, log = r.log)
                    } else {
                        val srtFile = File(outputDir, "hardsub_extracted_${System.currentTimeMillis()}.srt")
                        withContext(Dispatchers.IO) { srtFile.writeText(r.srtContent, Charsets.UTF_8) }
                        VideoOpResult(true, listOf(srtFile.absolutePath), r.log)
                    }
                }
                // [THÊM tính năng Convert sang MP4, 16/09/2026] Không hỏi người dùng
                // chọn phần cứng/phần mềm như Compress (không cần thiết ở đây — convert
                // luôn ưu tiên đúng, không có khái niệm "người dùng cố tình chọn phần
                // mềm để né phình dung lượng" như compress) — CHỈ probe rồi tự chọn,
                // dùng lại ĐÚNG probeHardwareEncodeSupport() đã có, không viết hàm mới.
                VideoToolMode.CONVERT_TO_MP4 -> {
                    val inputPath = selectedFilePaths.first()
                    val convertDurationSec = FileUtils.getVideoDurationSec(inputPath)
                    val sourceBitrateBps = FileUtils.calculateActualBitrateBpsSmart(inputPath, convertDurationSec)
                    binding.txtProgress.text = "Đang kiểm tra khả năng mã hoá phần cứng..."
                    val useHardware = VideoEngine.probeHardwareEncodeSupport(inputPath, cacheDir)
                    binding.txtProgress.text = "Đang convert (${if (useHardware) "phần cứng" else "phần mềm — sẽ chậm hơn"})..."
                    VideoEngine.convertToMp4WithKnownBackend(inputPath, outputDir, sourceBitrateBps, useHardware, ::updateRunProgress)
                }
            }

            finishRun(result)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val compressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CompressService.ACTION_PROGRESS -> {
                    val fileIndex = intent.getIntExtra("fileIndex", 0)
                    val totalFiles = intent.getIntExtra("totalFiles", 1)
                    val percent = intent.getIntExtra("percent", 0)
                    val useHardware = intent.getBooleanExtra("useHardware", true)
                    val prefix = if (totalFiles > 1) "File ${fileIndex + 1}/$totalFiles: " else ""
                    binding.progressBar.progress = percent
                    binding.txtProgress.text = "$prefix$percent% (${if (useHardware) "phần cứng" else "phần mềm"})"
                }
                CompressService.ACTION_COMPLETE -> {
                    val success = intent.getBooleanExtra("success", false)
                    val outputPaths = intent.getStringArrayListExtra("outputPaths") ?: arrayListOf()
                    val log = intent.getStringExtra("log") ?: ""
                    finishRun(VideoOpResult(success, outputPaths, log))
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        DebugLog.log(this, "VideoToolsActivity", "onStart() — isRunning=${CompressService.CompressResultHolder.isRunning}, lastResult=${if (CompressService.CompressResultHolder.lastResult != null) "có" else "null"}")
        val filter = IntentFilter().apply {
            addAction(CompressService.ACTION_PROGRESS)
            addAction(CompressService.ACTION_COMPLETE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(compressReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(compressReceiver, filter)
        }

        // Đồng bộ lại UI nếu Service đã chạy xong (hoặc đang chạy) trong lúc app ở nền
        if (CompressService.CompressResultHolder.isRunning) {
            binding.progressBar.visibility = View.VISIBLE
            binding.btnRun.isEnabled = false
            binding.btnCancelRunning.visibility = View.VISIBLE
            binding.txtProgress.text = "Đang nén ở chế độ nền... (mở thông báo để xem chi tiết)"
            // FIX: trước đây dòng "Chưa chọn video nào" (do selectedFilePaths bị reset
            // khi Activity tạo lại) khiến người dùng tưởng NHẦM là file đã mất, dù
            // Service vẫn đang xử lý đúng file đó — giờ hiện rõ tên file thật đang nén.
            val runningNames = CompressService.CompressResultHolder.runningFileNames
            if (runningNames.isNotEmpty()) {
                binding.txtSelectedFiles.text = "Đang nén (chạy nền): " + runningNames.joinToString(", ")
            }
        } else {
            binding.btnCancelRunning.visibility = View.GONE
            val inMemoryResult = CompressService.CompressResultHolder.lastResult
            if (inMemoryResult != null) {
                finishRun(inMemoryResult)
                CompressService.CompressResultHolder.lastResult = null
            } else {
                // FIX QUAN TRỌNG: nếu bản trong bộ nhớ (lastResult) đã bị Android xoá do
                // tiến trình app bị tắt SAU KHI compress xong (đúng lúc Service vừa
                // stopForeground() nên mất bảo vệ, rồi hệ thống thu hồi RAM) — bản trong
                // bộ nhớ mất, nhưng bản lưu trên đĩa (SharedPreferences) vẫn còn. Đây là
                // nguyên nhân của hiện tượng "thấy thông báo Nén thất bại/xong nhưng mở
                // app ra chả thấy gì" — giờ đọc từ đây như phương án dự phòng.
                CompressService.CompressResultStore.consumePending(applicationContext)?.let { persistedResult ->
                    finishRun(persistedResult)
                }
            }
        }

        checkWorkingFilesOnReturn()
    }

    /**
     * [THÊM 17/11/2026 — LỖI THẬT "preview đứng giữa chừng"] Quay lại app (onStart) thì kiểm tra video đang làm việc còn
     * trên đĩa không. Log thật: sau 1 lần onStop/onStart preview không bao giờ về READY nữa vì bản copy đã bị xoá
     * (nguyên nhân chính đã sửa ở VideoAIStudioApp — không còn xoá khi rời nền). Hàm này là LƯỚI AN TOÀN cho mọi nguyên nhân
     * khác (hệ thống dọn, tiến trình khác...) và đồng thời GHI LOG trạng thái mỗi lần quay lại, để lần sau có bằng chứng
     * thay vì phỏng đoán. Thiếu file thì tự copy lại từ Uri gốc (cùng cơ chế recoverMissingInput, tối đa 2 lần/file).
     */
    private fun checkWorkingFilesOnReturn() {
        if (selectedFilePaths.isEmpty() || recovering || pendingImports > 0) return
        val missing = selectedFilePaths.firstOrNull { p -> val f = File(p); !f.exists() || f.length() <= 0L }
        DebugLog.log(
            this, "VideoToolsActivity",
            "onStart: kiểm tra file nguồn — " + (if (missing == null) "còn nguyên" else "MẤT ${File(missing).name}") +
                "; " + FileUtils.describeInputState(this, missing ?: selectedFilePaths.first())
        )
        if (missing == null) return
        val tries = autoRecoveries[missing] ?: 0
        if (tries >= 2) return
        autoRecoveries[missing] = tries + 1
        recoverMissingInput(missing, thenRun = false)
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log(this, "VideoToolsActivity", "onStop()")
        try { unregisterReceiver(compressReceiver) } catch (e: Exception) { /* chưa đăng ký, bỏ qua */ }
    }

    /**
     * Luồng riêng cho Compress: dò phần cứng NHANH trên 1 đoạn ngắn trước (vài giây,
     * vẫn chạy trên lifecycleScope vì đây là thao tác nhanh) — sau đó GIAO VIỆC NÉN
     * THẬT cho Foreground Service, để tiến trình không bị huỷ khi rời app (đúng lỗi
     * đã gặp: "chuyển app khác thì nén dừng, không báo lỗi, quay lại thấy file hỏng").
     */
    private fun runCompressBatch() {
        // FIX: chặn từ phía UI luôn (không chỉ ở Service) — nếu đã có 1 tác vụ nén
        // đang chạy nền, báo rõ cho người dùng thay vì để họ tưởng nút "Chạy" không
        // phản ứng gì (Service giờ cũng tự chặn ở tầng dưới, xem CompressService,
        // nhưng chặn sớm ở đây giúp người dùng hiểu ngay lý do).
        if (CompressService.CompressResultHolder.isRunning) {
            Toast.makeText(this, "Đang có 1 tác vụ nén khác chạy nền — đợi xong rồi hẵng chạy tiếp.", Toast.LENGTH_LONG).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""

        // QUYẾT ĐỊNH CẬP NHẬT (08/07/2026): bản đầu phiên này từng đổi mặc định sang
        // CHỈ dùng phần mềm để né vấn đề phình dung lượng — nhưng đó là né tránh, không
        // giải quyết yêu cầu gốc "phải chạy trên đúng chip video engine". Đã tìm ra và
        // sửa ĐÚNG GỐC RỄ trong VideoEngine.compressInternal(): đổi bitrate_mode từ 1
        // (VBR — được phép vượt bitrate mục tiêu ở cảnh phức tạp) sang 2 (CBR — ép cứng
        // bitrate đều suốt video). Giờ PHỤC HỒI phần cứng làm mặc định (đúng yêu cầu ban
        // đầu), phần mềm chỉ là lựa chọn thủ công dự phòng nếu người dùng tự bỏ tick.
        // Có thêm log chẩn đoán so sánh bitrate mục tiêu vs thật đạt được (xem
        // VideoEngine, tìm "[CHẨN ĐOÁN CBR]") để xác nhận CBR có thực sự khắc phục được
        // vấn đề hay chưa — xem qua nút "Xem / Gửi log debug".
        val useHardwareRequested = binding.checkboxUseHardware.isChecked

        lifecycleScope.launch {
            val preset = currentPreset()

            val useHardware = if (useHardwareRequested) {
                binding.txtProgress.text = "Đang kiểm tra khả năng mã hoá phần cứng..."
                val supported = VideoEngine.probeHardwareEncodeSupport(selectedFilePaths.first(), cacheDir)
                if (!supported) {
                    // Người dùng CHỦ ĐỘNG chọn phần cứng nhưng máy không hỗ trợ thật —
                    // đây là bất ngờ, nên vẫn cần hỏi xác nhận trước khi chạy phần mềm
                    // chậm hơn, khác với trường hợp mặc định (họ đã biết trước là chậm).
                    val totalDurationSec = selectedFilePaths.sumOf { FileUtils.getVideoDurationSec(it) }
                    val etaMinutes = (totalDurationSec / SOFTWARE_SPEED_FACTOR / 60).toInt().coerceAtLeast(1)
                    val proceed = confirmSoftwareFallback(etaMinutes)
                    if (!proceed) {
                        binding.progressBar.visibility = View.GONE
                        binding.btnRun.isEnabled = true
                        binding.txtProgress.text = ""
                        binding.txtResult.text = "Đã huỷ — máy không hỗ trợ phần cứng thật sự, chạy phần mềm sẽ mất khoảng $etaMinutes phút."
                        return@launch
                    }
                }
                supported
            } else {
                // Mặc định: phần mềm — người dùng đã biết trước qua checkbox và ước tính
                // dung lượng hiển thị sẵn trên màn hình, không cần hỏi xác nhận lại nữa.
                false
            }

            binding.txtProgress.text = "Đang chạy ở chế độ nền (${if (useHardware) "phần cứng" else "phần mềm"})... có thể rời app, sẽ có thông báo khi xong."
            binding.btnCancelRunning.visibility = View.VISIBLE

            // FIX: ghi lại tên file đang gửi đi nén nền — để nếu Activity bị tạo lại
            // (màn hình tắt/bật, rời app...) và selectedFilePaths bị reset về rỗng,
            // UI vẫn có thể hiện đúng "Đang nén: X" thay vì "Chưa chọn video nào".
            CompressService.CompressResultHolder.runningFileNames = selectedFilePaths.map { File(it).name }

            val serviceIntent = Intent(this@VideoToolsActivity, CompressService::class.java).apply {
                putStringArrayListExtra(CompressService.EXTRA_INPUT_PATHS, ArrayList(selectedFilePaths))
                putExtra(CompressService.EXTRA_PRESET_ORDINAL, preset.ordinal)
                putExtra(CompressService.EXTRA_USE_HARDWARE, useHardware)
            }
            ContextCompat.startForegroundService(this@VideoToolsActivity, serviceIntent)
        }
    }

    private suspend fun confirmSoftwareFallback(etaMinutes: Int): Boolean = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        AlertDialog.Builder(this)
            .setTitle("Máy không hỗ trợ mã hoá phần cứng")
            .setMessage("Sẽ chạy bằng phần mềm (CPU) — ước tính mất khoảng $etaMinutes phút, có thể làm nóng máy. Bạn có muốn tiếp tục không?")
            .setPositiveButton("Tiếp tục") { _, _ -> cont.resumeWith(Result.success(true)) }
            .setNegativeButton("Huỷ") { _, _ -> cont.resumeWith(Result.success(false)) }
            .setCancelable(false)
            .show()
    }

    /**
     * Hiện toàn bộ nội dung log debug đã ghi (xem `DebugLog.kt`) trong 1 hộp thoại, kèm
     * nút "Chia sẻ" để gửi thẳng qua Messenger/Zalo/Gmail/... — thay thế việc phải chụp
     * màn hình nhiều lần (dễ thiếu thông tin, dễ đoán sai nguyên nhân lỗi).
     */
    private fun showDebugLogDialog() {
        val logContent = DebugLog.readAll(applicationContext)
        AlertDialog.Builder(this)
            .setTitle("Log debug (${logContent.lines().size} dòng)")
            .setMessage(if (logContent.length > 6000) "...(cắt bớt, xem đầy đủ khi Chia sẻ)...\n" + logContent.takeLast(6000) else logContent)
            .setPositiveButton("Chia sẻ") { _, _ ->
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, logContent)
                        putExtra(Intent.EXTRA_SUBJECT, "VideoAIStudio debug log")
                    }
                    startActivity(Intent.createChooser(shareIntent, "Gửi log debug"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Không chia sẻ được: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("Xoá log") { _, _ ->
                DebugLog.clear(applicationContext)
                Toast.makeText(this, "Đã xoá log debug", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun finishRun(result: VideoOpResult) {
        binding.progressBar.visibility = View.GONE
        binding.btnRun.isEnabled = true
        binding.txtProgress.text = ""

        // FIX QUAN TRỌNG: trước đây khi result.success == true, result.log bị BỎ QUA
        // HOÀN TOÀN dù VideoEngine.compressWithKnownBackend có thể trả về success=true
        // KÈM cảnh báo "CẢNH BÁO: dung lượng sau nén không nhỏ hơn đáng kể so với gốc"
        // (trường hợp cả 2 đường phần cứng lẫn phần mềm đều không nén nhỏ đi được).
        // Vì UI chỉ hiện "Thành công!" nên người dùng không hề biết file gần như không
        // đổi dung lượng — đúng hiện tượng "chọn nén Vừa nhưng không có bất kỳ thay đổi
        // nào" mà không thấy báo lỗi gì. Giờ luôn hiện cảnh báo nếu log có chứa nó.
        val hasWarning = result.success && result.log.contains("CẢNH BÁO", ignoreCase = true)
        // [THÊM 17/11/2026] Ghi chú cách cắt thật sự đã dùng (cắt chính xác / quay về cắt nhanh + lý do) — để người dùng
        // không phải đoán, và để lần sau gửi log có đủ thông tin. Rỗng với mọi chế độ khác.
        val noteBlock = if (result.note.isNotBlank()) "\n\n${if (result.fellBack) "⚠ " else ""}Cách cắt:\n${result.note}" else ""
        binding.txtResult.text = when {
            !result.success -> "Thất bại:\n${result.log}$noteBlock"
            hasWarning -> "Hoàn tất, NHƯNG CÓ CẢNH BÁO:\n${result.log}\n\nFile lưu tại:\n" + result.outputPaths.joinToString("\n") + noteBlock
            else -> "Thành công!\nFile lưu tại:\n" + result.outputPaths.joinToString("\n") + noteBlock
        }
        if (result.note.isNotBlank()) DebugLog.log(this, "VideoToolsActivity", "Cách cắt: ${result.note.replace("\n", " | ")}")

        if (result.success && result.outputPaths.size == 1) {
            lastSingleOutputPath = result.outputPaths.first()
            binding.btnSaveAs.visibility = View.VISIBLE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        } else if (result.success && result.outputPaths.size > 1) {
            // FIX: trước đây nhánh này chỉ hiện dòng disclaimer "chưa hỗ trợ Lưu vào tuỳ
            // chọn cho nhiều file" — đây chính là "lỗi lưu file" người dùng gặp khi tách
            // audio ra nhiều đoạn: file chỉ nằm trong thư mục riêng của app
            // (Android/data/com.videoaistudio.app/...), không có cách nào đưa ra ngoài.
            // Giờ hiện nút "Lưu TẤT CẢ file vào 1 thư mục..." để copy hết ra vị trí do
            // người dùng chọn (xem saveAllAsLauncher).
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = result.outputPaths
            binding.btnSaveAllAs.visibility = View.VISIBLE
        } else {
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        }
    }

    /**
     * Parse "start,end" mỗi dòng thành cặp (giây, giây).
     *
     * FIX: chịu được trường hợp người dùng tự gõ tay số thập phân bằng DẤU PHẨY
     * (thói quen bàn phím tiếng Việt, vd "10,5,20,3" nghĩa là 10.5 và 20.3) thay vì
     * dùng nút "Thêm đoạn đã chọn" (nút đó đã ép Locale.US ra dấu chấm, xem
     * addSelectedRangeToList). Trước đây parts.size != 2 thì BỎ QUA CẢ DÒNG một cách
     * im lặng — khiến segments trống rỗng và app coi như "không chọn đoạn", dẫn tới
     * lấy nhầm toàn bộ video/audio. Giờ nếu tách theo dấu chấm ra đúng 2 phần thì dùng
     * luôn (chuẩn); nếu không, thử lại coi dấu phẩy đầu tiên trong mỗi số là thập phân.
     */
    private fun parseSegments(raw: String): List<Pair<Double, Double>> {
        return raw.lines()
            .mapNotNull { line ->
                val trimmedLine = line.trim()
                if (trimmedLine.isBlank()) return@mapNotNull null

                // Thử chuẩn trước: đúng 2 phần, mỗi phần là số hợp lệ (dấu chấm thập phân).
                val standardParts = trimmedLine.split(",")
                if (standardParts.size == 2) {
                    val start = standardParts[0].trim().toDoubleOrNull()
                    val end = standardParts[1].trim().toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                // Rớt về đây nghĩa là split(",") không cho đúng 2 số hợp lệ — khả năng cao
                // là số thập phân dùng dấu phẩy (vd 4 phần "10,5,20,3"). Thử ghép lại theo
                // quy tắc: có đúng 4 phần và tất cả đều là số nguyên -> ghép phần 1-2 thành
                // 1 số thập phân (start), phần 3-4 thành 1 số thập phân (end).
                if (standardParts.size == 4 && standardParts.all { it.trim().toIntOrNull() != null }) {
                    val start = "${standardParts[0].trim()}.${standardParts[1].trim()}".toDoubleOrNull()
                    val end = "${standardParts[2].trim()}.${standardParts[3].trim()}".toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                null
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
        FileUtils.clearVideoInputCache(applicationContext)
    }

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_AUTO_BURN_SUBTITLE = "extra_auto_burn_subtitle"
        // Tốc độ mã hoá phần mềm quan sát được thực tế (speed=0.3x trong log FFmpeg
        // của chính người dùng) — dùng để ước tính thời gian trước khi chạy.
        private const val SOFTWARE_SPEED_FACTOR = 0.3
    }
}
