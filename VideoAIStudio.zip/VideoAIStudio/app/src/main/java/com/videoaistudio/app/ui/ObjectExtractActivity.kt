package com.videoaistudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.videoaistudio.app.databinding.ActivityObjectExtractBinding
import com.videoaistudio.app.inference.CharacterClustering
import com.videoaistudio.app.inference.CropCandidate
import com.videoaistudio.app.inference.CropQuality
import com.videoaistudio.app.inference.DetectionUtils
import com.videoaistudio.app.inference.ImageSharpness
import com.videoaistudio.app.inference.InferenceManager
import com.videoaistudio.app.inference.LocalModelProvider
import com.videoaistudio.app.inference.ModelConfig
import com.videoaistudio.app.inference.ProviderSource
import com.videoaistudio.app.inference.SimpleIouTracker
import com.videoaistudio.app.inference.TaskType
import com.videoaistudio.app.inference.TrackSummary
import com.videoaistudio.app.video.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.BitSet

/**
 * Pipeline nhận diện + phân loại NHÂN VẬT + giữ N ảnh tốt nhất mỗi nhân vật:
 *
 * 1. Lấy mẫu frame theo khoảng thời gian -> chạy detection (bất kỳ model YOLO-style nào, số
 *    lớp tự đọc từ output model, tên lớp lấy từ file labels người dùng cung cấp) -> NMS ->
 *    theo dõi IoU đơn giản giữa các frame mẫu (ra các "track") -> lọc theo class người dùng chọn.
 * 2. Với mỗi crop đủ nét/đủ lớn: chấm điểm chất lượng (CropQuality) + (nếu người dùng chọn
 *    model Re-ID) trích vector đặc trưng. Mỗi track chỉ giữ lại một số ít crop điểm cao nhất
 *    (lưu tạm trên đĩa) để không phình bộ nhớ/đĩa với video dài.
 * 3. Gom các track thành NHÂN VẬT: vector trung bình của track càng giống nhau (cosine) càng
 *    dễ gộp; ràng buộc cứng: cùng class, và 2 track cùng xuất hiện trong 1 frame mẫu thì
 *    KHÔNG BAO GIỜ gộp (xem CharacterClustering). Không chọn Re-ID => mỗi track = 1 nhân vật.
 * 4. Mỗi nhân vật chỉ giữ N ảnh điểm cao nhất -> thư mục char01_<tên lớp>/, char02_... (nhân
 *    vật xuất hiện nhiều frame nhất xếp trước); copy ra thư mục người dùng chỉ định (nếu có)
 *    qua Storage Access Framework.
 *
 * Giới hạn thành thật (đã nói rõ với người dùng) — xem thêm PROJECT_SPEC.md mục 4.4:
 * - 🔴 TOÀN BỘ phần Re-ID/gom nhân vật/chọn N ảnh CHƯA TEST THẬT trên máy với model Re-ID thật.
 *   Ngưỡng giống nhau mặc định 0.65, ngưỡng độ nét 15.0, công thức điểm chất lượng đều là SỐ
 *   ĐOÁN, chưa hiệu chỉnh.
 * - Gom nhân vật làm ở mức TRACK: nếu tracker IoU gán nhầm (2 người đi ngang qua nhau bị đổi ID
 *   giữa chừng) thì track đó lẫn 2 người và không tách lại được.
 * - Chỉ hỗ trợ họ model detection xuất output kiểu YOLOv8 (Ultralytics).
 * - Việc lọc theo class chỉ diễn ra SAU khi model đã chạy xong trên từng frame — không giảm
 *   được thời gian CHẠY MODEL trên từng frame, chỉ giảm số ảnh lưu ra.
 */
class ObjectExtractActivity : AppCompatActivity() {

    private lateinit var binding: ActivityObjectExtractBinding
    private lateinit var inferenceManager: InferenceManager
    private var configs: List<ModelConfig> = emptyList()
    private var reidConfigs: List<ModelConfig> = emptyList()
    private var selectedVideoPath: String? = null
    private var outputFolderUri: Uri? = null
    private val classCheckboxes = mutableListOf<CheckBox>()

    /** 1 nhân vật sau khi gom: các track thành viên + toàn bộ ảnh ứng viên của chúng. */
    private class CharacterGroup(
        val trackIds: List<Int>,
        val classId: Int,
        val framesPresent: Int,
        val candidates: List<CropCandidate>
    )

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importVideo(it) }
    }

    private val pickOutputFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputFolderUri = it
            binding.txtOutputFolder.text = "Sẽ lưu vào: ${it.lastPathSegment ?: it.toString()}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityObjectExtractBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)
        FileUtils.clearVideoInputCache(applicationContext)
        // Thư mục làm việc tạm của lần chạy trước bị bỏ lại (app bị kill giữa chừng) — chỉ xoá tiền tố của CHÍNH màn này
        FileUtils.clearStaleWorkDirs(applicationContext, listOf("detect_work_"))
        configs = inferenceManager.getAllConfigs().filter {
            it.taskType == TaskType.OBJECT_DETECTION && it.source == ProviderSource.LOCAL_MODEL
        }
        reidConfigs = inferenceManager.getAllConfigs().filter {
            it.taskType == TaskType.OBJECT_REID && it.source == ProviderSource.LOCAL_MODEL
        }

        if (configs.isEmpty()) {
            Toast.makeText(this, "Chưa có model Object Detection local nào được cấu hình.", Toast.LENGTH_LONG).show()
        }

        binding.spinnerModel.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, configs.map { it.displayName }
        )
        updateLabelsInfo()
        binding.spinnerModel.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) = updateLabelsInfo()
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        // Spinner Re-ID: mục đầu = không dùng; có model thì chọn sẵn model đầu tiên
        binding.spinnerReidModel.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(NO_REID_LABEL) + reidConfigs.map { it.displayName }
        )
        if (reidConfigs.isNotEmpty()) binding.spinnerReidModel.setSelection(1)
        binding.txtReidInfo.text = if (reidConfigs.isEmpty()) {
            "Chưa có model Re-ID nào. Vào 'Cấu hình Model' → tác vụ OBJECT_REID để nạp 1 file .onnx embedding/Re-ID. " +
            "Không có thì vẫn chạy được, nhưng mỗi track IoU bị tính là 1 nhân vật riêng."
        } else {
            "Đã có ${reidConfigs.size} model Re-ID. Chọn 'Không dùng' nếu muốn mỗi track là 1 nhân vật riêng."
        }

        binding.btnPickVideo.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        binding.btnPickOutputFolder.setOnClickListener { pickOutputFolder.launch(null) }
        binding.btnRun.setOnClickListener { runDetection() }
    }

    private fun currentConfig(): ModelConfig? = configs.getOrNull(binding.spinnerModel.selectedItemPosition)

    /** null = người dùng chọn "Không dùng Re-ID". */
    private fun currentReidConfig(): ModelConfig? {
        val pos = binding.spinnerReidModel.selectedItemPosition
        return if (pos <= 0) null else reidConfigs.getOrNull(pos - 1)
    }

    /** Đọc file labels (nếu có) và tạo checkbox cho từng class để người dùng chọn lọc. */
    private fun updateLabelsInfo() {
        val config = currentConfig()
        binding.containerClassCheckboxes.removeAllViews()
        classCheckboxes.clear()

        if (config?.labelsFilePath != null) {
            val labels = File(config.labelsFilePath).readLines().filter { it.isNotBlank() }
            binding.txtLabelsInfo.text = "Đã có file labels: ${labels.size} nhãn"
            for (label in labels) {
                val cb = CheckBox(this).apply { text = label }
                classCheckboxes.add(cb)
                binding.containerClassCheckboxes.addView(cb)
            }
        } else {
            binding.txtLabelsInfo.text = "Chưa có file labels — không lọc được theo tên lớp, sẽ tách TẤT CẢ (vào Cấu hình Model để thêm labels nếu muốn lọc)"
        }
    }

    /** Danh sách tên class được người dùng tick chọn. Rỗng = không lọc, tách tất cả. */
    private fun selectedClassNames(): Set<String> =
        classCheckboxes.filter { it.isChecked }.map { it.text.toString() }.toSet()

    private fun importVideo(uri: Uri) {
        // [SỬA 25/10/2026] Copy video (có thể vài GB) vào cache CHẠY NỀN — trước đây chạy thẳng trên luồng
        // chính nên UI đứng hàng chục giây => ANR "không phản hồi" (cùng lỗi với VideoToolsActivity.importUri).
        binding.txtSelectedVideo.text = "Đang sao chép video vào bộ nhớ đệm..."
        lifecycleScope.launch {
            try {
                val name = withContext(Dispatchers.IO) { FileUtils.queryDisplayName(this@ObjectExtractActivity, uri) }
                val file = withContext(Dispatchers.IO) {
                    FileUtils.copyUriToCache(this@ObjectExtractActivity, uri, name, isCancelled = { !isActive })
                }
                selectedVideoPath = file.absolutePath
                binding.txtSelectedVideo.text = "Đã chọn: $name"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                binding.txtSelectedVideo.text = ""
                Toast.makeText(this@ObjectExtractActivity, "Không đọc được video: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun runDetection() {
        val config = currentConfig()
        val videoPath = selectedVideoPath
        if (config == null || videoPath == null) {
            Toast.makeText(this, "Vui lòng chọn model và video trước", Toast.LENGTH_SHORT).show()
            return
        }
        val reidConfig = currentReidConfig()
        val confThreshold = binding.edtConfThreshold.text.toString().toFloatOrNull() ?: 0.5f
        val sampleInterval = binding.edtSampleInterval.text.toString().toDoubleOrNull()?.takeIf { it > 0.0 } ?: 1.0
        val imagesPerCharacter = binding.edtImagesPerCharacter.text.toString().toIntOrNull()?.coerceIn(1, 100) ?: DEFAULT_IMAGES_PER_CHARACTER
        val similarityThreshold = binding.edtSimilarityThreshold.text.toString().toFloatOrNull()?.coerceIn(0.05f, 0.99f) ?: DEFAULT_SIMILARITY_THRESHOLD
        val classFilter = selectedClassNames()

        val labels = config.labelsFilePath?.let { File(it).readLines().filter { l -> l.isNotBlank() } } ?: emptyList()

        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""

        // Khởi tạo provider TRƯỚC try để finally giải phóng được (constructor nhẹ, model chỉ nạp khi dùng)
        val detProvider = LocalModelProvider(applicationContext, config)
        val reidProvider = reidConfig?.let { LocalModelProvider(applicationContext, it) }
        val workDir = File(cacheDir, "detect_work_${System.currentTimeMillis()}")

        lifecycleScope.launch {
            try {
                val framesDir = File(workDir, "samples")

                binding.txtProgress.text = "Đang lấy mẫu frame (mỗi ${sampleInterval}s)..."
                val fps = 1.0 / sampleInterval
                val sampleResult = withContext(Dispatchers.IO) { sampleFrames(videoPath, framesDir, fps) }
                if (!sampleResult) {
                    finishWithError("Lấy mẫu frame thất bại")
                    return@launch
                }

                val frameFiles = framesDir.listFiles { f -> f.extension == "png" }?.sortedBy { it.name } ?: emptyList()
                if (frameFiles.isEmpty()) {
                    finishWithError("Không lấy được frame mẫu nào")
                    return@launch
                }

                // Kiểm tra tương thích model NGAY TRÊN FRAME ĐẦU TIÊN, trước khi xử lý cả video
                // (từ 08/07/2026 cho detection; 11/10/2026 thêm cho model Re-ID) — để model sai
                // định dạng báo lỗi sớm thay vì đợi chạy hết video rồi báo "không tìm thấy gì".
                binding.txtProgress.text = "Đang kiểm tra tương thích model..."
                val firstFrameBitmap = BitmapFactory.decodeFile(frameFiles.first().absolutePath)
                val compatCheck = firstFrameBitmap?.let { bmp ->
                    withContext(Dispatchers.Default) { detProvider.runRawDetection(bmp) }
                }
                val reidProbe = if (firstFrameBitmap != null && reidProvider != null) {
                    reidProvider.runEmbedding(firstFrameBitmap)
                } else null
                firstFrameBitmap?.recycle()

                val compatNumFeatures = compatCheck?.second?.getOrNull(1)?.toInt() ?: -1
                if (compatCheck == null || compatNumFeatures - 4 <= 0) {
                    finishWithError(
                        "Model không tương thích: output không đúng định dạng YOLOv8-style " +
                        "mà tính năng này hỗ trợ (cần shape dạng [1, 4+số_lớp, số_box]). " +
                        "Kiểm tra lại file .onnx đã chọn, hoặc thử model khác."
                    )
                    return@launch
                }
                if (reidProvider != null && reidProbe == null) {
                    finishWithError(
                        "Model Re-ID không tương thích: không trích được vector đặc trưng từ ảnh thử. " +
                        "Cần model .onnx nhận ảnh 4 chiều có 3 kênh màu ([1,3,H,W] hoặc [1,H,W,3]) và trả ra 1 vector. " +
                        "Kiểm tra lại file model, hoặc chọn 'Không dùng Re-ID'."
                    )
                    return@launch
                }

                val tracker = SimpleIouTracker()
                val cropsDir = File(workDir, "crops").apply { mkdirs() }
                val pools = HashMap<Int, MutableList<CropCandidate>>()   // trackId -> crop điểm cao nhất của track
                val trackFrames = HashMap<Int, BitSet>()                 // trackId -> các frame mẫu track xuất hiện
                val trackClass = HashMap<Int, Int>()                     // trackId -> classId
                // Mỗi track giữ tối đa chừng này crop: đủ cho việc chọn top-N (top-N của cả nhân vật
                // luôn nằm trong top-N của từng track thành viên) và đủ mẫu để lấy vector trung bình
                val perTrackCap = maxOf(imagesPerCharacter, MIN_CROPS_PER_TRACK_FOR_EMBEDDING)
                var numClassesDetected = -1
                var embeddingAttempts = 0
                var embeddingFailures = 0

                withContext(Dispatchers.Default) {
                    for ((frameIdx, frameFile) in frameFiles.withIndex()) {
                        val bitmap = BitmapFactory.decodeFile(frameFile.absolutePath) ?: continue
                        val rawResult = detProvider.runRawDetection(bitmap)
                        if (rawResult == null) {
                            bitmap.recycle()
                            continue
                        }
                        val (flatArray, outShape) = rawResult
                        val numFeatures = outShape.getOrNull(1)?.toInt()
                        val numBoxes = outShape.getOrNull(2)?.toInt()
                        if (numFeatures == null || numBoxes == null) {
                            bitmap.recycle()
                            continue
                        }
                        val numClasses = numFeatures - 4
                        if (numClasses <= 0) {
                            bitmap.recycle()
                            continue
                        }
                        numClassesDetected = numClasses
                        val inputSize = detProvider.getSquareInputSize()

                        val detections = DetectionUtils.decodeYoloV8Style(
                            flatArray, numClasses, numBoxes, confThreshold, bitmap.width, bitmap.height, inputSize
                        )
                        val afterNms = DetectionUtils.nms(detections)
                        val tracked = tracker.update(afterNms)

                        for ((box, trackId) in tracked) {
                            val label = labels.getOrNull(box.classId) ?: "class_${box.classId}"

                            // Lọc theo class người dùng chọn — bỏ trống checkbox nghĩa là lấy tất cả
                            if (classFilter.isNotEmpty() && label !in classFilter) continue

                            // Ghi nhận track CÓ MẶT ở frame này (kể cả khi crop bị loại vì mờ bên dưới) —
                            // dùng cho ràng buộc "2 track cùng 1 frame không thể là cùng 1 nhân vật"
                            trackFrames.getOrPut(trackId) { BitSet() }.set(frameIdx)
                            trackClass[trackId] = box.classId

                            val cropped = cropSafe(bitmap, box) ?: continue
                            if (minOf(cropped.width, cropped.height) < MIN_CROP_SIDE_PX) {
                                cropped.recycle()
                                continue
                            }
                            val sharpness = ImageSharpness.computeScore(cropped)
                            if (sharpness < MIN_SHARPNESS_SCORE) {
                                cropped.recycle()
                                continue
                            }

                            val quality = CropQuality.score(sharpness, cropped.width, cropped.height, box.confidence)
                            val pool = pools.getOrPut(trackId) { mutableListOf() }
                            // Pool đầy mà crop này không hơn crop tệ nhất -> bỏ ngay, khỏi tốn lượt chạy Re-ID + ghi đĩa
                            if (pool.size >= perTrackCap && quality <= pool.minOf { it.quality }) {
                                cropped.recycle()
                                continue
                            }

                            var embedding: FloatArray? = null
                            if (reidProvider != null) {
                                embeddingAttempts++
                                embedding = reidProvider.runEmbedding(cropped)
                                if (embedding == null) embeddingFailures++
                            }

                            val cropFile = File(cropsDir, "t${trackId}_s$frameIdx.jpg")
                            cropFile.outputStream().use { out -> cropped.compress(Bitmap.CompressFormat.JPEG, 92, out) }
                            val candidate = CropCandidate(
                                trackId = trackId, frameIdx = frameIdx, classId = box.classId,
                                confidence = box.confidence, width = cropped.width, height = cropped.height,
                                sharpness = sharpness, quality = quality, file = cropFile, embedding = embedding
                            )
                            cropped.recycle()
                            pool.add(candidate)
                            if (pool.size > perTrackCap) {
                                val worst = pool.minByOrNull { it.quality }
                                if (worst != null) {
                                    pool.remove(worst)
                                    worst.file.delete()
                                }
                            }
                        }
                        bitmap.recycle()

                        val keptSoFar = pools.values.sumOf { it.size }
                        withContext(Dispatchers.Main) {
                            binding.progressBar.max = frameFiles.size
                            binding.progressBar.progress = frameIdx + 1
                            binding.txtProgress.text = "Đã xử lý ${frameIdx + 1} / ${frameFiles.size} frame mẫu, " +
                                "${trackFrames.size} track, đang giữ $keptSoFar ảnh ứng viên"
                        }
                    }
                }

                // ---- Gom track thành nhân vật ----
                binding.txtProgress.text = "Đang gom các track thành nhân vật..."
                val summaries = trackFrames.map { (trackId, frames) ->
                    val vectors = pools[trackId]?.mapNotNull { it.embedding } ?: emptyList()
                    TrackSummary(trackId, trackClass[trackId] ?: -1, frames, CharacterClustering.meanEmbedding(vectors))
                }
                val clusters = withContext(Dispatchers.Default) {
                    CharacterClustering.cluster(summaries, similarityThreshold)
                }
                val tracksWithImages = summaries.count { !pools[it.trackId].isNullOrEmpty() }

                val characters = clusters.mapNotNull { memberIds ->
                    val candidates = memberIds.flatMap { pools[it] ?: emptyList() }
                    if (candidates.isEmpty()) return@mapNotNull null
                    val present = BitSet()
                    memberIds.forEach { id -> trackFrames[id]?.let { present.or(it) } }
                    CharacterGroup(memberIds, trackClass[memberIds.first()] ?: -1, present.cardinality(), candidates)
                }.sortedWith(compareByDescending<CharacterGroup> { it.framesPresent }.thenBy { it.trackIds.min() })

                if (characters.isEmpty()) {
                    finishWithError("Không tìm thấy object nào đạt ngưỡng tự tin/độ nét/kích thước/loại đã chọn. Thử giảm ngưỡng tự tin, bỏ chọn lọc class, hoặc kiểm tra model.")
                    return@launch
                }

                // ---- Mỗi nhân vật chỉ giữ N ảnh điểm cao nhất ----
                binding.txtProgress.text = "Đang chọn ${imagesPerCharacter} ảnh tốt nhất cho mỗi nhân vật..."
                val outputDir = File(FileUtils.getOutputDir(this@ObjectExtractActivity), "objects_${System.currentTimeMillis()}")
                val savedFiles = mutableListOf<File>()
                val summaryLines = mutableListOf<String>()
                withContext(Dispatchers.IO) {
                    outputDir.mkdirs()
                    for ((ci, ch) in characters.withIndex()) {
                        val label = labels.getOrNull(ch.classId) ?: "class_${ch.classId}"
                        val safeLabel = label.replace(Regex("[^A-Za-z0-9_-]"), "_")
                        val charDir = File(outputDir, "char${"%02d".format(java.util.Locale.US, ci + 1)}_$safeLabel").apply { mkdirs() }
                        val top = CharacterClustering.selectTopN(ch.candidates, imagesPerCharacter)
                        for ((rank, cand) in top.withIndex()) {
                            val confPct = "%.0f".format(java.util.Locale.US, cand.confidence * 100)
                            val dest = File(charDir, "rank${rank + 1}_s${cand.frameIdx}_c${confPct}.jpg")
                            cand.file.copyTo(dest, overwrite = true)
                            savedFiles.add(dest)
                        }
                        summaryLines.add("• ${charDir.name}: ${top.size} ảnh, có mặt ở ${ch.framesPresent} frame mẫu (gộp từ ${ch.trackIds.size} track)")
                    }
                }
                val savedCount = savedFiles.size

                var finalLocationNote = outputDir.absolutePath
                val folderUri = outputFolderUri
                if (savedCount > 0 && folderUri != null) {
                    binding.txtProgress.text = "Đang copy ảnh ra thư mục đã chọn..."
                    val copiedOk = withContext(Dispatchers.IO) { copyFilesToTree(savedFiles, outputDir, folderUri) }
                    if (copiedOk) {
                        finalLocationNote = "thư mục bạn đã chọn"
                        outputDir.deleteRecursively() // đã copy ra ngoài xong, dọn bản trong app tránh trùng dung lượng
                    } else {
                        finalLocationNote = "${outputDir.absolutePath}\n(Copy ra thư mục đã chọn thất bại, ảnh vẫn còn trong bộ nhớ app)"
                    }
                }

                binding.progressBar.visibility = android.view.View.GONE
                binding.btnRun.isEnabled = true

                val notes = StringBuilder()
                if (reidProvider == null) {
                    notes.append("\nKhông dùng Re-ID: mỗi track IoU được tính là 1 nhân vật riêng — người bị che khuất rồi xuất hiện lại sẽ thành nhân vật mới.")
                } else {
                    if (embeddingAttempts > 0 && embeddingFailures == embeddingAttempts) {
                        notes.append("\nCẢNH BÁO: model Re-ID không trích được vector nào trong lúc chạy — kết quả như khi không dùng Re-ID.")
                    } else if (embeddingFailures > 0) {
                        notes.append("\nLưu ý: model Re-ID thất bại trên $embeddingFailures / $embeddingAttempts crop (các crop đó không góp vào việc nhận diện).")
                    }
                    if (characters.size == tracksWithImages && tracksWithImages > 1) {
                        notes.append("\nRe-ID không gộp được track nào (${tracksWithImages} track -> ${characters.size} nhân vật). Nếu bạn biết có người xuất hiện lại, thử HẠ ngưỡng giống nhau, hoặc kiểm tra kiểu chuẩn hoá ảnh trong Cấu hình Model.")
                    }
                }
                if (numClassesDetected > 0 && labels.size != numClassesDetected) {
                    notes.append("\nLưu ý: model có $numClassesDetected lớp nhưng file labels có ${labels.size} dòng — tên lớp có thể không khớp, kiểm tra lại file labels.")
                }

                binding.txtResult.text =
                    "Hoàn tất! ${characters.size} nhân vật (từ $tracksWithImages track), lưu $savedCount ảnh (tối đa $imagesPerCharacter ảnh/nhân vật) vào:\n$finalLocationNote\n\n" +
                    summaryLines.take(MAX_SUMMARY_LINES).joinToString("\n") +
                    (if (summaryLines.size > MAX_SUMMARY_LINES) "\n… và ${summaryLines.size - MAX_SUMMARY_LINES} nhân vật nữa" else "") +
                    notes
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                finishWithError("Lỗi khi xử lý: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                // Luôn giải phóng model + xoá thư mục làm việc (frame mẫu PNG + crop tạm), kể cả khi
                // lỗi/huỷ giữa chừng — trước đây chỉ xoá ở nhánh chạy thành công.
                detProvider.release()
                reidProvider?.release()
                withContext(NonCancellable + Dispatchers.IO) { workDir.deleteRecursively() }
            }
        }
    }

    /** Copy toàn bộ file/thư mục con từ outputDir (bộ nhớ app) ra thư mục người dùng chọn qua SAF. */
    private fun copyFilesToTree(savedFiles: List<File>, baseDir: File, targetTreeUri: Uri): Boolean {
        return try {
            val targetRoot = DocumentFile.fromTreeUri(this, targetTreeUri) ?: return false
            for (file in savedFiles) {
                val relativeDir = file.parentFile?.name ?: "objects"
                var subDir = targetRoot.findFile(relativeDir)
                if (subDir == null || !subDir.isDirectory) {
                    subDir = targetRoot.createDirectory(relativeDir) ?: continue
                }
                val destDoc = subDir.createFile("image/jpeg", file.nameWithoutExtension) ?: continue
                contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun cropSafe(bitmap: Bitmap, box: com.videoaistudio.app.inference.DetectionBox): Bitmap? {
        val padding = 8
        val x1 = (box.x1 - padding).toInt().coerceIn(0, bitmap.width - 1)
        val y1 = (box.y1 - padding).toInt().coerceIn(0, bitmap.height - 1)
        val x2 = (box.x2 + padding).toInt().coerceIn(x1 + 1, bitmap.width)
        val y2 = (box.y2 + padding).toInt().coerceIn(y1 + 1, bitmap.height)
        return try {
            Bitmap.createBitmap(bitmap, x1, y1, x2 - x1, y2 - y1)
        } catch (e: Exception) {
            null
        }
    }

    private fun sampleFrames(inputPath: String, outDir: File, fps: Double): Boolean {
        outDir.mkdirs()
        val pattern = File(outDir, "frame_%06d.png").absolutePath
        val cmd = "-y -i \"$inputPath\" -vf fps=$fps \"$pattern\""
        val session = com.arthenica.ffmpegkit.FFmpegKit.execute(cmd)
        return com.arthenica.ffmpegkit.ReturnCode.isSuccess(session.returnCode)
    }

    private fun finishWithError(message: String) {
        binding.progressBar.visibility = android.view.View.GONE
        binding.btnRun.isEnabled = true
        binding.txtResult.text = message
    }

    companion object {
        /** Ngưỡng độ nét tối thiểu (phương sai Laplacian) — SỐ ĐOÁN, chưa hiệu chỉnh bằng dữ liệu thật. */
        private const val MIN_SHARPNESS_SCORE = 15.0
        /** Cạnh ngắn nhất (pixel) của crop để được xét — crop quá nhỏ vô nghĩa với Re-ID. SỐ ĐOÁN. */
        private const val MIN_CROP_SIDE_PX = 32
        /** Số crop tối thiểu mỗi track giữ lại để lấy vector đặc trưng trung bình ổn định hơn 1 crop. SỐ ĐOÁN. */
        private const val MIN_CROPS_PER_TRACK_FOR_EMBEDDING = 6
        private const val DEFAULT_IMAGES_PER_CHARACTER = 5
        /** Ngưỡng cosine để gộp track thành 1 nhân vật — SỐ ĐOÁN, phụ thuộc từng model Re-ID. */
        private const val DEFAULT_SIMILARITY_THRESHOLD = 0.65f
        private const val MAX_SUMMARY_LINES = 15
        private const val NO_REID_LABEL = "Không dùng Re-ID (mỗi track = 1 nhân vật)"
    }
}
