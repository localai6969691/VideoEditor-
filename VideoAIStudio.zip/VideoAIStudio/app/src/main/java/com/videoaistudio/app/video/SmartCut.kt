package com.videoaistudio.app.video

import java.io.File
import java.util.Locale

/**
 * [19/11/2026 — KHÔNG CÒN ĐƯỢC GỌI TỪ ĐÂU TRONG APP] Người dùng TỪ CHỐI smart cut vì phải mã hoá lại ("vừa lâu, vừa làm hư frame hết").
 * Công tắc "Cắt chính xác" giờ dùng [EditListCut] (stream copy + edit list, không mã hoá lại). File này (+ tools/tests/smartcut,
 * 110/110 PASS) chỉ giữ lại làm tham chiếu: ĐỪNG nối lại vào luồng chạy mà không hỏi người dùng.
 *
 * [THÊM 17/11/2026] Cắt CHÍNH XÁC từng khung hình mà vẫn giữ nguyên chất lượng phần lớn video ("smart cut").
 *
 * VẤN ĐỀ: "-c copy" chỉ bắt đầu được tại KHUNG KHOÁ, nên điểm bắt đầu thật luôn là khung khoá TRƯỚC điểm người dùng
 * chọn (cách vài giây). Mã hoá lại TOÀN BỘ đoạn thì chính xác nhưng chậm và đổi chất lượng cả đoạn (người dùng
 * từng từ chối ngày 01/09/2026). Cách ở đây: chỉ mã hoá lại đoạn [start, khungKhoáKếTiếp) — vài giây — rồi giữ
 * nguyên (copy) phần còn lại [khungKhoáKếTiếp, end).
 *
 * ĐIỂM KHÓ ĐÃ ĐO BẰNG FFMPEG 6.1.1 THẬT (xem tools/tests/smartcut/): ghép 2 file MP4 bằng concat demuxer KHÔNG dùng được —
 * MP4 chỉ ghi bộ tham số (SPS/PPS) của file đầu, còn phần copy cần bộ tham số của video gốc => chỉ giải mã được ~1/4 số
 * khung. Cách chạy được: đưa CẢ HAI đoạn qua MPEG-TS (SPS/PPS nằm ngay trong luồng, trước mỗi khung IDR), ghép bằng concat
 * demuxer rồi đóng lại vào container gốc: 100/100 khung phần copy giống hệt nguồn, khung đầu khớp nguồn (PSNR ≈ 45 dB).
 *
 * BỘ MÃ HOÁ cho đoạn đầu: chọn theo danh sách FFmpeg THẬT SỰ có ([parseEncoders]/[pickEncoder]) — libx264 (CRF 16, giữ
 * profile/level nguồn) nếu có; không thì h264_mediacodec (phần cứng, theo bitrate ≈1,2× nguồn; không đặt profile/level).
 * Bản FFmpeg TRONG APP không có libx264 (PROJECT_SPEC.md mục 2) => trên điện thoại đi đường h264_mediacodec: đường này mới
 * kiểm bằng GIẢ LẬP (libx264 theo bitrate) trên máy sửa code, CHƯA chạy trên chip thật. Mọi hỏng hóc đều quay về cắt nhanh.
 *
 * Lớp này THUẦN JVM (không phụ thuộc Android) để test được bằng FFmpeg thật trên máy sửa code; việc chạy FFmpeg/FFprobe
 * thật đi qua [Runner] (trên máy: FFmpegKit/FFprobeKit — xem VideoEngine).
 *
 * GIỚI HẠN (có chủ đích, gặp là quay về cắt nhanh tại khung khoá + ghi lý do): chỉ H.264 8-bit 4:2:0 không xoay, không
 * xen kẽ; container mp4/m4v/mov (mkv KHÔNG hỗ trợ, xem dưới); âm thanh aac/mp3/ac3/eac3 hoặc không có; mất các luồng phụ (chỉ giữ 1 video + 1 audio
 * đầu tiên — giống "-c copy" mặc định chọn 1 luồng mỗi loại). 🔴 CHƯA kiểm trên bộ giải mã phần cứng của máy thật:
 * file đầu ra có SPS/PPS đổi giữa chừng (hợp lệ theo chuẩn, FFmpeg giải mã đúng; các bộ giải mã phần cứng thường xử lý được).
 */
object SmartCut {

    /** Sai số coi "điểm bắt đầu nằm đúng trên khung khoá" (mili-giây làm tròn / Float32 của slider). */
    const val KEY_EPS_SEC = 0.002

    /** Cửa sổ tìm khung khoá sau điểm bắt đầu. */
    const val KEY_WINDOW_SEC = 90.0

    /** Đoạn mã hoá lại tối đa (giây). Quá dài => quay về cắt nhanh (mã hoá lại lâu, tốn pin). */
    const val MAX_HEAD_SEC = 60.0

    /** Lệch thời lượng tối đa giữa kết quả và kỳ vọng; vượt => coi là hỏng, quay về cắt nhanh. */
    const val DURATION_TOLERANCE_SEC = 1.5

    /** Đệm cộng vào -ss của lệnh copy để chắc chắn FFmpeg chọn ĐÚNG khung khoá (đo 25/10/2026, xem VideoEngine). */
    const val COPY_SEEK_MARGIN_SEC = 0.005

    /**
     * CHỈ họ MP4 (bảng mẫu trong `stbl` cho phép seek tới ĐÚNG khung khoá). MKV bị loại — đo thật (ffmpeg 6.1.1, mkv remux
     * từ mp4): MKV chỉ có Cues thưa nên `-ss 33.2` trên khung khoá 33.123 vẫn nhảy về khung khoá 25.323 => đoạn đuôi
     * thừa ~8s, kết quả dài 27.96s thay vì 20s. Muốn hỗ trợ mkv phải đọc lại vị trí khung khoá thực sự, chưa làm.
     */
    private val SUPPORTED_CONTAINERS = setOf("mp4", "m4v", "mov")

    /** Lệch tối đa giữa thời lượng luồng hình và luồng tiếng của kết quả; vượt => nghi lệch tiếng tại chỗ nối. */
    const val SYNC_TOLERANCE_SEC = 0.5

    /** Lệch tối đa thời lượng đoạn đuôi (.ts) so với kỳ vọng. Lớn hơn => `-ss` đã nhảy về khung khoá TRƯỚC nextKey. */
    const val TAIL_TOLERANCE_SEC = 0.8
    private val SUPPORTED_AUDIO = setOf("aac", "mp3", "ac3", "eac3")
    private val X264_PROFILE = mapOf(
        "baseline" to "baseline", "constrained baseline" to "baseline", "main" to "main", "high" to "high"
    )

    // ---------------------------------------------------------------- kiểu dữ liệu

    data class Probe(
        val videoCodec: String?,
        val profile: String?,
        val level: Int,
        val pixFmt: String?,
        val fieldOrder: String?,
        val rotated: Boolean,
        val fps: Double,
        val audioCodec: String?,
        val width: Int = 0,
        val height: Int = 0,
        /** bit_rate của luồng video (bps), 0 nếu container không ghi. */
        val videoBitRate: Long = 0,
        /** bit_rate cả file (bps), 0 nếu không rõ. */
        val containerBitRate: Long = 0
    )

    /** Bộ mã hoá H.264 dùng cho đoạn đầu. Chọn theo danh sách FFmpeg THẬT SỰ có (không đoán theo máy). */
    enum class Encoder(val ffName: String) {
        /** CRF thật, giữ profile/level nguồn. Chỉ có ở bản FFmpeg GPL (máy sửa code); bản trong app KHÔNG có (spec mục 2). */
        LIBX264("libx264"),
        /** Phần cứng Android — đúng bộ mã hoá mà Compress/Convert của app đang dùng. Mã hoá theo bitrate (không CRF). */
        MEDIACODEC("h264_mediacodec")
    }

    sealed class Plan {
        /** Điểm bắt đầu đã nằm đúng trên khung khoá: "-c copy" thường đã chính xác. */
        object CopyIsExact : Plan()
        /** Mã hoá lại [start, nextKey), copy [nextKey, end). */
        data class Smart(val nextKeyframe: Double) : Plan()
        /** Cả đoạn [start, end) nằm gọn trước khung khoá kế tiếp: mã hoá lại cả đoạn. */
        object HeadOnly : Plan()
        data class Unsupported(val reason: String) : Plan()
    }

    enum class Status { EXACT_DONE, COPY_IS_EXACT, UNSUPPORTED, FAILED, CANCELLED }

    data class Outcome(val status: Status, val note: String, val log: String = "")

    data class StepResult(val success: Boolean, val cancelled: Boolean = false, val log: String = "")

    /** Cầu nối tới FFmpeg/FFprobe thật (Android: FFmpegKit/FFprobeKit; test JVM: tiến trình ffmpeg trên máy). */
    interface Runner {
        /** Chạy ffprobe, trả về stdout; null nếu lỗi. */
        fun probe(args: String): String?
        /** Đầu ra của `ffmpeg -hide_banner -encoders`; null nếu không đọc được (=> coi như không biết bộ mã hoá nào). */
        fun encoders(): String? = null
        /** Chạy ffmpeg và CHẶN tới khi xong. [durationSec] để tính % tiến độ (<=0: không báo). */
        fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit): StepResult
    }

    // ---------------------------------------------------------------- phân tích đầu ra ffprobe

    /** Phân tích `ffprobe -of flat` (dòng `streams.stream.N.khoá=giá trị`). */
    fun parseProbe(flat: String): Probe {
        val streams = HashMap<Int, HashMap<String, String>>()
        val re = Regex("""^streams\.stream\.(\d+)\.(.+?)=(.*)$""")
        for (line in flat.lineSequence()) {
            val m = re.find(line.trim()) ?: continue
            val idx = m.groupValues[1].toInt()
            streams.getOrPut(idx) { HashMap() }[m.groupValues[2]] = m.groupValues[3].trim().trim('"')
        }
        val ordered = streams.toSortedMap().values
        val v = ordered.firstOrNull { it["codec_type"] == "video" }
        val a = ordered.firstOrNull { it["codec_type"] == "audio" }
        val rotated = v != null && v.entries.any { (k, value) ->
            (k.endsWith(".rotation") || k == "tags.rotate") && (value.toDoubleOrNull() ?: 0.0) != 0.0
        }
        val containerBr = flat.lineSequence().map { it.trim() }
            .firstOrNull { it.startsWith("format.bit_rate=") }?.substringAfter('=')?.trim('"')?.toLongOrNull() ?: 0L
        return Probe(
            videoCodec = v?.get("codec_name"),
            profile = v?.get("profile"),
            level = v?.get("level")?.toIntOrNull() ?: -1,
            pixFmt = v?.get("pix_fmt"),
            fieldOrder = v?.get("field_order"),
            rotated = rotated,
            fps = parseFraction(v?.get("r_frame_rate")) ?: 0.0,
            audioCodec = a?.get("codec_name"),
            width = v?.get("width")?.toIntOrNull() ?: 0,
            height = v?.get("height")?.toIntOrNull() ?: 0,
            videoBitRate = v?.get("bit_rate")?.toLongOrNull() ?: 0L,
            containerBitRate = containerBr
        )
    }

    private val ENCODER_LINE = Regex("^[VAS][.A-Z]{5}\\s+(\\S+)")

    /** Phân tích `ffmpeg -hide_banner -encoders`: tập tên bộ mã hoá (bỏ dòng chú giải/tiêu đề). */
    fun parseEncoders(text: String): Set<String> =
        text.lineSequence().mapNotNull { ENCODER_LINE.find(it.trim())?.groupValues?.get(1) }.filter { it != "=" }.toSet()

    fun pickEncoder(available: Set<String>): Encoder? = when {
        "libx264" in available -> Encoder.LIBX264
        "h264_mediacodec" in available -> Encoder.MEDIACODEC
        else -> null
    }

    /**
     * Bitrate (kbps) cho bộ mã hoá theo bitrate: ≈1,2× bitrate video gốc để các khung mã hoá lại không kém nguồn.
     * Gốc lấy từ luồng video; không có thì lấy cả file trừ ~192 kbps âm thanh; không có nữa thì ước lượng 0,1 bit/điểm ảnh.
     */
    fun headBitrateKbps(probe: Probe): Int {
        val fps = if (probe.fps in 1.0..240.0) probe.fps else 30.0
        val srcBps = when {
            probe.videoBitRate > 0 -> probe.videoBitRate.toDouble()
            probe.containerBitRate > 256_000 -> (probe.containerBitRate - 192_000).toDouble()
            probe.width > 0 && probe.height > 0 -> probe.width.toDouble() * probe.height * fps * 0.1
            else -> 8_000_000.0
        }
        return (srcBps * 1.2 / 1000).toInt().coerceIn(2000, 60000)
    }

    private fun parseFraction(s: String?): Double? {
        if (s.isNullOrBlank()) return null
        val parts = s.split("/")
        val num = parts[0].toDoubleOrNull() ?: return null
        val den = if (parts.size > 1) parts[1].toDoubleOrNull() ?: return null else 1.0
        return if (den == 0.0) null else num / den
    }

    /** Phân tích `ffprobe -show_entries packet=pts_time,flags -of csv=p=0`: trả pts (giây) các gói là khung khoá. */
    fun parseKeyframes(csv: String): List<Double> =
        csv.lineSequence().mapNotNull { line ->
            val p = line.trim().split(",")
            if (p.size >= 2 && p[1].contains('K')) p[0].toDoubleOrNull() else null
        }.sorted().toList()

    private val NUMBER_LINE = Regex("^-?\\d+(\\.\\d+)?$")
    private val FRAME_LINE = Regex("^(-?\\d+(\\.\\d+)?|N/A)$")

    /** Số cuối cùng trong đầu ra ffprobe (bỏ qua dòng cảnh báo/lỗi lẫn vào). */
    fun lastNumber(text: String): Double? =
        text.lineSequence().map { it.trim() }.filter { NUMBER_LINE.matches(it) }.lastOrNull()?.toDoubleOrNull()

    /** Đếm dòng "pts_time" của `-show_entries frame=pts_time -of csv=p=0` (số hoặc N/A), bỏ qua dòng lỗi lẫn vào. */
    fun countFrameLines(text: String): Int =
        text.lineSequence().map { it.trim() }.count { FRAME_LINE.matches(it) }

    // ---------------------------------------------------------------- quyết định

    fun decide(start: Double, end: Double, ext: String, probe: Probe, keyframes: List<Double>): Plan {
        if (end <= start) return Plan.Unsupported("đoạn cắt rỗng")
        if (start <= 0.05) return Plan.CopyIsExact
        if (keyframes.any { kotlin.math.abs(it - start) <= KEY_EPS_SEC }) return Plan.CopyIsExact

        if (ext.lowercase(Locale.ROOT) !in SUPPORTED_CONTAINERS) return Plan.Unsupported("định dạng .${ext.lowercase(Locale.ROOT)} chưa hỗ trợ cắt chính xác")
        if (probe.videoCodec != "h264") return Plan.Unsupported("video là ${probe.videoCodec ?: "không rõ"} (chỉ hỗ trợ H.264)")
        if (probe.pixFmt != "yuv420p") return Plan.Unsupported("kiểu điểm ảnh ${probe.pixFmt ?: "không rõ"} (chỉ hỗ trợ 8-bit yuv420p)")
        if (probe.profile?.lowercase(Locale.ROOT) !in X264_PROFILE.keys) return Plan.Unsupported("profile H.264 ${probe.profile ?: "không rõ"} chưa hỗ trợ")
        val fo = probe.fieldOrder
        if (fo != null && fo != "progressive" && fo != "unknown") return Plan.Unsupported("video xen kẽ ($fo)")
        if (probe.rotated) return Plan.Unsupported("video có thông tin xoay màn hình")
        if (probe.audioCodec != null && probe.audioCodec !in SUPPORTED_AUDIO) return Plan.Unsupported("âm thanh ${probe.audioCodec} chưa hỗ trợ")

        val next = keyframes.firstOrNull { it > start + KEY_EPS_SEC }
        if (next == null || end <= next + 0.05) {
            return if (end - start <= MAX_HEAD_SEC) Plan.HeadOnly
            else Plan.Unsupported("không thấy khung khoá nào trong ${KEY_WINDOW_SEC.toInt()}s sau điểm bắt đầu")
        }
        if (next - start > MAX_HEAD_SEC) return Plan.Unsupported("khung khoá kế tiếp cách ${"%.0f".format(Locale.US, next - start)}s, quá xa")
        return Plan.Smart(next)
    }

    // ---------------------------------------------------------------- dựng lệnh

    private fun sec(v: Double): String = "%.3f".format(Locale.US, v)

    private fun levelArg(level: Int): String? =
        if (level in 10..62 && level != 9) "%d.%d".format(Locale.US, level / 10, level % 10) else null

    /** Tham số libx264: giữ profile/level/pix_fmt của nguồn để bộ giải mã coi cùng 1 luồng. */
    fun x264Args(probe: Probe): String {
        val profile = X264_PROFILE[probe.profile?.lowercase(Locale.ROOT)] ?: "high"
        val lvl = levelArg(probe.level)?.let { " -level $it" } ?: ""
        return "-c:v libx264 -preset veryfast -crf 16 -pix_fmt yuv420p -profile:v $profile$lvl"
    }

    /** Tham số mã hoá đoạn đầu theo bộ mã hoá đã chọn. */
    fun encoderArgs(enc: Encoder, probe: Probe): String = when (enc) {
        Encoder.LIBX264 -> x264Args(probe)
        // CÙNG kiểu cờ Compress đang dùng (-bitrate_mode 2 = CBR, xem VideoEngine). Cố ý KHÔNG đặt -profile/-level: tuỳ chọn đó
        // không chắc bản FFmpeg trong app nhận; ffmpeg báo lỗi sẽ làm cả bước hỏng.
        Encoder.MEDIACODEC -> "-c:v h264_mediacodec -bitrate_mode 2 -b:v ${headBitrateKbps(probe)}k -pix_fmt yuv420p"
    }

    private fun mapArgs(probe: Probe): String =
        "-map 0:v:0" + if (probe.audioCodec != null) " -map 0:a:0" else ""

    fun headCommand(input: String, start: Double, durationSec: Double, probe: Probe, outTs: String, enc: Encoder = Encoder.LIBX264): String {
        val audio = if (probe.audioCodec != null) " -c:a copy -copypriorss 0" else ""
        return "-y -ss ${sec(start)} -i \"$input\" -t ${sec(durationSec)} ${mapArgs(probe)} ${encoderArgs(enc, probe)}$audio " +
            "-avoid_negative_ts make_zero -f mpegts \"$outTs\""
    }

    /**
     * [SỬA 17/11/2026] TUYỆT ĐỐI KHÔNG thêm `-copypriorss 0` vào đây: seek ở nextKey+5ms nghĩa là keyframe tại nextKey
     * nằm TRƯỚC điểm seek 5ms, và chính `copy_prior_start` mặc định mới giữ lại nó. Với `-copypriorss 0` keyframe đó bị bỏ,
     * đoạn đuôi bắt đầu ở keyframe kế tiếp (đo thật: 66/510 khung, video-only chỉ còn 2,27 s thay vì 17 s). Muốn bỏ audio
     * tiền-cuộn thì xử lý ở phần đầu (head) chứ không ở đuôi.
     */
    fun tailCommand(input: String, nextKey: Double, durationSec: Double, probe: Probe, outTs: String): String =
        "-y -ss ${sec(nextKey + COPY_SEEK_MARGIN_SEC)} -i \"$input\" -t ${sec(durationSec)} ${mapArgs(probe)} -c copy " +
            "-avoid_negative_ts make_zero -f mpegts \"$outTs\""

    fun concatCommand(listFile: String, probe: Probe, output: String): String {
        val bsf = if (probe.audioCodec == "aac") " -bsf:a aac_adtstoasc" else ""
        return "-y -f concat -safe 0 -i \"$listFile\" -c copy$bsf \"$output\""
    }

    fun keyframeProbeCommand(input: String, start: Double): String =
        "-v error -select_streams v:0 -show_entries packet=pts_time,flags -read_intervals \"${sec(start)}%+${KEY_WINDOW_SEC.toInt()}\" -of csv=p=0 \"$input\""

    fun infoProbeCommand(input: String): String =
        "-v error -show_entries format=bit_rate:stream=index,codec_type,codec_name,profile,level,pix_fmt,field_order,r_frame_rate,width,height,bit_rate:stream_side_data=rotation:stream_tags=rotate -of flat \"$input\""

    fun durationProbeCommand(file: String): String =
        "-v error -show_entries format=duration -of csv=p=0 \"$file\""

    fun streamDurationProbeCommand(file: String, stream: String): String =
        "-v error -select_streams $stream -show_entries stream=duration -of csv=p=0 \"$file\""

    /** Đếm số khung giải mã được trong cửa sổ [at, at+window] — phát hiện lỗi giải mã tại chỗ nối. */
    fun framesProbeCommand(file: String, at: Double, windowSec: Double): String =
        "-v error -select_streams v:0 -show_entries frame=pts_time -read_intervals \"${sec(at.coerceAtLeast(0.0))}%+${sec(windowSec)}\" -of csv=p=0 \"$file\""

    // ---------------------------------------------------------------- chạy

    /**
     * Cắt [start, end) của [input] thành [output] chính xác tại [start]. Mọi bước chạy qua [runner]; file tạm nằm trong
     * [tempDir] (do hàm tạo và dọn). Trả [Outcome]: EXACT_DONE = [output] đã ghi; COPY_IS_EXACT = chưa ghi gì, người gọi
     * dùng "-c copy" ngay tại [start]; UNSUPPORTED/FAILED = chưa có output hợp lệ, người gọi quay về cắt nhanh tại khung khoá.
     * [totalDurationSec]: thời lượng cả video (ước lượng dung lượng tạm), 0 nếu không biết.
     */
    fun cutExact(
        input: String,
        output: String,
        start: Double,
        end: Double,
        totalDurationSec: Double,
        tempDir: File,
        runner: Runner,
        isCancelled: () -> Boolean = { false },
        onProgress: (Int) -> Unit = {}
    ): Outcome {
        val ext = File(input).extension
        val info = runner.probe(infoProbeCommand(input))
            ?: return Outcome(Status.FAILED, "không đọc được thông tin video (ffprobe lỗi)")
        val probe = parseProbe(info)
        val kfText = runner.probe(keyframeProbeCommand(input, start))
            ?: return Outcome(Status.FAILED, "không đọc được danh sách khung khoá (ffprobe lỗi)")
        val keyframes = parseKeyframes(kfText)

        val plan = decide(start, end, ext, probe, keyframes)
        when (plan) {
            is Plan.CopyIsExact -> return Outcome(Status.COPY_IS_EXACT, "điểm bắt đầu nằm đúng trên khung khoá — cắt nhanh đã chính xác")
            is Plan.Unsupported -> return Outcome(Status.UNSUPPORTED, plan.reason)
            else -> Unit
        }

        val enc = pickEncoder(parseEncoders(runner.encoders() ?: ""))
            ?: return Outcome(Status.UNSUPPORTED, "FFmpeg trong app không có bộ mã hoá H.264 dùng được (cần libx264 hoặc h264_mediacodec)")

        // Dung lượng tạm: tail.ts (≈ phần copy) + file cuối (≈ cùng cỡ) => cần ≈ 2.2× phần copy + đệm.
        val srcBytes = File(input).length()
        val tailFraction = if (totalDurationSec > 0) ((end - start) / totalDurationSec).coerceIn(0.0, 1.0) else 1.0
        val need = (srcBytes * tailFraction * 2.2).toLong() + 256L * 1024 * 1024
        tempDir.mkdirs()
        val free = tempDir.usableSpace
        if (free < need) {
            tempDir.deleteRecursively()
            return Outcome(Status.UNSUPPORTED, "không đủ dung lượng trống cho file tạm (cần ~${need / (1024 * 1024)}MB, còn ${free / (1024 * 1024)}MB)")
        }

        val headTs = File(tempDir, "head.ts")
        val tailTs = File(tempDir, "tail.ts")
        val listFile = File(tempDir, "pieces.txt")
        val logs = StringBuilder()
        try {
            val nextKey = (plan as? Plan.Smart)?.nextKeyframe
            val headDur = if (nextKey != null) nextKey - start else end - start
            val headShare = if (nextKey != null) 10 else 80
            var base = 0

            fun step(cmd: String, dur: Double, share: Int): StepResult {
                val r = runner.ffmpeg(cmd, dur) { p -> onProgress((base + p * share / 100).coerceIn(0, 99)) }
                base += share
                logs.appendLine(r.log.takeLast(2000))
                return r
            }

            val h = step(headCommand(input, start, headDur, probe, headTs.absolutePath, enc), headDur, headShare)
            if (h.cancelled || isCancelled()) return Outcome(Status.CANCELLED, "đã huỷ")
            if (!h.success || !headTs.exists() || headTs.length() == 0L) return Outcome(Status.FAILED, "bước mã hoá phần đầu lỗi", logs.toString())

            val pieces = mutableListOf(headTs)
            if (nextKey != null) {
                val tailDur = end - nextKey
                val t = step(tailCommand(input, nextKey, tailDur, probe, tailTs.absolutePath), tailDur, 45)
                if (t.cancelled || isCancelled()) return Outcome(Status.CANCELLED, "đã huỷ")
                if (!t.success || !tailTs.exists() || tailTs.length() == 0L) return Outcome(Status.FAILED, "bước cắt phần còn lại lỗi", logs.toString())
                // Kiểm tra SỚM: đoạn đuôi phải dài ≈ end−nextKey. Dài hơn hẳn nghĩa là `-ss` copy nhảy về khung khoá trước đó
                // (container seek thưa) => ghép vào sẽ lặp hình ở chỗ nối; bỏ ngay, khỏi tốn thêm bước ghép.
                val tailActual = runner.probe(durationProbeCommand(tailTs.absolutePath))?.let { lastNumber(it) }
                if (tailActual == null || kotlin.math.abs(tailActual - tailDur) > TAIL_TOLERANCE_SEC) {
                    return Outcome(Status.FAILED, "đoạn đuôi dài ${tailActual?.let { "%.2f".format(Locale.US, it) } ?: "?"}s, kỳ vọng ${"%.2f".format(Locale.US, tailDur)}s — nghi `-ss` copy không rơi đúng khung khoá ${"%.3f".format(Locale.US, nextKey)}s", logs.toString())
                }
                pieces.add(tailTs)
            }

            listFile.writeText(pieces.joinToString("\n") { "file '${it.absolutePath.replace("'", "'\\''")}'" })
            val concatShare = 100 - base
            val c = step(concatCommand(listFile.absolutePath, probe, output), end - start, concatShare)
            if (c.cancelled || isCancelled()) { File(output).delete(); return Outcome(Status.CANCELLED, "đã huỷ") }
            val outFile = File(output)
            if (!c.success || !outFile.exists() || outFile.length() == 0L) {
                outFile.delete()
                return Outcome(Status.FAILED, "bước ghép + đóng gói lỗi", logs.toString())
            }

            // Kiểm tra kết quả: thời lượng + giải mã được quanh chỗ nối. Hỏng => xoá, để người gọi quay về cắt nhanh.
            val actual = runner.probe(durationProbeCommand(output))?.let { lastNumber(it) }
            val expected = end - start
            if (actual == null || kotlin.math.abs(actual - expected) > DURATION_TOLERANCE_SEC) {
                outFile.delete()
                return Outcome(Status.FAILED, "thời lượng kết quả ${actual?.let { "%.2f".format(Locale.US, it) } ?: "?"}s lệch kỳ vọng ${"%.2f".format(Locale.US, expected)}s", logs.toString())
            }
            if (probe.audioCodec != null) {
                // Hình/tiếng phải dài gần bằng nhau: bộ mã hoá lạ (vd phần cứng) có thể đổi mốc thời gian phần đầu so với audio copy.
                val vd = runner.probe(streamDurationProbeCommand(output, "v:0"))?.let { lastNumber(it) }
                val ad = runner.probe(streamDurationProbeCommand(output, "a:0"))?.let { lastNumber(it) }
                if (vd != null && ad != null && kotlin.math.abs(vd - ad) > SYNC_TOLERANCE_SEC) {
                    outFile.delete()
                    return Outcome(Status.FAILED, "hình dài ${"%.2f".format(Locale.US, vd)}s nhưng tiếng dài ${"%.2f".format(Locale.US, ad)}s (lệch > ${SYNC_TOLERANCE_SEC}s) — nghi lệch tiếng", logs.toString())
                }
            }
            if (nextKey != null) {
                val seam = nextKey - start
                val fps = if (probe.fps in 1.0..240.0) probe.fps else 25.0
                val window = 3.0
                val frames = runner.probe(framesProbeCommand(output, seam - 1.0, window))?.let { countFrameLines(it) } ?: -1
                val minFrames = (window * fps * 0.8).toInt()
                if (frames < minFrames) {
                    outFile.delete()
                    return Outcome(Status.FAILED, "giải mã được $frames khung quanh chỗ nối (cần ≥ $minFrames) — nghi hỏng tại chỗ nối", logs.toString())
                }
            }
            onProgress(100)
            val what = if (nextKey != null)
                "mã hoá lại ${"%.2f".format(Locale.US, headDur)}s đầu, giữ nguyên phần còn lại"
            else "mã hoá lại cả đoạn ngắn ${"%.2f".format(Locale.US, headDur)}s (nằm gọn trước khung khoá kế tiếp)"
            return Outcome(Status.EXACT_DONE, "cắt chính xác (${enc.ffName}): $what; thời lượng ${"%.2f".format(Locale.US, actual)}s", logs.toString())
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
