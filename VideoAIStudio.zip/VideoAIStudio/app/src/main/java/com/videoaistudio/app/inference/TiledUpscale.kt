package com.videoaistudio.app.inference

import java.util.concurrent.CancellationException

/**
 * [THÊM 12/10/2026] Chia ô (tiling) để chạy model upscale có KÍCH THƯỚC ĐẦU VÀO CỐ ĐỊNH (vd model đã
 * lượng tử hoá QDQ cho NPU Hexagon — QNN EP không nhận kích thước động) trên khung hình có kích thước
 * BẤT KỲ. Thuần Kotlin, KHÔNG phụ thuộc Android/ONNX Runtime — để kiểm tra số học độc lập (xem PROJECT_SPEC.md
 * mục 4.3 và mục 6, 12/10/2026).
 *
 * Cách làm ("cắt lõi" thay vì trộn mép — không cần bộ đệm số thực cỡ ảnh đầu ra):
 *  - Mỗi trục được chia thành các "lõi" (core) liền nhau, KHÔNG chồng, độ dài gần bằng nhau và ≤ tile − 2·pad.
 *  - Mỗi lõi được chạy bằng 1 ô (window) có kích thước ĐÚNG bằng đầu vào model, đặt sao cho lõi nằm trong ô và có
 *    thêm tối đa `pad` điểm ảnh "ngữ cảnh" mỗi bên (ngữ cảnh đủ khi không sát mép ảnh).
 *  - Chỉ phần LÕI của kết quả được ghi ra ảnh đầu ra; phần ngữ cảnh (nơi model hay sai vì thiếu láng giềng) bị bỏ.
 *  - Ảnh nhỏ hơn ô: ô thò ra ngoài ảnh, phần thò ra lấy lặp lại điểm ảnh biên (clamp-to-edge) rồi chỉ lấy phần ứng với ảnh thật.
 *
 * Giới hạn thành thật: nếu trường nhìn (receptive field) của model lớn hơn `pad`, vẫn có thể thấy đường nối giữa các ô.
 * `pad` mặc định ([DEFAULT_PAD_PX]) là SỐ ĐOÁN, chưa đo với model nào.
 */
object TiledUpscale {

    /** Số điểm ảnh ngữ cảnh mỗi bên (đầu vào) — số đoán, chưa kiểm với model thật. */
    const val DEFAULT_PAD_PX = 16

    /** Đoạn trên 1 trục: ô bắt đầu từ [windowStart]; lõi là [coreStart, coreEnd) (toạ độ ảnh đầu vào). */
    data class Span(val windowStart: Int, val coreStart: Int, val coreEnd: Int)

    /** Kết quả chạy 1 ô: điểm ảnh ARGB đã nhân hệ số của ô, rộng [width], cao [height]. */
    class TileResult(val pixels: IntArray, val width: Int, val height: Int)

    /** Nơi nhận kết quả: [begin] gọi đúng 1 lần (sau khi biết hệ số), rồi [write] cho từng vùng lõi. */
    interface Sink {
        fun begin(outWidth: Int, outHeight: Int)
        fun write(x: Int, y: Int, width: Int, height: Int, pixels: IntArray)
    }

    /** Pad thực dùng: không lớn hơn 1/8 cạnh ô (để lõi còn ≥ ~3/4 cạnh ô), không âm. */
    fun effectivePad(tileW: Int, tileH: Int, requested: Int = DEFAULT_PAD_PX): Int =
        maxOf(0, minOf(requested, minOf(tileW, tileH) / 8))

    /**
     * Chia 1 trục độ dài [size] thành các đoạn cho ô độ dài [tile]. Yêu cầu size ≥ 1, tile ≥ 1, 0 ≤ pad, 2·pad < tile.
     * - size ≤ tile: 1 đoạn duy nhất, ô bắt đầu ở 0 (có thể thò ra ngoài ảnh).
     * - size > tile: n = ceil(size / (tile − 2·pad)) lõi chia ĐỀU (chênh nhau tối đa 1 điểm ảnh), ô của mỗi lõi
     *   bắt đầu ở clamp(coreStart − pad, 0, size − tile) nên luôn nằm TRỌN trong ảnh.
     */
    fun plan(size: Int, tile: Int, pad: Int): List<Span> {
        require(size >= 1 && tile >= 1) { "size/tile phải ≥ 1 (size=$size, tile=$tile)" }
        require(pad >= 0 && 2L * pad < tile) { "pad=$pad không hợp lệ với tile=$tile" }
        if (size <= tile) return listOf(Span(0, 0, size))
        val coreMax = tile - 2 * pad
        val n = (size + coreMax - 1) / coreMax
        val spans = ArrayList<Span>(n)
        for (i in 0 until n) {
            val c0 = (i.toLong() * size / n).toInt()
            val c1 = ((i + 1).toLong() * size / n).toInt()
            val start = (c0 - pad).coerceIn(0, size - tile)
            spans.add(Span(start, c0, c1))
        }
        return spans
    }

    /** Lấy ô [tileW]×[tileH] từ ảnh [src] ([w]×[h]) bắt đầu ở ([x0],[y0]); phần thò ra ngoài ảnh lấy lặp điểm ảnh biên. */
    fun extractTile(src: IntArray, w: Int, h: Int, x0: Int, y0: Int, tileW: Int, tileH: Int): IntArray {
        val out = IntArray(tileW * tileH)
        val validW = minOf(tileW, w - x0)
        for (y in 0 until tileH) {
            val sy = minOf(y0 + y, h - 1)
            val rowStart = sy * w + x0
            val dst = y * tileW
            System.arraycopy(src, rowStart, out, dst, validW)
            if (validW < tileW) {
                val edge = src[sy * w + (w - 1)]
                for (x in validW until tileW) out[dst + x] = edge
            }
        }
        return out
    }

    /**
     * Chạy upscale theo ô cho ảnh [src] ([w]×[h], ARGB). [runTile] nhận điểm ảnh của 1 ô đúng cỡ [tileW]×[tileH] và trả
     * kết quả đã phóng; hệ số phóng suy ra từ kết quả của ô đầu tiên và PHẢI giống nhau ở mọi ô, là số nguyên và giống
     * nhau ở 2 chiều. [isCancelled] được hỏi trước mỗi ô; nếu true thì ném [CancellationException].
     * Ném IllegalStateException (thông báo tiếng Việt) nếu [runTile] trả null hoặc kết quả sai kích thước.
     * @return hệ số phóng.
     */
    fun run(
        src: IntArray, w: Int, h: Int,
        tileW: Int, tileH: Int, pad: Int,
        runTile: (IntArray) -> TileResult?,
        sink: Sink,
        isCancelled: () -> Boolean = { false }
    ): Int {
        require(src.size == w * h) { "src.size=${src.size} không khớp ${w}x$h" }
        val xs = plan(w, tileW, pad)
        val ys = plan(h, tileH, pad)
        var scale = 0
        var tileIndex = 0
        val total = xs.size * ys.size
        for (ySpan in ys) {
            for (xSpan in xs) {
                if (isCancelled()) throw CancellationException("Đã huỷ giữa chừng khi xử lý ô $tileIndex/$total")
                val tile = extractTile(src, w, h, xSpan.windowStart, ySpan.windowStart, tileW, tileH)
                val res = runTile(tile)
                    ?: throw IllegalStateException("Model không trả kết quả cho ô ${tileIndex + 1}/$total")
                if (res.width % tileW != 0 || res.height % tileH != 0 ||
                    res.width / tileW != res.height / tileH || res.width < tileW) {
                    throw IllegalStateException(
                        "Kết quả ô ${res.width}x${res.height} không phải bội số nguyên đều của đầu vào ${tileW}x$tileH " +
                            "— model này không phải kiểu upscale theo hệ số nguyên."
                    )
                }
                if (res.pixels.size != res.width * res.height) {
                    throw IllegalStateException("Số điểm ảnh kết quả (${res.pixels.size}) không khớp ${res.width}x${res.height}")
                }
                val s = res.width / tileW
                if (scale == 0) {
                    scale = s
                    sink.begin(w * scale, h * scale)
                } else if (s != scale) {
                    throw IllegalStateException("Hệ số phóng thay đổi giữa các ô ($scale rồi $s)")
                }
                val cw = xSpan.coreEnd - xSpan.coreStart
                val ch = ySpan.coreEnd - ySpan.coreStart
                val region = IntArray(cw * scale * ch * scale)
                val srcX = (xSpan.coreStart - xSpan.windowStart) * scale
                val srcY = (ySpan.coreStart - ySpan.windowStart) * scale
                val rowLen = cw * scale
                for (r in 0 until ch * scale) {
                    System.arraycopy(res.pixels, (srcY + r) * res.width + srcX, region, r * rowLen, rowLen)
                }
                sink.write(xSpan.coreStart * scale, ySpan.coreStart * scale, rowLen, ch * scale, region)
                tileIndex++
            }
        }
        return scale
    }

    /** Số ô sẽ phải chạy cho 1 khung hình [w]×[h] (để ước lượng thời gian/hiển thị). */
    fun tileCount(w: Int, h: Int, tileW: Int, tileH: Int, pad: Int): Int =
        plan(w, tileW, pad).size * plan(h, tileH, pad).size
}
