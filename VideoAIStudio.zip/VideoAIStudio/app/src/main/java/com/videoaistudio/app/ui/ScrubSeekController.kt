package com.videoaistudio.app.ui

import android.os.Handler
import android.os.SystemClock

/**
 * Điều phối `seekTo()` KIỂU VÒNG KÍN cho lúc kéo RangeSlider (xem trước khung hình).
 *
 * VÌ SAO KHÔNG DÙNG "TICKER MỞ VÒNG" (100ms/lần) NỮA — lần sửa thứ 5 cho đúng 1 bug
 * "kéo slider mà preview không di chuyển theo":
 *  - Mỗi `ExoPlayer.seekTo()` HUỶ seek đang xử lý dở và FLUSH decoder. Muốn ra 1 khung
 *    hình, 1 seek phải sống sót đủ lâu để: nạp dữ liệu tại vị trí mới -> decode khung hình
 *    khoá -> vẽ lên Surface (gọi tắt là "độ trễ ra khung hình").
 *  - Ticker cũ bắn seek MỖI 100ms bất kể seek trước đã ra hình chưa, và CÒN bắn lại cả khi vị
 *    trí KHÔNG ĐỔI (ngón tay đứng yên). Nếu độ trễ ra khung hình > 100ms thì seek sau luôn
 *    chen vào huỷ seek trước -> KHÔNG BAO GIỜ có khung hình nào được vẽ cho tới lúc thả tay
 *    (đúng triệu chứng gốc). Độ trễ phụ thuộc vị trí trong video (khung hình khoá to/nhỏ, dữ
 *    liệu đã nằm trong cache hệ thống chưa...) nên có đoạn đầu video <100ms (preview chạy),
 *    đoạn sau >100ms (preview đứng) — khớp với "lúc đầu theo, lúc sau không theo". Mọi bản
 *    sửa trước đều chỉnh CON SỐ nhịp (90/60/100ms) thay vì dựa vào tín hiệu "đã xong".
 *  - Cách này: chỉ cho phép 1 seek "đang bay"; seek kế tiếp CHỈ bắn khi player báo đã xong seek
 *    trước (xem `onSeekSettled`), luôn tới vị trí NGÓN TAY MỚI NHẤT (các vị trí trung gian bị bỏ),
 *    và KHÔNG bắn lại nếu vị trí trùng lần vừa bắn. Có van an toàn (watchdog) nếu tín hiệu bị mất.
 *
 * Tín hiệu "đã xong" được `VideoToolsActivity` nối vào là `Player.STATE_READY` (ExoPlayer luôn
 * đưa trạng thái về BUFFERING ngay khi seekTo, rồi chỉ về READY sau khi renderer video đã vẽ
 * khung hình đầu tiên + đủ buffer; các cập nhật trạng thái cũ bị loại bỏ trong lúc có seek mới
 * chưa xác nhận -> không bị "tín hiệu cũ của seek trước" đánh lừa). KHÔNG dùng
 * `onPositionDiscontinuity(SEEK)` — bản sửa 02/09/2026 đã sai chính vì tín hiệu đó bắn NGAY
 * LẬP TỨC, không gắn với việc vẽ hình.
 *
 * Mọi hàm gọi trên MAIN thread (cùng thread với Handler truyền vào).
 */
class ScrubSeekController(
    private val handler: Handler,
    /** Van an toàn: nếu quá thời gian này mà không có tín hiệu "xong", coi như xong để khỏi kẹt. Phải DÀI hơn nhiều so với độ trễ ra hình bình thường (nếu ngắn, chính van này sẽ chen vào huỷ seek đang chờ). */
    private val timeoutMs: Long = 800L,
    /** Khoảng cách tối thiểu giữa 2 lần bắn seek — tránh bắn dồn khi seek ra hình cực nhanh. */
    private val minGapMs: Long = 30L,
    private val doSeek: (Long) -> Unit
) {
    private var active = false
    private var pendingMs = NONE
    private var inFlight = false
    private var lastIssuedMs = NONE
    private var lastIssuedAt = 0L
    private var firstDispatchDone = false

    // Số liệu để ghi log debug (thay vì phải đoán bằng cảm giác như 4 lần trước).
    private var issued = 0
    private var settled = 0
    private var timeouts = 0
    private var skippedSame = 0
    private var framesRendered = 0
    private var latencySumMs = 0L
    private var latencyMaxMs = 0L
    private var beganAt = 0L

    val isActive: Boolean get() = active

    private val watchdog = Runnable {
        if (inFlight) {
            inFlight = false
            timeouts++
            dispatchIfPossible()
        }
    }
    private val gapRunnable = Runnable { dispatchIfPossible() }

    /** Gọi ở `onStartTrackingTouch`. */
    fun begin() {
        cancelTimers()
        active = true
        pendingMs = NONE
        inFlight = false
        lastIssuedMs = NONE
        lastIssuedAt = 0L
        firstDispatchDone = false
        issued = 0; settled = 0; timeouts = 0; skippedSame = 0; framesRendered = 0
        latencySumMs = 0L; latencyMaxMs = 0L
        beganAt = SystemClock.uptimeMillis()
    }

    /** Gọi mỗi khi vị trí ngón tay đổi (có thể rất dày — mỗi pixel). Rẻ: chỉ ghi nhớ rồi thử bắn. */
    fun update(positionMs: Long) {
        if (!active) return
        pendingMs = positionMs
        dispatchIfPossible()
    }

    /** Nối vào `Player.Listener.onPlaybackStateChanged(STATE_READY)`: seek đang bay đã ra hình. */
    fun onSeekSettled() {
        if (!active || !inFlight) return
        inFlight = false
        settled++
        val latency = SystemClock.uptimeMillis() - lastIssuedAt
        latencySumMs += latency
        if (latency > latencyMaxMs) latencyMaxMs = latency
        handler.removeCallbacks(watchdog)
        dispatchIfPossible()
    }

    /** Nối vào `Player.Listener.onRenderedFirstFrame()` — CHỈ để đếm số liệu chẩn đoán, không điều khiển luồng. */
    fun noteFrameRendered() {
        if (active) framesRendered++
    }

    /** Gọi ở `onStopTrackingTouch`. Trả về chuỗi số liệu để ghi log. */
    fun end(): String {
        val elapsed = SystemClock.uptimeMillis() - beganAt
        val summary = summary(elapsed)
        active = false
        cancelTimers()
        inFlight = false
        pendingMs = NONE
        return summary
    }

    private fun summary(elapsedMs: Long): String {
        val avg = if (settled > 0) latencySumMs / settled else -1L
        return "kéo ${elapsedMs}ms: bắn $issued seek, $settled xong (READY), $framesRendered khung hình vẽ, " +
            "$timeouts timeout, $skippedSame bỏ-vì-trùng-vị-trí, trễ trung bình ${avg}ms / tối đa ${latencyMaxMs}ms"
    }

    private fun cancelTimers() {
        handler.removeCallbacks(watchdog)
        handler.removeCallbacks(gapRunnable)
    }

    private fun dispatchIfPossible() {
        if (!active || inFlight || pendingMs == NONE) return
        if (pendingMs == lastIssuedMs) {
            // Ngón tay đứng yên đúng vị trí vừa seek: KHÔNG seek lại (seek lại = flush decoder vô ích).
            pendingMs = NONE
            skippedSame++
            return
        }
        if (firstDispatchDone) {
            val sinceLast = SystemClock.uptimeMillis() - lastIssuedAt
            if (sinceLast < minGapMs) {
                handler.removeCallbacks(gapRunnable)
                handler.postDelayed(gapRunnable, minGapMs - sinceLast)
                return
            }
        }
        val target = pendingMs
        pendingMs = NONE
        lastIssuedMs = target
        lastIssuedAt = SystemClock.uptimeMillis()
        firstDispatchDone = true
        // Đặt inFlight + watchdog TRƯỚC khi gọi doSeek: phòng trường hợp tín hiệu "xong" đến đồng bộ.
        inFlight = true
        issued++
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, timeoutMs)
        try {
            doSeek(target)
        } catch (e: Exception) {
            // Player chưa sẵn sàng/đã release: không kẹt cờ inFlight.
            inFlight = false
            handler.removeCallbacks(watchdog)
        }
    }

    private companion object {
        const val NONE = -1L
    }
}
