package com.videoaistudio.app.video

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.videoaistudio.app.debug.DebugLog

/**
 * [THÊM 17/11/2026] Dọn bản copy video đang làm việc NGAY KHI người dùng VUỐT XOÁ app khỏi danh sách ứng dụng gần đây.
 *
 * TẠI SAO LÀ SERVICE: `Service.onTaskRemoved()` là chỗ Android tài liệu hoá để báo "người dùng vừa gỡ task của app khỏi
 * recents" — khác `Activity.onStop()` (xảy ra cả khi chỉ che màn hình vài giây: trình chọn nơi lưu, Home, tắt màn hình —
 * chính vì thế cơ chế dọn ở `onStop` đã bị gỡ ngày 17/11/2026, xem VideoAIStudioApp). Service khai báo
 * `android:stopWithTask="false"` nên KHÔNG bị dừng cùng task và nhận được callback này.
 *
 * Service này chỉ được bật SAU KHI có bản copy video (xem [ensureStarted], gọi từ FileUtils.copyUriToCache) — không bật
 * lúc chưa có gì để dọn. Nó không làm gì khác: không foreground, không thông báo, không giữ wakelock.
 *
 * 🔴 CHƯA TEST TRÊN MÁY THẬT. Giới hạn đã biết (nói thẳng, không phải lỗi sẽ sửa được trong app):
 *  1. Một số hãng (Xiaomi/Huawei/Oppo... có lớp quản lý RAM riêng) có thể giết hẳn tiến trình khi vuốt xoá mà KHÔNG gọi
 *     `onTaskRemoved` => lần đó vẫn giữ nguyên hành vi cũ (bản copy còn đến lần mở màn hình công cụ kế tiếp).
 *  2. Android 8+ có thể dừng service nền nhàn rỗi sau một thời gian app ở nền => vuốt xoá SAU KHI app đã nằm nền lâu
 *     cũng có thể không có service nào để nhận callback. Vuốt xoá ngay sau khi vừa rời app (trường hợp thường gặp) thì ổn.
 *  3. Không dọn khi Compress đang chạy nền (CompressService đọc chính thư mục này) — cùng quy tắc ở bản Application cũ.
 *  Thư mục rác sót lại (tiến trình bị giết giữa lúc xoá) vẫn được dọn ở lần khởi động sau như cũ.
 */
class TaskCleanupService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Không tự hồi sinh: nếu hệ thống giết service thì thôi (lần sau có bản copy mới sẽ bật lại).
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        try {
            val compressRunning = CompressService.CompressResultHolder.isRunning
            DebugLog.log(
                applicationContext, "TaskCleanupService",
                "onTaskRemoved (vuốt xoá app) — Compress đang chạy=$compressRunning; " + FileUtils.describeInputState(applicationContext, null)
            )
            if (!compressRunning) FileUtils.clearVideoInputCache(applicationContext)
        } catch (e: Exception) {
            // dọn best-effort; không được làm sập tiến trình đang bị đóng
        } finally {
            stopSelf()
        }
    }

    companion object {
        /**
         * Bật service (nếu chưa chạy). An toàn khi gọi nhiều lần và từ luồng nền. Android 8+ cấm bật service nền khi app
         * không ở foreground => có thể ném IllegalStateException; nuốt lỗi và ghi log (không có gì để dọn vẫn là bình thường).
         */
        fun ensureStarted(context: Context) {
            try {
                val app = context.applicationContext
                app.startService(Intent(app, TaskCleanupService::class.java))
            } catch (e: Exception) {
                try {
                    DebugLog.log(context.applicationContext, "TaskCleanupService", "Không bật được dịch vụ dọn khi vuốt xoá: ${e.javaClass.simpleName}: ${e.message}")
                } catch (e2: Exception) { /* log là phụ */ }
            }
        }
    }
}
