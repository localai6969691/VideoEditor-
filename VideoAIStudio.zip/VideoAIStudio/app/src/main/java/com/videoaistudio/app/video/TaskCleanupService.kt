package com.videoaistudio.app.video

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.videoaistudio.app.debug.DebugLog

/**
 * [THÊM 17/11/2026, SỬA LẠI 18–19/11/2026] Dọn bản copy video đang làm việc NGAY KHI người dùng VUỐT XOÁ app khỏi
 * danh sách ứng dụng gần đây.
 *
 * TẠI SAO LÀ SERVICE: `Service.onTaskRemoved()` là chỗ Android tài liệu hoá để báo "người dùng vừa gỡ task của app khỏi
 * recents" — khác `Activity.onStop()` (xảy ra cả khi chỉ che màn hình vài giây — chính vì thế cơ chế dọn ở `onStop` đã
 * bị gỡ ngày 17/11/2026, xem VideoAIStudioApp). Service khai báo `android:stopWithTask="false"` nên KHÔNG bị dừng cùng task.
 *
 * LẦN SỬA 18–19/11/2026 — LOG THẬT chứng minh bản 17/11 (service thường, nền) KHÔNG đủ: người dùng vuốt xoá lúc 10:38:33
 * nhưng không có dòng log nào của service, `ApplicationExitInfo` ghi `importance=400` (CACHED = không có service nào đang chạy)
 * và app đã nằm nền 114s trước đó. Android dừng service nền nhàn rỗi sau ~1 phút app ở nền (hạn chế thực thi nền từ Android 8)
 * ⇒ lúc vuốt xoá đã không còn service nào để nhận `onTaskRemoved`. (Suy luận mạnh; lần đó chưa ghi log vòng đời service nên chưa
 * có dòng log nào chứng minh trực tiếp "service bị dừng lúc nào".)
 * Cách sửa: chạy service ở chế độ FOREGROUND (kèm thông báo yên lặng, mức IMPORTANCE_MIN) suốt thời gian có bản copy — service
 * foreground KHÔNG bị dừng khi app nằm nền và tiến trình không còn ở trạng thái cached. Đánh đổi nói thẳng: trong lúc có bản
 * copy video sẽ có 1 thông báo nhỏ "Đang giữ bản copy video…"; thoát màn hình bình thường (hoặc vuốt xoá) thì thông báo mất.
 * Việc xoá làm ĐỒNG BỘ ngay trong service ([FileUtils.clearVideoInputCacheNow]) chứ không "đổi tên rồi xoá nền" như
 * `clearVideoInputCache`: tiến trình có thể bị giết ngay sau khi task bị gỡ, xoá nền dở dang sẽ để lại thư mục rác (GB) đến lần mở sau.
 *
 * Vòng đời: được bật ([ensureStarted]) ở cuối `FileUtils.copyUriToCache` và mỗi khi app quay lại foreground mà còn bản copy
 * (VideoAIStudioApp.onActivityStarted); tự tắt khi bản copy bị dọn bình thường ([stop], gọi cuối `clearVideoInputCache`) hoặc sau
 * khi dọn do vuốt xoá.
 *
 * 🔴 CHƯA TEST TRÊN MÁY THẬT. Giới hạn đã biết (không phải lỗi sửa được trong app):
 *  1. Hãng nào giết tiến trình khi vuốt xoá mà KHÔNG gọi `onTaskRemoved` (một số ROM Xiaomi/Huawei/Oppo...) thì vẫn như cũ:
 *     bản copy còn đến lần mở màn hình công cụ kế tiếp.
 *  2. Android 14+: service foreground loại `dataSync` phải được bật khi app đang ở foreground — nếu app đã rời foreground lúc copy
 *     xong thì không bật được (ghi log `startForegroundService THẤT BẠI`); lần quay lại app sẽ bật lại ([ensureStarted] ở onActivityStarted).
 *  3. Android 15+ có giới hạn thời gian cho `dataSync` (6h/24h) khi targetSdk ≥ 35 — app đang targetSdk 34 nên chưa dính; nếu nâng
 *     targetSdk phải xử lý `onTimeout`.
 *  4. Không dọn khi Compress đang chạy nền (CompressService đọc chính thư mục này).
 *  Thư mục rác sót lại (tiến trình bị giết giữa lúc xoá) vẫn được dọn ở lần khởi động sau như cũ.
 */
class TaskCleanupService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        log("onCreate — service được tạo")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fgRequired = intent?.getBooleanExtra(EXTRA_FG_REQUIRED, false) == true
        try {
            createChannelIfNeeded()
            startForeground(NOTIF_ID, buildNotification())
            log("startForeground() THÀNH CÔNG (startId=$startId, bật bằng startForegroundService=$fgRequired)")
        } catch (e: Exception) {
            log("startForeground() THẤT BẠI: ${e.javaClass.simpleName}: ${e.message} (bật bằng startForegroundService=$fgRequired)")
            // Đã gọi startForegroundService mà không startForeground được => hệ thống sẽ ném RemoteServiceException sau vài giây
            // và làm SẬP app. Tự dừng để tránh; hậu quả chỉ là mất tính năng dọn-khi-vuốt-xoá lần này.
            if (fgRequired) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        // Không tự hồi sinh: nếu hệ thống giết service thì thôi (lần sau có bản copy mới / app quay lại foreground sẽ bật lại).
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val app = applicationContext
        val compressRunning = try { CompressService.CompressResultHolder.isRunning } catch (e: Exception) { false }
        log("onTaskRemoved (vuốt xoá app) — Compress đang chạy=$compressRunning; " + FileUtils.describeInputState(app, null))
        // Làm ở luồng riêng (xoá file GB có thể chặn nhiều giây — log 17/11 có File.delete treo 2–5s trên luồng chính) và ĐỒNG BỘ;
        // service còn sống đến khi xoá xong nên tiến trình không bị giết giữa chừng.
        Thread {
            try {
                if (!compressRunning) FileUtils.clearVideoInputCacheNow(app, "TaskCleanupService.onTaskRemoved")
                else log("Bỏ qua dọn vì Compress đang chạy — bản copy còn đến lần mở màn hình công cụ kế tiếp")
            } catch (e: Exception) {
                log("dọn khi vuốt xoá LỖI: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { /* không quan trọng */ }
                stopSelf()
            }
        }.apply { name = "task-cleanup" }.start()
    }

    override fun onDestroy() {
        // Dòng này cho biết service bị dừng lúc nào (tự dừng sau khi dọn / do clearVideoInputCache gọi stop / hệ thống dừng).
        log("onDestroy — service bị dừng")
        super.onDestroy()
    }

    private fun log(msg: String) {
        try { DebugLog.log(applicationContext, "TaskCleanupService", msg) } catch (e: Exception) { /* log là phụ */ }
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Bản video đang làm việc", NotificationManager.IMPORTANCE_MIN)
            channel.setShowBadge(false)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        // Chạm vào thông báo = mở lại app như bấm biểu tượng (đưa task đang có lên trước, KHÔNG tạo màn hình mới —
        // màn hình công cụ mới sẽ dọn mất bản copy ở onCreate).
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pending = launch?.let { PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE) }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Video AI Studio")
            .setContentText("Đang giữ bản copy video để chỉnh sửa — vuốt xoá app sẽ tự dọn")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .apply { if (pending != null) setContentIntent(pending) }
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "video_cache_holder"
        private const val NOTIF_ID = 1002 // CompressService dùng 1001
        private const val EXTRA_FG_REQUIRED = "fg_required"

        /**
         * Bật service (nếu chưa chạy) ở chế độ foreground. An toàn khi gọi nhiều lần và từ luồng nền. Android 12+ cấm bật
         * service foreground khi app không ở foreground => có thể ném exception; nuốt lỗi, ghi log, thử bật service thường
         * (sẽ bị hệ thống dừng sau ~1 phút nền nhưng vẫn bắt được vuốt xoá NGAY sau khi rời app).
         */
        fun ensureStarted(context: Context) {
            val app = context.applicationContext
            try {
                val intent = Intent(app, TaskCleanupService::class.java).putExtra(EXTRA_FG_REQUIRED, true)
                ContextCompat.startForegroundService(app, intent)
                logStatic(app, "ensureStarted — đã gọi startForegroundService")
            } catch (e: Exception) {
                logStatic(app, "ensureStarted — startForegroundService THẤT BẠI: ${e.javaClass.simpleName}: ${e.message}; thử startService thường")
                try {
                    app.startService(Intent(app, TaskCleanupService::class.java))
                } catch (e2: Exception) {
                    logStatic(app, "ensureStarted — startService thường cũng THẤT BẠI: ${e2.javaClass.simpleName}: ${e2.message}")
                }
            }
        }

        /**
         * Tắt service (và thông báo) khi bản copy đã được dọn bình thường. KHÔNG tắt nếu vẫn còn bản copy (vd một màn hình khác
         * vừa copy xong video mới giữa lúc màn hình cũ đang dọn).
         */
        fun stop(context: Context) {
            val app = context.applicationContext
            try {
                if (FileUtils.hasWorkingCopy(app)) return
                app.stopService(Intent(app, TaskCleanupService::class.java))
            } catch (e: Exception) {
                logStatic(app, "stop THẤT BẠI: ${e.javaClass.simpleName}: ${e.message}")
            }
        }

        private fun logStatic(app: Context, msg: String) {
            try { DebugLog.log(app, "TaskCleanupService", msg) } catch (e: Exception) { /* log là phụ */ }
        }
    }
}
