package com.videoaistudio.app.video

import java.util.Locale

/**
 * [THÊM 19/11/2026] CẮT CHÍNH XÁC KHÔNG MÃ HOÁ LẠI ("edit list"), thay cho smart cut mã hoá lại ([SmartCut]).
 *
 * VÌ SAO CÓ FILE NÀY: người dùng (19/11/2026) từ chối smart cut: "cắt chính xác là phải encode lại, vừa lâu, vừa làm hư
 * frame hết". Smart cut phải mã hoá lại vài giây đầu (tới khung khoá kế tiếp) nên chậm và đổi chất lượng khung hình.
 * Cách ở đây KHÔNG đụng tới dữ liệu hình/tiếng — vẫn là `-c copy`.
 *
 * Ý TƯỞNG: `-c copy` chỉ bắt đầu giải mã được tại KHUNG KHOÁ K ≤ S (S = điểm người dùng chọn). Cách cũ (`-avoid_negative_ts
 * make_zero`) dồn mốc thời gian để file bắt đầu tại K => file cắt ra dài hơn/bắt đầu sớm hơn điểm chọn (tới cả 1 GOP).
 * Cách mới: bỏ `make_zero`, để các gói từ K tới S mang mốc thời gian ÂM; bộ ghi mp4/mov ghi vào file một "edit list"
 * (hộp `edts/elst`) nói "bắt đầu phát từ đúng S". Trình phát hiểu edit list sẽ giải mã K..S nhưng KHÔNG hiện, hiện từ
 * đúng S. Dữ liệu từ K tới S vẫn nằm trong file (ẩn) => file lớn hơn tối đa ~1 GOP.
 *
 * ĐÃ ĐO BẰNG FFMPEG 6.1.1 THẬT (cùng dòng 6.1 với FFmpegKit của app) trên file giả lập (có/không B-frame, mở/đóng GOP,
 * H.264/HEVC, có/không tiếng, 25 và 29,97 fps) — 31/31 điểm cắt (sát/lệch khung khoá, đầu/giữa/cuối file): khung hình
 * đầu tiên giải mã ra ĐÚNG khung có mốc ≥ S; mọi khung giống từng bit với khung nguồn (không mã hoá lại); lệch tiếng so
 * với nguồn 0.0 ms (đo bằng tương quan chéo trên tiếng nhiễu). Xem tools/tests/editlistcut.
 *
 * GIỚI HẠN — NÓI THẲNG (đã đo hoặc suy ra từ cách làm, KHÔNG phải đã thử trên máy người dùng):
 *  1. Chỉ có hiệu lực khi trình phát TÔN TRỌNG edit list. ffmpeg/ffprobe: có (đã đo). ExoPlayer/trình phát khác trên máy:
 *     🔴 CHƯA TEST. Trình phát bỏ qua edit list sẽ hiện thêm đoạn đệm K..S ở đầu (= hành vi cũ khi cắt nhanh). Chỉ đo được với
 *     ffmpeg đọc thô (`ignore_editlist 1`): hình và tiếng vẫn KHỚP nhau (cả hai cùng trễ ~85ms so với nguồn); các trình phát khác chưa thử.
 *  2. Cắt TRỰC TIẾP chỉ cho mp4/m4v(ghi dạng mp4)/mov. mkv/flv/3gp: nếu codec hợp MP4 (H.264/H.265 + AAC/MP3/AC3/E-AC3) thì cắt
 *     thẳng sang file .mp4 (đổi vỏ, vẫn không mã hoá lại) — đã đo mkv/flv/3gp: khung đầu đúng, tiếng lệch ≤0.2ms ([remuxSupportedFor],
 *     [codecsFitMp4]). ĐÃ ĐO KHÔNG DÙNG ĐƯỢC: .ts (seek theo vị trí gói, không theo khung khoá => file ra MẤT HÌNH, chỉ còn tiếng —
 *     [checkOutput] có chốt chặn "không có luồng hình"), .avi (lệch 1–2 khung ở vài điểm cắt, tiếng lệch ~5ms), webm/VP9/Opus
 *     (codec không hợp). Các trường hợp đó: app hỏi người dùng chọn Convert (mã hoá lại toàn bộ) hoặc cắt nhanh.
 *  3. ĐIỂM KẾT THÚC vẫn như cách cũ: `-t` tính theo mốc giải mã (dts) nên có thể dư vài khung ở cuối (đo 0.06–0.25s) và rơi
 *     1–2 khung B cuối. Không phải lỗi mới.
 *  4. GHÉP bằng `concat` demuxer (-c copy) file có đoạn đệm bị SAI điểm đầu (đo: file thử bắt đầu sớm ~1s, thời lượng
 *     dư) => [VideoEngine.merge] phát hiện ([parsePreRoll]) và đọc file đó theo kiểu thô (`option ignore_editlist 1`):
 *     ghép đúng + đồng bộ nhưng đoạn đệm LỘ RA ở đầu phần đó (nói rõ trong ghi chú kết quả).
 *  5. Cắt tiếp từ file ĐÃ cắt kiểu này với "Cắt chính xác" BẬT: đúng (đã đo, cascade). Với công tắc TẮT (khung khoá) trên
 *     file có đoạn đệm: chưa kiểm — mốc khung khoá đọc từ ffprobe là mốc ÂM.
 *
 * File thuần JVM (không Android) để test bằng kotlinc + ffmpeg thật.
 */
object EditListCut {

    /** Trả tên muxer ffmpeg (`-f`) cho đuôi file, hoặc null nếu không hỗ trợ edit list. m4v ghi dạng mp4 (muxer "m4v" của ffmpeg là H.264 thô!). */
    fun muxerFor(ext: String): String? = when (ext.lowercase(Locale.ROOT)) {
        "mp4", "m4v" -> "mp4"
        "mov" -> "mov"
        else -> null
    }

    /** Đuôi KHÔNG phải mp4/mov nhưng đã đo cắt thẳng sang MP4 (-f mp4) đúng khung đầu + không mã hoá lại. Chỉ là điều kiện CẦN — còn phải [codecsFitMp4]. */
    private val REMUX_SOURCES = setOf("mkv", "flv", "3gp")
    fun remuxSupportedFor(ext: String): Boolean = ext.lowercase(Locale.ROOT) in REMUX_SOURCES

    class Codecs(val video: String?, val audio: String?)

    fun codecProbeCommand(file: String): String =
        "-v error -show_entries stream=codec_type,codec_name -of csv=p=0 \"$file\""

    /** Đọc đầu ra [codecProbeCommand]: mỗi dòng dạng `h264,video` / `aac,audio` (thứ tự 2 cột do ffprobe quyết định). Lấy luồng hình và tiếng ĐẦU TIÊN. */
    fun parseCodecs(probeOutput: String): Codecs {
        var v: String? = null; var a: String? = null
        for (line in probeOutput.lineSequence()) {
            val parts = line.trim().split(",").map { it.trim().lowercase(Locale.ROOT) }
            if (parts.size != 2) continue
            val kind = parts.firstOrNull { it == "video" || it == "audio" } ?: continue
            val name = parts.first { it != kind }
            if (kind == "video" && v == null) v = name
            if (kind == "audio" && a == null) a = name
        }
        return Codecs(v, a)
    }

    /** Codec hợp để đổi vỏ sang MP4 (phát được rộng rãi trên Android): hình H.264/H.265; tiếng không có hoặc AAC/MP3/AC3/E-AC3. */
    fun codecsFitMp4(c: Codecs): Boolean =
        (c.video == "h264" || c.video == "hevc") && (c.audio == null || c.audio in setOf("aac", "mp3", "ac3", "eac3"))

    private fun f3(v: Double) = String.format(Locale.US, "%.3f", v)

    /**
     * Lệnh cắt. `-ss` ĐÚNG [startSec] (không cộng lề như `copySeekArg`: ở đây `-ss` hơi thấp hơn khung khoá chỉ làm đoạn đệm dài
     * thêm 1 GOP, kết quả vẫn đúng — đã đo S=9.98 với khung khoá ở 10.0). KHÔNG có `-avoid_negative_ts make_zero`; ghi rõ `disabled`
     * để không phụ thuộc chế độ `auto` của từng bản ffmpeg.
     */
    fun command(input: String, output: String, startSec: Double, durationSec: Double, muxer: String, remux: Boolean = false): String =
        // remux=true (nguồn mkv/flv/3gp -> MP4): chỉ lấy 1 luồng hình + (nếu có) 1 luồng tiếng, bỏ phụ đề/dữ liệu — mp4 không nhận phụ đề mkv (subrip)
        // và sẽ làm lệnh thất bại.
        "-y -ss ${f3(startSec)} -i \"$input\" -t ${f3(durationSec)}${if (remux) " -map 0:v:0 -map 0:a:0? -sn -dn" else ""} " +
            "-c copy -avoid_negative_ts disabled -f $muxer \"$output\""

    /** Đọc gói hình đầu tiên (mốc hiển thị + cờ). Ví dụ đầu ra: `-4.320000,KD_`. */
    fun firstPacketProbeCommand(file: String): String =
        "-v error -select_streams v:0 -show_entries packet=pts_time,flags -of csv=p=0 -read_intervals \"%+#1\" \"$file\""

    fun durationProbeCommand(file: String): String =
        "-v error -show_entries format=duration -of csv=p=0 \"$file\""

    private val PACKET_LINE = Regex("""^\s*(-?\d+(?:\.\d+)?),([A-Za-z_]+)\s*$""")

    /**
     * Số giây ĐỆM ở đầu file (khung từ K tới S, ẩn nhờ edit list) đọc từ gói hình đầu tiên: mốc hiển thị ÂM + cờ `D` (discard).
     * 0.0 nếu không có đoạn đệm hoặc không đọc được. Bỏ qua mọi dòng nhiễu của log ffprobe.
     */
    fun parsePreRoll(probeOutput: String): Double {
        for (line in probeOutput.lineSequence()) {
            val m = PACKET_LINE.matchEntire(line) ?: continue
            val pts = m.groupValues[1].toDoubleOrNull() ?: continue
            val flags = m.groupValues[2]
            return if (pts < 0.0 && flags.contains('D')) -pts else 0.0
        }
        return 0.0
    }

    /** Thời lượng (giây) từ đầu ra [durationProbeCommand]; null nếu không đọc được. */
    fun parseDuration(probeOutput: String): Double? {
        for (line in probeOutput.lineSequence()) {
            val t = line.trim()
            if (t.isEmpty()) continue
            val v = t.toDoubleOrNull() ?: continue
            if (v.isFinite() && v > 0.0) return v
        }
        return null
    }

    /** Dư/thiếu thời lượng cho phép giữa file ra và [expectedSec]: dư vài khung do `-t` tính theo dts (đo tới 0.25s) + dự phòng. */
    const val DURATION_TOLERANCE_SEC = 0.8

    /**
     * Kiểm file ra sau khi cắt. Trả null nếu hợp lý, ngược lại là lý do (để quay về cắt nhanh). Bắt trường hợp edit list KHÔNG
     * được ghi (bản ffmpeg/muxer lạ): lúc đó thời lượng = dự kiến + đoạn đệm (đo: 14.4s thay vì 10s).
     */
    fun checkOutput(outputExists: Boolean, outputBytes: Long, durationSec: Double?, expectedSec: Double, hasVideoStream: Boolean = true): String? {
        if (!outputExists || outputBytes <= 0L) return "không tạo được file ra"
        // Chốt chặn đã đo thật: nguồn .ts + `-ss` => ffmpeg không gặp khung khoá nào trong đoạn cắt => file ra CHỈ CÒN TIẾNG (thời lượng vẫn "đúng").
        if (!hasVideoStream) return "file ra không có luồng hình"
        if (durationSec == null) return "không đọc được thời lượng file ra"
        val tol = maxOf(DURATION_TOLERANCE_SEC, 0.05 * expectedSec)
        if (durationSec < expectedSec - tol) return "file ra ngắn hơn dự kiến (${f3(durationSec)}s thay vì ${f3(expectedSec)}s)"
        if (durationSec > expectedSec + DURATION_TOLERANCE_SEC) return "file ra dài hơn dự kiến (${f3(durationSec)}s thay vì ${f3(expectedSec)}s) — có thể edit list không được ghi"
        return null
    }

    /** Dòng ghi chú cho người dùng khi cắt chính xác thành công. [preRollSec] từ [parsePreRoll]. */
    fun describeSuccess(preRollSec: Double): String =
        if (preRollSec > 0.05)
            "Cắt chính xác, KHÔNG mã hoá lại. File chứa thêm ~${String.format(Locale.US, "%.1f", preRollSec)}s dữ liệu đệm ở đầu (ẩn khi phát bằng " +
                "trình phát hiểu edit list; trình phát khác có thể hiện đoạn này). Hãy xem thử file ở trình phát bạn dùng."
        else
            "Điểm bắt đầu trùng khung khoá nên cắt giữ nguyên, không cần đoạn đệm."
}
