package com.videoaistudio.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.videoaistudio.app.databinding.ActivityMainBinding
import com.videoaistudio.app.inference.InferenceManager

/**
 * Màn hình chính chỉ điều hướng tới từng tính năng.
 * Các thao tác video (trim/split/merge/tách audio/tách phụ đề/nén) đều trỏ vào
 * VideoToolsActivity, chỉ khác chế độ khởi tạo ban đầu — Trim và Split đã được gộp
 * thành 1 (TRIM_SPLIT) vì bản chất cùng là "cắt theo mốc thời gian", chỉ khác số
 * lượng đoạn.
 *
 * 2 nút phụ đề (09/09/2026, cập nhật lại cùng ngày) — GOM CHUNG theo chủ đề "phụ đề"
 * chứ không theo việc tính năng đó dùng chung code với thao tác nào:
 *  - btnExtractSubtitle → EXTRACT_HARDSUB (tách phụ đề bằng OCR, đứng độc lập).
 *  - btnBurnSubtitle → vẫn mở TRIM_SPLIT (vì ghép phụ đề bắt buộc đi kèm chọn đoạn cắt,
 *    dùng lại đúng UI/logic đó), nhưng truyền thêm EXTRA_AUTO_BURN_SUBTITLE để
 *    VideoToolsActivity tự tick sẵn checkbox "Ghép cứng phụ đề" — người bấm nút này
 *    không cần tự biết checkbox nằm ở đâu bên trong màn hình Cắt/Tách.
 * Lưu ý: REMOVE_MIDDLE vẫn CHƯA có nút riêng ở đây, chỉ chọn được qua spinnerMode.
 *
 * btnConvertToMp4 (16/09/2026) → CONVERT_TO_MP4 — riêng input m3u8/HLS cần trình chọn
 * THƯ MỤC thay vì file đơn, xem nút btnPickM3u8Folder + giải thích đầy đủ tại
 * FileUtils.importM3u8FolderToCache() (bên trong màn hình Cắt/Tách/VideoToolsActivity,
 * không phải ở đây).
 *
 * btnFixBrokenMp4 (17/09/2026) → CÙNG ĐÍCH HỆT btnConvertToMp4 (CONVERT_TO_MP4, không có
 * tham số/mode riêng) — chỉ khác TÊN NÚT, cho người có sẵn 1 file .mp4 (ví dụ tải bằng
 * IDM từ nguồn m3u8, công cụ ráp thô không sửa timestamp) bị đứng hình khi tua — họ sẽ
 * không nghĩ tới việc bấm "Convert sang MP4" vì file đã LÀ mp4 sẵn, không phải "đổi định
 * dạng". Xem VideoEngine.convertToMp4WithKnownBackend() phần "-fflags +genpts"/
 * "-avoid_negative_ts" để biết cách xử lý đúng vấn đề timestamp lệch do ráp thô.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var inferenceManager: InferenceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)

        binding.btnTrimCut.setOnClickListener { openVideoTools(VideoToolMode.TRIM_SPLIT) }
        binding.btnMerge.setOnClickListener { openVideoTools(VideoToolMode.MERGE) }
        binding.btnExtractAudio.setOnClickListener { openVideoTools(VideoToolMode.EXTRACT_AUDIO) }
        binding.btnBurnSubtitle.setOnClickListener {
            openVideoTools(VideoToolMode.TRIM_SPLIT, autoBurnSubtitle = true)
        }
        binding.btnExtractSubtitle.setOnClickListener { openVideoTools(VideoToolMode.EXTRACT_HARDSUB) }
        binding.btnCompress.setOnClickListener { openVideoTools(VideoToolMode.COMPRESS) }
        binding.btnConvertToMp4.setOnClickListener { openVideoTools(VideoToolMode.CONVERT_TO_MP4) }
        // [THÊM 17/09/2026] Cùng đích ĐÚNG HỆT btnConvertToMp4 ở trên — chỉ khác tên nút
        // cho dễ tìm, xem giải thích tại activity_main.xml.
        binding.btnFixBrokenMp4.setOnClickListener { openVideoTools(VideoToolMode.CONVERT_TO_MP4) }

        binding.btnUpscale.setOnClickListener {
            startActivity(Intent(this, UpscaleActivity::class.java))
        }
        binding.btnObjectExtract.setOnClickListener {
            startActivity(Intent(this, ObjectExtractActivity::class.java))
        }

        binding.btnModelSettings.setOnClickListener {
            startActivity(Intent(this, ModelSettingsActivity::class.java))
        }
    }

    private fun openVideoTools(mode: VideoToolMode, autoBurnSubtitle: Boolean = false) {
        val intent = Intent(this, VideoToolsActivity::class.java)
        intent.putExtra(VideoToolsActivity.EXTRA_MODE, mode.name)
        if (autoBurnSubtitle) {
            intent.putExtra(VideoToolsActivity.EXTRA_AUTO_BURN_SUBTITLE, true)
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        inferenceManager.releaseAll()
    }
}
