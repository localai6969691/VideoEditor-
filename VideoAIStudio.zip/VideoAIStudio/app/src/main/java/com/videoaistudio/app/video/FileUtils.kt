package com.videoaistudio.app.video

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * FFmpeg cần đường dẫn file thật, trong khi Android (từ scoped storage) trả về
 * content:// Uri khi người dùng chọn file qua trình chọn hệ thống. Hàm này copy
 * nội dung Uri ra file tạm trong bộ nhớ riêng của app để xử lý.
 */
object FileUtils {
    /** Dung sai khi snap về khung khoá — xem doc comment của findPrecedingKeyframeSec(). */
    const val KEYFRAME_SNAP_TOLERANCE_SEC = 0.1


    /**
     * Copy file người dùng chọn (model .onnx, file labels...) vào bộ nhớ riêng LÂU DÀI
     * của app (khác với cache tạm dùng cho video input, có thể bị hệ thống dọn bất kỳ lúc nào).
     */
    fun copyUriToPermanentStorage(context: Context, uri: Uri, subDir: String, suggestedName: String): File {
        val dir = File(context.getExternalFilesDir(null), subDir).apply { mkdirs() }
        val destFile = File(dir, suggestedName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Không đọc được file đã chọn")
        return destFile
    }

    /** Dọn sạch cache video input — gọi khi mở lại màn hình chọn video, tránh tích tụ
     *  dung lượng qua nhiều phiên (đặc biệt sau các lần bị crash giữa chừng, file cũ
     *  không được dọn sẽ nằm mãi trong cache và chiếm dung lượng oan). */
    fun clearVideoInputCache(context: Context) {
        // [SỬA 25/10/2026 — NGUYÊN NHÂN ANR "Video AI Studio không phản hồi" khi dùng video nặng GB]
        // Trước đây `deleteRecursively()` chạy THẲNG trên luồng chính ở 4 nơi (onCreate, nút Chọn video,
        // onDestroy của VideoToolsActivity và Application.onActivityStopped) — xoá 1 file cache 1.8GB
        // có thể chặn UI nhiều giây (hệ thống file phải giải phóng hàng triệu block), đủ vượt ngưỡng ANR 5s.
        // Cách làm mới: ĐỔI TÊN thư mục (thao tác tức thời, cùng ổ đĩa) rồi xoá thư mục đã đổi tên ở luồng
        // nền. Thư mục `video_input` mới (nếu cần) được tạo lại sạch ở lần copy kế tiếp nên không có chuyện
        // xoá nhầm file mới. Thư mục rác còn sót nếu tiến trình bị kill giữa chừng được dọn ở lần khởi động
        // sau (tiền tố "video_input_trash_" — xem VideoAIStudioApp). Nếu đổi tên thất bại thì xoá đồng bộ
        // như cũ (hiếm).
        val dir = File(context.cacheDir, "video_input")
        if (!dir.exists()) return
        val trash = File(context.cacheDir, "video_input_trash_${System.nanoTime()}")
        if (dir.renameTo(trash)) {
            Thread {
                try { trash.deleteRecursively() } catch (e: Exception) { /* dọn best-effort */ }
            }.apply { name = "clear-video-cache" }.start()
        } else {
            dir.deleteRecursively()
        }
    }

    /**
     * [THÊM 11/10/2026] Xoá các thư mục làm việc tạm (`detect_work_*`, `upscale_work_*`...) nằm
     * thẳng trong cacheDir mà lần chạy trước có thể đã bỏ lại (app bị kill/ngắt giữa chừng —
     * trước đây các thư mục này CHỈ bị xoá ở nhánh chạy thành công, không bị `clearVideoInputCache()`
     * đụng tới vì nằm ngoài `video_input`, nên có thể tích tụ nhiều GB frame mẫu PNG).
     *
     * CHỈ gọi ở 2 thời điểm AN TOÀN: (1) lúc tiến trình app vừa khởi động (chắc chắn chưa có
     * tác vụ nào đang chạy); (2) lúc 1 màn hình mở lên để xoá đúng tiền tố CỦA CHÍNH NÓ.
     * KHÔNG gọi khi app rời foreground (khác `clearVideoInputCache`), vì tác vụ có thể đang chạy.
     */
    fun clearStaleWorkDirs(context: Context, prefixes: List<String>) {
        context.cacheDir.listFiles()?.forEach { f ->
            if (f.isDirectory && prefixes.any { f.name.startsWith(it) }) f.deleteRecursively()
        }
    }

    /**
     * Copy file người dùng chọn vào cache. [SỬA 25/10/2026] Thêm [onProgress] (số byte đã copy) và
     * [isCancelled] (kiểm tra mỗi khối 1MB để dừng khi người dùng rời màn hình) — HÀM NÀY NẶNG (video
     * vài GB mất hàng chục giây), BẮT BUỘC gọi từ luồng nền (Dispatchers.IO), KHÔNG gọi từ luồng chính.
     * Gọi 3 tham số như cũ vẫn hợp lệ (2 tham số mới có giá trị mặc định).
     */
    fun copyUriToCache(
        context: Context,
        uri: Uri,
        suggestedName: String,
        onProgress: ((Long) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): File {
        val cacheDir = File(context.cacheDir, "video_input").apply { mkdirs() }
        val destFile = File(cacheDir, suggestedName)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    val buffer = ByteArray(1 shl 20)
                    var total = 0L
                    while (true) {
                        if (isCancelled()) throw java.util.concurrent.CancellationException("Đã huỷ sao chép")
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        total += n
                        onProgress?.invoke(total)
                    }
                }
            } ?: throw IllegalStateException("Không đọc được file đã chọn")
        } catch (e: Exception) {
            destFile.delete() // không để lại file copy dở dang trong cache
            throw e
        }
        return destFile
    }

    /** Kích thước file (byte) theo trình chọn file, -1 nếu không biết — chỉ để hiện % tiến độ sao chép. */
    fun queryDisplaySize(context: Context, uri: Uri): Long {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                if (index >= 0 && cursor.moveToFirst() && !cursor.isNull(index)) cursor.getLong(index) else -1L
            } ?: -1L
        } catch (e: Exception) {
            -1L
        }
    }

    /**
     * Copy file phụ đề người dùng chọn vào cache — LUÔN dùng tên CỐ ĐỊNH đơn giản
     * ("subtitle_input.<đuôi gốc>"), KHÔNG dùng tên file gốc như `copyUriToCache()` ở
     * trên vẫn làm cho video. Lý do: đường dẫn phụ đề sẽ được nhét thẳng vào cú pháp
     * filter FFmpeg `subtitles=<đường_dẫn>` — nếu tên file gốc có dấu cách, dấu `:`,
     * dấu `'`... có thể làm SAI CÚ PHÁP filter (lỗi khó nhận ra, không phải kiểu lỗi
     * "không tìm thấy file" rõ ràng). Dùng tên tự đặt, đơn giản, tránh hẳn rủi ro này
     * thay vì phải viết logic escape ký tự đặc biệt (dễ sai, khó test đủ mọi trường hợp).
     */
    fun copySubtitleToCache(context: Context, uri: Uri, originalName: String): File {
        val cacheDir = File(context.cacheDir, "video_input").apply { mkdirs() }
        val ext = originalName.substringAfterLast('.', "srt").lowercase().filter { it.isLetterOrDigit() }.ifBlank { "srt" }
        val destFile = File(cacheDir, "subtitle_input.$ext")
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Không đọc được file phụ đề đã chọn")
        return destFile
    }

    /**
     * [THÊM tính năng Convert sang MP4, 16/09/2026] Import 1 bộ HLS CỤC BỘ (playlist
     * .m3u8/.m3u + các đoạn .ts nó tham chiếu) từ 1 THƯ MỤC người dùng chọn qua
     * ACTION_OPEN_DOCUMENT_TREE, thành các file THẬT trong cache app mà FFmpeg đọc được.
     *
     * TẠI SAO m3u8 KHÔNG THỂ DÙNG CHUNG TRÌNH CHỌN FILE ĐƠN (ACTION_OPEN_DOCUMENT) như
     * các định dạng video khác — đây là lý do KỸ THUẬT, không phải chỉ là tiện UI: file
     * .m3u8 CHỈ LÀ 1 DANH SÁCH TÊN các đoạn .ts nằm CÙNG THƯ MỤC (đường dẫn tương đối,
     * không tự chứa hình ảnh gì cả). Nếu chỉ cấp quyền đọc đúng 1 file .m3u8 (đúng những
     * gì ACTION_OPEN_DOCUMENT làm dưới Scoped Storage), các file .ts nằm CẠNH nó trong
     * cùng thư mục KHÔNG được cấp quyền đọc — FFmpeg mở được playlist nhưng báo lỗi
     * "không mở được file" cho TỪNG đoạn .ts bên trong, dù bản thân playlist đọc bình
     * thường (lỗi RẤT DỄ nhầm là "FFmpeg không hỗ trợ m3u8", trong khi bản chất là lỗi
     * quyền truy cập file, không phải lỗi định dạng). Vì vậy BẮT BUỘC phải xin quyền cả
     * THƯ MỤC (OpenDocumentTree) rồi tự copy toàn bộ file cần dùng ra cache trước, đúng
     * NGUYÊN LÝ đã áp dụng cho phụ đề ở `copySubtitleToCache()` — khác ở chỗ phụ đề chỉ
     * cần 1 file duy nhất, còn m3u8 cần NGUYÊN 1 BỘ file đi cùng nhau.
     *
     * Copy TOÀN BỘ file vào 1 thư mục cache PHẲNG (không thư mục con), GIỮ NGUYÊN TÊN
     * GỐC (khác `copySubtitleToCache()` — cái đó ĐỔI tên vì cần tên đơn giản cho cú pháp
     * filter FFmpeg; ở đây KHÔNG được đổi tên vì playlist tham chiếu tới đoạn BẰNG ĐÚNG
     * TÊN GỐC — đổi tên sẽ làm playlist trỏ sai file, ra lỗi "không tìm thấy" y hệt như
     * không copy gì cả).
     *
     * 🔴 CHƯA TEST THẬT TRÊN MÁY — đặc biệt CHƯA xác nhận: (1) `listFiles()` của
     * DocumentFile CHỈ liệt kê file ở ĐÚNG CẤP NGOÀI CÙNG của thư mục đã chọn, KHÔNG đệ
     * quy vào thư mục con — một số nguồn HLS tổ chức đoạn .ts trong thư mục con riêng,
     * trường hợp đó hàm này sẽ bỏ sót, cần thêm đệ quy nếu gặp thực tế; (2) thư mục có
     * rất nhiều đoạn (video dài, tách nhỏ) copy có chậm/tốn dung lượng tạm đáng kể
     * không — chưa đo trên máy thật.
     *
     * @return đường dẫn CỤC BỘ của đúng file .m3u8/.m3u tìm thấy trong thư mục (đã có
     *   sẵn các đoạn .ts cạnh nó trong cùng thư mục cache) — null nếu không tìm thấy
     *   file playlist nào trong thư mục đã chọn.
     */
    fun importM3u8FolderToCache(context: Context, treeUri: Uri): File? {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        val cacheDir = File(context.cacheDir, "video_input/m3u8_bundle_${System.currentTimeMillis()}").apply { mkdirs() }
        var playlistFile: File? = null
        for (child in root.listFiles()) {
            if (!child.isFile) continue
            val name = child.name ?: continue
            val destFile = File(cacheDir, name)
            try {
                context.contentResolver.openInputStream(child.uri)?.use { input ->
                    destFile.outputStream().use { output -> input.copyTo(output) }
                }
            } catch (e: Exception) {
                continue // 1 file lỗi không chặn cả bộ — nhưng nếu đúng là 1 đoạn .ts bị
                // lỗi, playlist vẫn sẽ chạy được, chỉ đoạn đó bị thiếu khi phát/convert.
            }
            val lowerName = name.lowercase()
            if (lowerName.endsWith(".m3u8") || lowerName.endsWith(".m3u")) {
                playlistFile = destFile
            }
        }
        return playlistFile
    }

    /** Đọc FPS thật của video để dựng lại đúng tốc độ gốc sau khi xử lý frame-by-frame. */
    /** Đọc thời lượng video (giây) để chia thành các chunk xử lý cuốn chiếu. */
    /** Đọc bitrate gốc của video (bit/giây) — dùng làm cơ sở ước lượng dung lượng sau upscale,
     *  thay vì tra bảng "bitrate chuẩn cho 4K" (sai lệch vì không phản ánh đúng nội dung thật). */
    /**
     * Tính bitrate THẬT dựa trên dung lượng file / thời lượng — cách này LUÔN CHÍNH XÁC
     * về mặt toán học (không như metadata trong file có thể bị ghi sai hoặc thiếu tuỳ
     * codec/container). Đây là bản sửa cho lỗi "nén ra nặng hơn cả gốc" — nguyên nhân
     * là bitrate đọc từ metadata (getVideoBitrate) có thể sai, khiến app tính nhầm mức
     * bitrate mục tiêu cao hơn cả bitrate gốc thật.
     */
    fun calculateActualBitrateBps(path: String): Long {
        val durationSec = getVideoDurationSec(path)
        if (durationSec <= 0) return 0L
        val fileSizeBits = File(path).length() * 8
        return (fileSizeBits / durationSec).toLong()
    }

    /**
     * [THÊM tính năng Convert sang MP4] Như `calculateActualBitrateBps()` ở trên, NHƯNG
     * xử lý đúng trường hợp input là 1 PLAYLIST m3u8/m3u — nếu dùng thẳng
     * `calculateActualBitrateBps()` cho m3u8, `File(path).length()` chỉ đo kích thước
     * CHÍNH FILE PLAYLIST (thuần văn bản, vài trăm byte) chứ KHÔNG PHẢI dữ liệu hình ảnh
     * thật (nằm ở các file .ts cạnh nó) — sẽ ra bitrate SAI GẦN NHƯ BẰNG 0, kéo theo bitrate
     * mục tiêu khi encode lại (đường phần cứng) cũng gần bằng 0 -> video convert ra gần như
     * đứng hình/mất nét hoàn toàn. ĐÃ BẮT lỗi này trước khi giao, chưa từng xảy ra thật.
     *
     * Cách tính đúng cho m3u8: cộng dồn kích thước TOÀN BỘ file cùng thư mục với playlist
     * (chính là các đoạn .ts đã được `importM3u8FolderToCache()` copy vào CÙNG 1 thư mục
     * cache riêng cho bundle đó — xem hàm đó) rồi chia cho thời lượng, thay vì chỉ đo
     * riêng file .m3u8.
     */
    fun calculateActualBitrateBpsSmart(path: String, durationSec: Double): Long {
        val file = File(path)
        val ext = file.extension.lowercase()
        if (ext != "m3u8" && ext != "m3u") return calculateActualBitrateBps(path)
        if (durationSec <= 0) return 0L
        val totalBytes = file.parentFile?.listFiles()?.sumOf { it.length() } ?: file.length()
        return (totalBytes * 8 / durationSec).toLong()
    }

    fun getVideoBitrate(path: String): Long {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            retriever.release()
        }
    }

    /**
     * Ước lượng dung lượng sau upscale khi nén bằng QP qua libkvazaar — dùng lại đúng
     * nguyên lý CRF/QP: cứ +6 vào QP thì bitrate giảm khoảng một nửa (quy tắc kinh
     * nghiệm phổ biến trong encoding, áp dụng tương tự cho QP vì cùng cơ chế lượng tử
     * hoá, dù QP kém tinh vi hơn CRF thật một chút).
     */
    fun estimateUpscaledSizeBytes(originalBitrateBps: Long, scaleFactor: Int, durationSec: Double, qp: Int): Long {
        if (originalBitrateBps <= 0) return 0L
        val pixelRatio = (scaleFactor * scaleFactor).toDouble()
        val smoothingFactor = 0.8
        val qpAdjust = Math.pow(2.0, (26 - qp) / 6.0) // mốc QP 26 ~ CRF 23 x264
        val estimatedBitrate = originalBitrateBps * pixelRatio * smoothingFactor * qpAdjust
        return (estimatedBitrate * durationSec / 8).toLong()
    }

    fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        // Ép Locale.US để luôn hiện dấu chấm thập phân, tránh lẫn lộn với dấu phẩy
        // ngăn cách hàng nghìn/đơn vị khi hiển thị, dù đây chỉ là text hiển thị (không
        // ảnh hưởng lệnh FFmpeg) nhưng vẫn nên nhất quán.
        return if (mb >= 1024) "%.2f GB".format(java.util.Locale.US, mb / 1024.0) else "%.1f MB".format(java.util.Locale.US, mb)
    }

    /**
     * Với "-c copy" (không encode lại), FFmpeg BẮT BUỘC phải bắt đầu file output đúng
     * tại 1 khung hình khoá (keyframe/sync sample) — không thể cắt giữa chừng 1 GOP vì
     * không giải mã lại. Vì vậy khi người dùng chọn giây X làm điểm bắt đầu, FFmpeg sẽ
     * tự động lùi về khung hình khoá gần nhất TRƯỚC hoặc ĐÚNG giây X đó — đây chính là
     * nguyên nhân "số giây hiển thị trên preview khác với video output thật": preview
     * (ExoPlayer) tua chính xác tới đúng khung hình bất kỳ, nhưng file cắt ra thì không.
     *
     * Hàm này tìm ĐÚNG khung hình khoá đó (dùng MediaExtractor.SEEK_TO_PREVIOUS_SYNC —
     * chính cơ chế FFmpeg dùng bên trong khi input-seeking + stream copy), để UI có thể
     * hiển thị/tua preview tới ĐÚNG giây mà video output sẽ thật sự bắt đầu, thay vì để
     * người dùng thấy 1 giây rồi ra 1 giây khác.
     */
    /**
     * [SỬA 25/10/2026 — LỖI "cắt ra bị trôi về TRƯỚC chỗ cắt vài giây", đo bằng FFmpeg thật + mô phỏng]
     * `SEEK_TO_PREVIOUS_SYNC` trả khung khoá có thời điểm <= mục tiêu TÍNH ĐẾN TỪNG MICRO-GIÂY, nên hàm này
     * KHÔNG LUỸ ĐẲNG nếu không có dung sai: đưa CHÍNH thời điểm khung khoá K vào lại (sau khi nó đã bị
     * làm tròn nhẹ ở Float32 của slider / `%.1f` của danh sách đoạn / cắt cụt `.toLong()` ở dòng
     * `targetUs` bên dưới) thì chỉ cần kết quả thấp hơn K dù 1 micro-giây là hàm lùi về khung khoá
     * TRƯỚC K — cách K cả 1 GOP (vài giây). Điểm CHỐT trước FFmpeg (`snapToPrecedingKeyframe`) lại snap LẦN 2
     * trên đúng giá trị đã bị làm tròn đó. Mô phỏng: ~50% lần cắt bị lùi thêm 1 khung khoá khi giá trị đi
     * qua Float32 hoặc `%.1f`; 0% khi có dung sai [toleranceSec]. Dung sai 0.1s > sai số làm tròn lớn nhất
     * của mọi đường (`%.1f` = 0.05s) và chỉ làm điểm bắt đầu có thể NHÍCH TỚI khung khoá ngay phía SAU nếu
     * nó nằm trong 0.1s — vô hình với người dùng, đổi lại không bao giờ lùi nhầm cả GOP.
     */
    fun findPrecedingKeyframeSec(path: String, targetSec: Double, toleranceSec: Double = KEYFRAME_SNAP_TOLERANCE_SEC): Double {
        if (targetSec <= 0.0) return 0.0
        val extractor = android.media.MediaExtractor()
        return try {
            extractor.setDataSource(path)
            var videoTrack = -1
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) { videoTrack = i; break }
            }
            if (videoTrack < 0) return targetSec
            extractor.selectTrack(videoTrack)
            val targetUs = Math.round((targetSec + toleranceSec) * 1_000_000.0)
            extractor.seekTo(targetUs, android.media.MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val actualUs = extractor.sampleTime
            if (actualUs < 0) targetSec else actualUs / 1_000_000.0
        } catch (e: Exception) {
            targetSec // đọc lỗi -> giữ nguyên giá trị gốc, không chặn luồng sử dụng
        } finally {
            extractor.release()
        }
    }

    fun getVideoDurationSec(path: String): Double {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val durationMs = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            durationMs / 1000.0
        } catch (e: Exception) {
            0.0
        } finally {
            retriever.release()
        }
    }

    fun getVideoFps(path: String): Double {
        val extractor = android.media.MediaExtractor()
        return try {
            extractor.setDataSource(path)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && format.containsKey(android.media.MediaFormat.KEY_FRAME_RATE)) {
                    return format.getInteger(android.media.MediaFormat.KEY_FRAME_RATE).toDouble()
                }
            }
            30.0 // mặc định an toàn nếu không đọc được (hiếm khi xảy ra)
        } catch (e: Exception) {
            30.0
        } finally {
            extractor.release()
        }
    }

    fun getOutputDir(context: Context): File {
        val dir = context.getExternalFilesDir("VideoAIStudioOutput") ?: context.filesDir
        dir.mkdirs()
        return dir
    }

    fun queryDisplayName(context: Context, uri: Uri): String {
        var name = "video_${System.currentTimeMillis()}"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }
}
