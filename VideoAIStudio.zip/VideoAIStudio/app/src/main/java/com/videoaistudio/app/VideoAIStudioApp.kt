package com.videoaistudio.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.videoaistudio.app.video.CompressService
import com.videoaistudio.app.video.FileUtils

/**
 * [SỬA 17/11/2026 — ĐỌC ĐOẠN NÀY TRƯỚC, nó thay thế ý định bên dưới] Application này KHÔNG CÒN dọn cache khi app rời
 * foreground nữa (xem `onActivityStopped`): log thật cho thấy cơ chế đó xoá bản copy video ĐANG LÀM VIỆC mỗi khi
 * màn hình bị che dù chỉ vài giây (trình chọn nơi lưu file, Home, màn hình tắt...) => preview đứng, lần chạy sau
 * phải copy lại. Việc dọn do `onCreate`/`onDestroy` của từng màn hình + dọn thư mục rác lúc khởi động đảm nhiệm.
 * ĐÁNH ĐỔI (nói thẳng): vuốt xoá app khỏi recent-apps thì bản copy còn lại cho tới lần mở màn hình công cụ kế tiếp
 * (hành vi trước 17/09/2026). [BỔ SUNG 17/11/2026] Phần vuốt xoá giờ do `video/TaskCleanupService` (onTaskRemoved) đảm nhiệm,
 * KHÔNG nằm ở đây — vì onStop không phân biệt được "vuốt xoá" với "che màn hình vài giây". Phần mô tả bên dưới là LỊCH SỬ ý định ban đầu, giữ lại để biết vì sao có lớp này.
 *
 * [THÊM 17/09/2026] Application riêng — CHỈ để dọn cache video input NGAY KHI app rời
 * foreground (không còn Activity nào đang hiển thị), thay vì chỉ trông vào
 * Activity.onDestroy() của từng màn hình (VideoToolsActivity/UpscaleActivity/
 * ObjectExtractActivity — cả 3 đều gọi FileUtils.clearVideoInputCache() ở onCreate() +
 * onDestroy(), xem PROJECT_SPEC.md mục 2.2/6).
 *
 * TẠI SAO CẦN — LỖI THẬT người dùng báo: "vuốt xoá ứng dụng trong recent app thì bộ nhớ
 * đệm vẫn còn nguyên đến mấy GB". Trước đây (xem PROJECT_SPEC.md mục 6, 04/09/2026) team
 * GIẢ ĐỊNH sửa xong ANR thì cache cũng tự dọn theo (vì Activity không còn bị hệ thống
 * force-kill giữa chừng) — giả định đó CHỈ đúng cho đúng 1 kịch bản (ANR ép kill), KHÔNG
 * đúng cho trường hợp CHUNG hơn nhiều: Android KHÔNG đảm bảo `onDestroy()` của bất kỳ
 * Activity nào sẽ chạy khi hệ thống thu hồi tiến trình app đã lùi nền để giải phóng RAM
 * cho app khác — đây là hành vi ĐÃ ĐƯỢC TÀI LIỆU HOÁ của chính nền tảng Android, không
 * phải lỗi riêng của app này, và KHÔNG CÓ CÁCH nào "sửa" để onDestroy() chắc chắn chạy
 * trong tình huống đó.
 *
 * Cách làm: đếm số Activity đang "started" (đang hiển thị) qua
 * `registerActivityLifecycleCallbacks` — CÁCH LÀM GỐC của chính Android, KHÔNG cần thêm
 * dependency `androidx.lifecycle:lifecycle-process` (lớp `ProcessLifecycleOwner` quen
 * thuộc thực chất chỉ là 1 lớp bọc tiện lợi quanh ĐÚNG cơ chế này). Khi đếm về 0 (Activity
 * CUỐI CÙNG vừa dừng) — tức là app vừa rời foreground, có thể do bấm nút Home, chuyển
 * sang app khác, HOẶC vuốt xoá trong recent-apps trong lúc tiến trình còn sống (đúng
 * trường hợp người dùng báo) — dọn cache NGAY LÚC ĐÓ, không đợi onDestroy() của bất kỳ
 * Activity nào, vì onStop() được gọi ĐÁNG TIN CẬY hơn nhiều so với onDestroy() cho các
 * hành động này (miễn tiến trình còn sống tại thời điểm người dùng thao tác — nếu hệ
 * thống đã âm thầm kill tiến trình từ TRƯỚC đó do thiếu RAM thì không có đoạn code nào,
 * kể cả đoạn này, còn cơ hội chạy — đây là giới hạn không thể vượt qua của nền tảng).
 *
 * AN TOÀN VỚI COMPRESS ĐANG CHẠY NỀN: Compress dùng CompressService (Foreground Service,
 * xem mục 2.2) — SỐNG SÓT được khi người dùng rời app, có thể đang đọc file input từ
 * ĐÚNG thư mục cache này giữa chừng. Nếu dọn cache ngay lúc app rời foreground trong khi
 * Compress đang chạy sẽ XOÁ MẤT file input đang đọc dở, hỏng luôn job đang chạy nền. Đã
 * kiểm tra `CompressService.CompressResultHolder.isRunning` (cờ CÓ SẴN từ trước, dùng để
 * chống chạy trùng lặp — xem CompressService.kt) TRƯỚC khi dọn — bỏ qua lần dọn này nếu
 * đang `true`. LƯU Ý: `CompressResultHolder` là `object` LỒNG BÊN TRONG `class
 * CompressService` (không phải object đứng riêng ở cấp package) — build #2 (17/09/2026)
 * đã FAIL vì import sai (`import ...video.CompressResultHolder` thay vì phải import
 * chính `CompressService` rồi gọi qua `CompressService.CompressResultHolder`) — lỗi do
 * suy ra cách gọi từ NGAY BÊN TRONG chính `CompressService.kt` (ở đó không cần ghi tiền
 * tố vì cùng class) mà không kiểm tra lại dòng khai báo thật trước khi dùng từ file khác.
 *
 * 🔴 CHƯA TEST THẬT TRÊN MÁY — đặc biệt CHƯA xác nhận: (1) hành vi thật khi vuốt xoá app
 * trong recent-apps trên các dòng máy/launcher OEM khác nhau (1 số hãng như Samsung/
 * Xiaomi có lớp quản lý RAM riêng, có thể ứng xử khác Android gốc); (2) tình huống
 * Compress VỪA kết thúc đúng lúc app rời foreground (khoảng hở giữa cờ isRunning chuyển
 * về false và lúc app rời foreground) — chưa thử tái hiện; (3) Convert/burn phụ đề (chạy
 * qua lifecycleScope của Activity, KHÔNG qua Service — xem mục 4.5/4.6) vốn đã bị ngắt
 * khi rời app từ trước, không phát sinh thêm rủi ro mới từ thay đổi này.
 */
class VideoAIStudioApp : Application() {

    private var startedActivityCount = 0

    override fun onCreate() {
        super.onCreate()

        // [THÊM 11/10/2026] Tiến trình vừa khởi động => chắc chắn KHÔNG có tác vụ detect/upscale
        // nào đang chạy => an toàn xoá thư mục làm việc tạm do lần chạy trước bị kill bỏ lại.
        // Chạy luồng nền vì có thể xoá nhiều GB, không được chặn luồng chính lúc khởi động.
        Thread {
            try {
                // [25/10/2026] thêm "video_input_trash_": thư mục cache video đã được đổi tên chờ xoá nền
                // (xem FileUtils.clearVideoInputCache) mà tiến trình trước bị kill chưa kịp xoá xong.
                FileUtils.clearStaleWorkDirs(applicationContext, listOf("detect_work_", "upscale_work_", "video_input_trash_"))
                // [16/11/2026] Thư mục video_input đã chuyển từ cacheDir sang filesDir => thư mục rác
                // `video_input_trash_*` giờ nằm ở filesDir (dòng trên chỉ quét cacheDir). Dọn cả 2 chỗ.
                FileUtils.clearStaleVideoInputTrash(applicationContext)
                // [17/11/2026] Thư mục tạm của "Cắt chính xác" (smartcut_tmp_*, nằm trong thư mục output) mà tiến trình trước bị
                // kill giữa chừng bỏ lại — có thể nặng cả GB. Tiến trình vừa khởi động => chắc chắn không có lần cắt nào đang chạy.
                FileUtils.getOutputDir(applicationContext).listFiles()?.forEach {
                    if (it.isDirectory && it.name.startsWith("smartcut_tmp_")) it.deleteRecursively()
                }
            } catch (e: Exception) {
                // dọn dẹp best-effort, không để làm crash app
            }
        }.start()

        // [THÊM 25/10/2026] Chẩn đoán ANR không cần adb: chụp ngăn xếp luồng chính lúc đang treo + đọc lý do
        // kết thúc của tiến trình trước (xem MainThreadWatchdog). Chỉ ghi vào DebugLog, không đổi hành vi app.
        com.videoaistudio.app.debug.MainThreadWatchdog.start(this)
        com.videoaistudio.app.debug.MainThreadWatchdog.logPreviousExits(this)

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedActivityCount++
            }

            override fun onActivityStopped(activity: Activity) {
                startedActivityCount--
                if (startedActivityCount <= 0) {
                    startedActivityCount = 0
                    // [SỬA 17/11/2026 — LỖI THẬT "preview đứng giữa chừng"] TRƯỚC ĐÂY ở đây gọi
                    // FileUtils.clearVideoInputCache() => cứ rời màn hình là bản copy video ĐANG LÀM VIỆC bị xoá,
                    // kể cả chỉ rời vài giây (log thật: bấm Lưu -> trình chọn nơi lưu che màn hình -> onStop ->
                    // video biến mất; lần kéo preview kế tiếp không bao giờ về READY). onStop KHÔNG phân biệt
                    // được "rời vài giây" với "vuốt xoá app", mà Activity vẫn còn sống và còn giữ đường dẫn file
                    // => xoá ở đây là xoá file người dùng đang dùng. Giờ CHỈ ghi log; việc dọn do onDestroy/onCreate
                    // của từng màn hình đảm nhiệm (xem mục 6 PROJECT_SPEC.md, 17/11/2026).
                    com.videoaistudio.app.debug.DebugLog.log(
                        applicationContext, "VideoAIStudioApp",
                        "App rời foreground (không còn Activity nào đang hiển thị) — KHÔNG dọn thư mục video đang làm việc; " +
                            "Compress đang chạy=${CompressService.CompressResultHolder.isRunning}; " +
                            FileUtils.describeInputState(applicationContext, null)
                    )
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
