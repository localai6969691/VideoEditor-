package com.videoaistudio.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.videoaistudio.app.video.CompressResultHolder
import com.videoaistudio.app.video.FileUtils

/**
 * [THÊM 17/09/2026] Application riêng — CHỈ để dọn cache video input NGAY KHI app rời
 * foreground (không còn Activity nào đang hiển thị), thay vì chỉ trông vào
 * Activity.onDestroy() của từng màn hình (VideoToolsActivity/UpscaleActivity/
 * ObjectExtractActivity — cả 3 đều gọi FileUtils.clearVideoInputCache() ở onCreate() +
 * onDestroy(), xem PROJECT_SPEC.md mục 2.2/6).
 *
 * TẠI SAO CẦN — LỖI THẬT người dùng báo: "vuốt xoá ứng dụng trong recent app thì bộ nhớ
 * đệm vẫn còn nguyên đến mấy GB". Trước đây (xem PROJECT_SPEC.md mục 6, 04/09/2026) team
 * GIẢ ĐỊNH sửa xong ANR thì cache cũng tự dọn theo (vì Activity không còn bị hệ thống
 * force-kill giữa chừng) — giả định đó CHỈ đúng cho đúng 1 kịch bản (ANR ép kill), KHÔNG
 * đúng cho trường hợp CHUNG hơn nhiều: Android KHÔNG đảm bảo `onDestroy()` của bất kỳ
 * Activity nào sẽ chạy khi hệ thống thu hồi tiến trình app đã lùi nền để giải phóng RAM
 * cho app khác — đây là hành vi ĐÃ ĐƯỢC TÀI LIỆU HOÁ của chính nền tảng Android, không
 * phải lỗi riêng của app này, và KHÔNG CÓ CÁCH nào "sửa" để onDestroy() chắc chắn chạy
 * trong tình huống đó.
 *
 * Cách làm: đếm số Activity đang "started" (đang hiển thị) qua
 * `registerActivityLifecycleCallbacks` — CÁCH LÀM GỐC của chính Android, KHÔNG cần thêm
 * dependency `androidx.lifecycle:lifecycle-process` (lớp `ProcessLifecycleOwner` quen
 * thuộc thực chất chỉ là 1 lớp bọc tiện lợi quanh ĐÚNG cơ chế này). Khi đếm về 0 (Activity
 * CUỐI CÙNG vừa dừng) — tức là app vừa rời foreground, có thể do bấm nút Home, chuyển
 * sang app khác, HOẶC vuốt xoá trong recent-apps trong lúc tiến trình còn sống (đúng
 * trường hợp người dùng báo) — dọn cache NGAY LÚC ĐÓ, không đợi onDestroy() của bất kỳ
 * Activity nào, vì onStop() được gọi ĐÁNG TIN CẬY hơn nhiều so với onDestroy() cho các
 * hành động này (miễn tiến trình còn sống tại thời điểm người dùng thao tác — nếu hệ
 * thống đã âm thầm kill tiến trình từ TRƯỚC đó do thiếu RAM thì không có đoạn code nào,
 * kể cả đoạn này, còn cơ hội chạy — đây là giới hạn không thể vượt qua của nền tảng).
 *
 * AN TOÀN VỚI COMPRESS ĐANG CHẠY NỀN: Compress dùng CompressService (Foreground Service,
 * xem mục 2.2) — SỐNG SÓT được khi người dùng rời app, có thể đang đọc file input từ
 * ĐÚNG thư mục cache này giữa chừng. Nếu dọn cache ngay lúc app rời foreground trong khi
 * Compress đang chạy sẽ XOÁ MẤT file input đang đọc dở, hỏng luôn job đang chạy nền. Đã
 * kiểm tra `CompressResultHolder.isRunning` (cờ CÓ SẴN từ trước, dùng để chống chạy trùng
 * lặp — xem CompressService.kt) TRƯỚC khi dọn — bỏ qua lần dọn này nếu đang `true`.
 *
 * 🔴 CHƯA TEST THẬT TRÊN MÁY — đặc biệt CHƯA xác nhận: (1) hành vi thật khi vuốt xoá app
 * trong recent-apps trên các dòng máy/launcher OEM khác nhau (1 số hãng như Samsung/
 * Xiaomi có lớp quản lý RAM riêng, có thể ứng xử khác Android gốc); (2) tình huống
 * Compress VỪA kết thúc đúng lúc app rời foreground (khoảng hở giữa cờ isRunning chuyển
 * về false và lúc app rời foreground) — chưa thử tái hiện; (3) Convert/burn phụ đề (chạy
 * qua lifecycleScope của Activity, KHÔNG qua Service — xem mục 4.5/4.6) vốn đã bị ngắt
 * khi rời app từ trước, không phát sinh thêm rủi ro mới từ thay đổi này.
 */
class VideoAIStudioApp : Application() {

    private var startedActivityCount = 0

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedActivityCount++
            }

            override fun onActivityStopped(activity: Activity) {
                startedActivityCount--
                if (startedActivityCount <= 0) {
                    startedActivityCount = 0
                    if (!CompressResultHolder.isRunning) {
                        FileUtils.clearVideoInputCache(applicationContext)
                    }
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
