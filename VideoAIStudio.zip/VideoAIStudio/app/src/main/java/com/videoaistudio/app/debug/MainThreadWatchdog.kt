package com.videoaistudio.app.debug

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * [THÊM 25/10/2026] Công cụ chẩn đoán ANR ("Video AI Studio không phản hồi") KHÔNG cần máy tính/adb.
 *
 * Vì sao cần: ANR đã tái phát ít nhất 4 lần (04/09, 06/09, 25/10…), mỗi lần chỉ có ảnh chụp hộp thoại +
 * log "trống" suốt đoạn bị treo (luồng chính đứng thì không ghi được gì), nên mỗi lần chỉ ĐOÁN nguyên nhân
 * (job đọc keyframe, bão seek, nút tua...) — chưa lần nào có bằng chứng. Hai thứ dưới đây cho bằng chứng thật:
 *
 * 1. [start] Luồng canh gác (daemon): cứ 500ms gửi 1 "ping" lên luồng chính; nếu luồng chính không trả lời
 *    trong >2s thì CHỤP NGĂN XẾP (stack trace) CỦA LUỒNG CHÍNH ngay lúc đang treo và ghi vào DebugLog (lặp
 *    lại tối đa 5 lần/đợt treo, cách nhau 3s, rồi ghi "hết treo sau X ms"). Dòng log đó chỉ ra ĐÚNG hàm đang
 *    chạy (vd `FileUtils.copyUriToCache`, `File.deleteRecursively`, `Object.wait` trong release()...).
 * 2. [logPreviousExits] Android 11+: đọc `ApplicationExitInfo` — lý do tiến trình lần trước kết thúc; nếu là
 *    ANR thì đọc kèm bản trace ANR do hệ thống chụp (có ngăn xếp luồng "main") và ghi vào DebugLog.
 *    Chỉ có dữ liệu khi tiến trình bị kill (vd bấm "Đóng ứng dụng" trên hộp thoại ANR).
 */
object MainThreadWatchdog {
    private const val PING_INTERVAL_MS = 500L
    private const val BLOCK_THRESHOLD_MS = 2000L
    private const val REPEAT_REPORT_MS = 3000L
    private const val MAX_REPORTS_PER_BLOCK = 5
    private const val MAX_FRAMES = 25

    @Volatile private var started = false
    @Volatile private var lastPongAt = 0L

    fun start(context: Context) {
        if (started) return
        started = true
        val app = context.applicationContext
        val mainLooper = Looper.getMainLooper()
        val mainThread = mainLooper.thread
        val mainHandler = Handler(mainLooper)
        lastPongAt = SystemClock.uptimeMillis()
        val pong = Runnable { lastPongAt = SystemClock.uptimeMillis() }

        Thread({
            var blockStartedAt = 0L   // thời điểm ping đầu tiên không được trả lời trong đợt treo hiện tại
            var reports = 0
            var lastReportAt = 0L
            while (true) {
                val sentAt = SystemClock.uptimeMillis()
                mainHandler.post(pong)
                try {
                    Thread.sleep(PING_INTERVAL_MS)
                } catch (e: InterruptedException) {
                    return@Thread
                }
                val now = SystemClock.uptimeMillis()
                if (lastPongAt >= sentAt) {
                    // Luồng chính vừa trả lời ping: nếu trước đó đã báo treo thì ghi "hết treo".
                    if (reports > 0) {
                        DebugLog.log(
                            app, "ANR-watchdog",
                            "Luồng chính HẾT TREO sau khoảng ${now - blockStartedAt}ms (đã ghi $reports ngăn xếp trong lúc treo)"
                        )
                    }
                    blockStartedAt = 0L
                    reports = 0
                    continue
                }
                if (blockStartedAt == 0L) blockStartedAt = sentAt
                val blockedFor = now - blockStartedAt
                if (blockedFor >= BLOCK_THRESHOLD_MS && reports < MAX_REPORTS_PER_BLOCK &&
                    (reports == 0 || now - lastReportAt >= REPEAT_REPORT_MS)
                ) {
                    reports++
                    lastReportAt = now
                    val frames = mainThread.stackTrace.take(MAX_FRAMES).joinToString(" <- ") {
                        "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}"
                    }
                    DebugLog.log(
                        app, "ANR-watchdog",
                        "LUỒNG CHÍNH ĐANG TREO ${blockedFor}ms (báo #$reports) — ngăn xếp luồng chính: $frames"
                    )
                }
            }
        }, "anr-watchdog").apply { isDaemon = true }.start()
    }

    /** Ghi vào DebugLog lý do kết thúc của các tiến trình trước (Android 11+), kèm trace nếu là ANR. Chạy luồng nền. */
    fun logPreviousExits(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val app = context.applicationContext
        Thread {
            try {
                val prefs = app.getSharedPreferences("exit_info_logged", Context.MODE_PRIVATE)
                val lastLogged = prefs.getLong("last_ts", 0L)
                val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val exits = am.getHistoricalProcessExitReasons(app.packageName, 0, 5)
                var newest = lastLogged
                for (info in exits.sortedBy { it.timestamp }) {
                    if (info.timestamp <= lastLogged) continue
                    if (info.timestamp > newest) newest = info.timestamp
                    val reasonName = when (info.reason) {
                        ApplicationExitInfo.REASON_ANR -> "ANR"
                        ApplicationExitInfo.REASON_CRASH -> "CRASH (exception)"
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY (bị kill vì thiếu RAM)"
                        ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
                        ApplicationExitInfo.REASON_USER_STOPPED -> "USER_STOPPED"
                        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
                        ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED"
                        ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
                        else -> "reason=${info.reason}"
                    }
                    var line = "Tiến trình trước (pid=${info.pid}) kết thúc: $reasonName, mô tả=\"${info.description}\", " +
                        "importance=${info.importance}, thời điểm=${java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(info.timestamp)}"
                    if (info.reason == ApplicationExitInfo.REASON_ANR) {
                        val trace = try {
                            info.traceInputStream?.bufferedReader()?.use { it.readText() }
                        } catch (e: Exception) {
                            null
                        }
                        if (!trace.isNullOrBlank()) {
                            // Cắt riêng khối luồng "main" (từ dòng "main" tới dòng trống kế tiếp) cho gọn.
                            val lines = trace.lines()
                            val start = lines.indexOfFirst { it.startsWith("\"main\"") }
                            val mainBlock = if (start >= 0) {
                                lines.drop(start).takeWhile { it.isNotBlank() }.take(40)
                            } else {
                                lines.take(40)
                            }
                            line += " — TRACE ANR (luồng main): " + mainBlock.joinToString(" ⏎ ") { it.trim() }.take(4000)
                        } else {
                            line += " — (không đọc được trace ANR)"
                        }
                    }
                    DebugLog.log(app, "ExitInfo", line)
                }
                if (newest > lastLogged) prefs.edit().putLong("last_ts", newest).apply()
            } catch (e: Throwable) {
                // chẩn đoán best-effort, không bao giờ được làm crash app
            }
        }.apply { name = "exit-info-logger" }.start()
    }
}
