import com.videoaistudio.app.video.EditListCut
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ceil

// Test thật cho EditListCut (cắt chính xác KHÔNG mã hoá lại, 19/11/2026): sinh video thử bằng ffmpeg trên máy, cắt bằng ĐÚNG lệnh
// mà app chạy (EditListCut.command), rồi đo bằng ffmpeg/ffprobe: khung đầu, khung có giống nguồn từng bit không, lệch tiếng,
// ghép (concat) kiểu app. Chạy: xem README.md cùng thư mục. Thoát mã 1 nếu có ca FAIL.

var passed = 0
var failed = 0
fun check(name: String, cond: Boolean, detail: String = "") {
    if (cond) { passed++; println("PASS  $name") } else { failed++; println("FAIL  $name  $detail") }
}

fun tokenize(s: String): List<String> {
    val out = ArrayList<String>(); val cur = StringBuilder(); var q = false
    for (c in s) when {
        c == '"' -> q = !q
        c == ' ' && !q -> { if (cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() } }
        else -> cur.append(c)
    }
    if (cur.isNotEmpty()) out.add(cur.toString())
    return out
}

fun execAll(cmd: List<String>, timeoutSec: Long = 300): Pair<Int, String> {
    val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
    val out = StringBuilder()
    val t = Thread { out.append(p.inputStream.bufferedReader().readText()) }.apply { start() }
    if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return -1 to "timeout" }
    t.join()
    return p.exitValue() to out.toString()
}

fun ffmpeg(vararg a: String) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y") + a.toList())
/** Chạy ffprobe với chuỗi lệnh KIỂU APP (EditListCut.*ProbeCommand) — như FFprobeKit.execute. */
fun appProbe(cmd: String): String? { val (c, t) = execAll(listOf("ffprobe") + tokenize(cmd)); return if (c == 0) t else null }

fun frameHashes(f: File): List<String> {
    val (c, t) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-i", f.path, "-map", "0:v", "-f", "framemd5", "-fps_mode", "passthrough", "-"))
    if (c != 0) return emptyList()
    // stderr được trộn vào (cảnh báo giải mã của nguồn GOP mở, vd "illegal short term buffer state") => chỉ lấy dòng framemd5 thật
    return t.lines().filter { it.isNotBlank() && !it.startsWith("#") && it[0].isDigit() && it.split(",").size >= 6 }.map { it.split(",")[5].trim() }
}

fun audioF32(f: File): FloatArray {
    val tmp = File(f.path + ".f32")
    execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", f.path, "-vn", "-ac", "1", "-ar", "44100", "-f", "f32le", tmp.path))
    val b = java.nio.ByteBuffer.wrap(tmp.readBytes()).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    val fb = b.asFloatBuffer(); val a = FloatArray(fb.remaining()); fb.get(a); tmp.delete(); return a
}

/** Độ lệch (ms) của đoạn tiếng output [1s,2s] so với nguồn quanh [startSec+0.2, startSec+4] bằng tương quan chéo thẳng (tiếng nhiễu). */
fun audioOffsetMs(src: FloatArray, out: FloatArray, startSec: Double): Double {
    val sr = 44100
    if (out.size < sr * 3) return Double.NaN
    val seg = out.copyOfRange(sr, sr * 2)
    val a = ((startSec + 0.2) * sr).toInt()
    var best = -1e30; var bestK = 0
    // tương quan thô theo bước 1 mẫu trên cửa sổ nhỏ quanh kỳ vọng (±0.3s) để nhanh: kỳ vọng vị trí = startSec + 1.0
    val centre = ((startSec + 1.0) * sr).toInt()
    var k = centre - (0.3 * sr).toInt()
    while (k <= centre + (0.3 * sr).toInt()) {
        if (k >= a - sr && k + seg.size <= src.size) {
            var s = 0.0
            var i = 0
            while (i < seg.size) { s += seg[i].toDouble() * src[k + i].toDouble(); i += 3 }
            if (s > best) { best = s; bestK = k }
        }
        k++
    }
    return (bestK - centre) * 1000.0 / sr
}

class Src(val name: String, val fps: Double, val hasAudio: Boolean)

fun makeSource(dir: File, name: String, fps: String, vcodec: List<String>, extra: List<String>, audio: Boolean, dur: Int = 40): Src {
    val out = File(dir, "$name.mp4")
    val args = ArrayList<String>()
    args += listOf("-f", "lavfi", "-i", "testsrc2=size=640x360:rate=$fps:duration=$dur")
    if (audio) args += listOf("-f", "lavfi", "-i", "anoisesrc=d=$dur:c=pink:r=44100:a=0.5:seed=7")
    args += listOf("-vf", "drawtext=text='%{n}':fontsize=60:fontcolor=white:box=1:boxcolor=black@0.6:x=20:y=20")
    args += vcodec + extra + listOf("-pix_fmt", "yuv420p")
    args += if (audio) listOf("-c:a", "aac", "-b:a", "128k", "-shortest") else listOf("-an")
    args += out.path
    ffmpeg(*args.toTypedArray())
    val parts = fps.split("/")
    val f = if (parts.size == 2) parts[0].toDouble() / parts[1].toDouble() else fps.toDouble()
    return Src(name, f, audio)
}

fun main() {
    val dir = File(System.getProperty("java.io.tmpdir"), "editlistcut_test_${System.nanoTime()}").apply { mkdirs() }
    println("Thư mục thử: ${dir.path}")

    // ---------------------------------------------------------------- 1. hàm thuần
    check("muxerFor mp4", EditListCut.muxerFor("mp4") == "mp4")
    check("muxerFor MP4 hoa", EditListCut.muxerFor("MP4") == "mp4")
    check("muxerFor m4v => mp4 (muxer 'm4v' của ffmpeg là H.264 thô)", EditListCut.muxerFor("m4v") == "mp4")
    check("muxerFor mov", EditListCut.muxerFor("mov") == "mov")
    check("muxerFor mkv không hỗ trợ", EditListCut.muxerFor("mkv") == null)
    check("muxerFor webm/ts/avi/3gp không hỗ trợ", listOf("webm", "ts", "avi", "3gp", "flv", "").all { EditListCut.muxerFor(it) == null })
    val cmd = EditListCut.command("/a b/in.mp4", "/a b/out.mp4", 14.32, 10.0, "mp4")
    check("command: -ss đặt TRƯỚC -i, đúng điểm, KHÔNG make_zero, có -c copy", cmd.startsWith("-y -ss 14.320 -i \"/a b/in.mp4\"") && cmd.contains("-c copy") && !cmd.contains("make_zero") && cmd.contains("-avoid_negative_ts disabled"), cmd)
    check("command: -t là thời lượng, -f muxer, đường dẫn có khoảng trắng được bọc", cmd.contains("-t 10.000") && cmd.contains("-f mp4") && cmd.endsWith("\"/a b/out.mp4\""), cmd)
    check("command: số nhỏ không ra dạng khoa học (1.0E-5)", !EditListCut.command("i", "o", 0.00001, 0.00001, "mp4").contains("E-"))
    check("remuxSupportedFor: mkv/flv/3gp có; mp4/ts/avi/webm không", listOf("mkv", "FLV", "3gp").all { EditListCut.remuxSupportedFor(it) } && listOf("mp4", "ts", "avi", "webm", "mov", "").none { EditListCut.remuxSupportedFor(it) })
    run {
        val c = EditListCut.parseCodecs("h264,video\naac,audio\nsubrip,subtitle\n")
        check("parseCodecs: h264 + aac", c.video == "h264" && c.audio == "aac")
        val c2 = EditListCut.parseCodecs("video,hevc\naudio,mp3\n")
        check("parseCodecs: thứ tự cột ngược + chỉ lấy luồng đầu", c2.video == "hevc" && c2.audio == "mp3")
        val c3 = EditListCut.parseCodecs("vp9,video\nopus,audio\nh264,video\n")
        check("parseCodecs: lấy luồng hình ĐẦU TIÊN", c3.video == "vp9")
        check("parseCodecs: rỗng", EditListCut.parseCodecs("").video == null && EditListCut.parseCodecs("garbage\n").audio == null)
        check("codecsFitMp4: h264+aac, hevc+ac3, h264 không tiếng => hợp", EditListCut.codecsFitMp4(c) && EditListCut.codecsFitMp4(EditListCut.Codecs("hevc", "ac3")) && EditListCut.codecsFitMp4(EditListCut.Codecs("h264", null)))
        check("codecsFitMp4: vp9/opus, mpeg4, h264+vorbis, không có hình => không hợp", !EditListCut.codecsFitMp4(c3) && !EditListCut.codecsFitMp4(EditListCut.Codecs("mpeg4", "aac")) && !EditListCut.codecsFitMp4(EditListCut.Codecs("h264", "vorbis")) && !EditListCut.codecsFitMp4(EditListCut.Codecs(null, "aac")))
    }
    run {
        val rc = EditListCut.command("in.mkv", "out.mp4", 14.32, 10.0, "mp4", remux = true)
        check("command remux: chỉ 1 hình + 1 tiếng (tuỳ chọn), bỏ phụ đề/dữ liệu, vẫn -c copy + không make_zero", rc.contains("-map 0:v:0 -map 0:a:0? -sn -dn") && rc.contains("-c copy") && !rc.contains("make_zero"), rc)
        check("command thường: không có -map", !EditListCut.command("in.mp4", "out.mp4", 1.0, 2.0, "mp4").contains("-map"))
    }
    check("checkOutput: file ra không có luồng hình (đã đo với nguồn .ts)", EditListCut.checkOutput(true, 1000, 6.0, 6.0, hasVideoStream = false)?.contains("luồng hình") == true)
    check("parsePreRoll: có đệm", abs(EditListCut.parsePreRoll("-4.320000,KD_\n") - 4.32) < 1e-9)
    check("parsePreRoll: log nhiễu quanh dòng gói", abs(EditListCut.parsePreRoll("ffprobe version 6.1\nsome warning\n-3.5,KD_\n") - 3.5) < 1e-9)
    check("parsePreRoll: không đệm (mốc dương)", EditListCut.parsePreRoll("0.085000,K__\n") == 0.0)
    check("parsePreRoll: mốc âm nhưng KHÔNG cờ D (vd file cũ) => 0", EditListCut.parsePreRoll("-0.080000,K__\n") == 0.0)
    check("parsePreRoll: rỗng/rác => 0", EditListCut.parsePreRoll("") == 0.0 && EditListCut.parsePreRoll("abc\n") == 0.0)
    check("parseDuration", EditListCut.parseDuration("10.120000\n") == 10.12 && EditListCut.parseDuration("N/A\n") == null && EditListCut.parseDuration("") == null)
    check("checkOutput: hợp lý", EditListCut.checkOutput(true, 1000, 10.12, 10.0) == null)
    check("checkOutput: file không có", EditListCut.checkOutput(false, 0, null, 10.0) != null)
    check("checkOutput: không đọc được thời lượng", EditListCut.checkOutput(true, 1000, null, 10.0) != null)
    check("checkOutput: edit list không được ghi (dài 14.4 thay vì 10)", EditListCut.checkOutput(true, 1000, 14.4, 10.0)?.contains("edit list") == true)
    check("checkOutput: ngắn bất thường", EditListCut.checkOutput(true, 1000, 5.0, 10.0) != null)
    check("describeSuccess: có số giây đệm", EditListCut.describeSuccess(4.32).contains("4.3s") && EditListCut.describeSuccess(4.32).contains("KHÔNG mã hoá lại"))

    // ---------------------------------------------------------------- 2. nguồn thử
    val srcs = mapOf(
        "bf3" to makeSource(dir, "bf3", "25", listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "20"), listOf("-g", "250", "-keyint_min", "250", "-sc_threshold", "0", "-bf", "3"), true),
        "bf0" to makeSource(dir, "bf0", "25", listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "20"), listOf("-g", "250", "-keyint_min", "250", "-sc_threshold", "0", "-bf", "0"), true),
        "open" to makeSource(dir, "open", "30000/1001", listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "20"), listOf("-g", "120", "-keyint_min", "120", "-sc_threshold", "0", "-bf", "3", "-x264-params", "open-gop=1"), true),
        "hevc" to makeSource(dir, "hevc", "25", listOf("-c:v", "libx265", "-preset", "ultrafast", "-crf", "24", "-tag:v", "hvc1"), listOf("-x265-params", "keyint=200:min-keyint=200:scenecut=0:bframes=4:log-level=none"), true),
        "noaud" to makeSource(dir, "noaud", "25", listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "20"), listOf("-g", "250", "-keyint_min", "250", "-sc_threshold", "0", "-bf", "3"), false)
    )
    val hashes = srcs.mapValues { frameHashes(File(dir, "${it.key}.mp4")) }
    val audios = srcs.filter { it.value.hasAudio }.mapValues { audioF32(File(dir, "${it.key}.mp4")) }
    check("nguồn thử sinh được", hashes.values.all { it.size > 900 }, hashes.mapValues { it.value.size }.toString())

    val plan = listOf(
        "bf3" to listOf(0.0, 0.3, 3.0, 9.98, 10.0, 10.001, 10.04, 14.32, 14.33, 14.35, 19.999, 29.5, 35.55),
        "bf0" to listOf(3.0, 10.0, 14.32, 14.33, 29.99),
        "open" to listOf(3.0, 4.004, 5.5, 9.9, 14.3),
        "hevc" to listOf(3.0, 8.0, 12.34, 23.99, 30.01),
        "noaud" to listOf(3.0, 14.32, 25.55)
    )
    val D = 6.0
    for ((name, points) in plan) {
        val src = srcs.getValue(name); val sh = hashes.getValue(name)
        for (s in points) {
            val out = File(dir, "o_${name}_$s.mp4")
            val (code, text) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "$name.mp4").path, out.path, s, D, EditListCut.muxerFor("mp4")!!)))
            check("[$name S=$s] ffmpeg chạy OK", code == 0 && out.exists(), text.take(200))
            if (code != 0 || !out.exists()) continue
            val oh = frameHashes(out)
            val idx = oh.map { sh.indexOf(it) }
            val expected = ceil(s * src.fps - 1e-6).toInt()
            check("[$name S=$s] khung đầu = khung nguồn #$expected (mốc ≥ S)", idx.isNotEmpty() && idx[0] == expected, "got=${idx.firstOrNull()}")
            check("[$name S=$s] KHÔNG mã hoá lại: mọi khung trùng md5 khung nguồn", idx.none { it < 0 }, "alien=${idx.count { it < 0 }}")
            // khoảng hở chỉ được nằm ở ≤3 khung CUỐI (B-frame cuối bị -t cắt — như cách cắt cũ), không được ở giữa
            val gaps = (0 until idx.size - 1).filter { idx[it + 1] != idx[it] + 1 }
            check("[$name S=$s] không có khoảng hở ở giữa file (chỉ ở ≤3 khung cuối)", gaps.all { it >= idx.size - 4 }, "gaps=$gaps n=${idx.size}")
            val dur = EditListCut.parseDuration(appProbe(EditListCut.durationProbeCommand(out.path)) ?: "")
            val wantDur = minOf(D, 40.0 - s) // điểm gần cuối file: chỉ còn lại ngần ấy
            check("[$name S=$s] thời lượng ≈ ${"%.2f".format(wantDur)} (-0.8…+0.8) và qua checkOutput", dur != null && EditListCut.checkOutput(true, out.length(), dur, wantDur) == null, "dur=$dur")
            if (src.hasAudio && s + 4.0 < 38.0) {
                val off = audioOffsetMs(audios.getValue(name), audioF32(out), s)
                check("[$name S=$s] lệch tiếng so với nguồn ≤ 1ms", !off.isNaN() && abs(off) <= 1.0, "off=$off")
            }
            val pre = EditListCut.parsePreRoll(appProbe(EditListCut.firstPacketProbeCommand(out.path)) ?: "")
            if (name == "bf3" && s == 14.32) check("[bf3 S=14.32] parsePreRoll đọc được ~4.32s từ ffprobe thật", abs(pre - 4.32) < 0.05, "pre=$pre")
            if (name == "bf3" && s == 10.0) check("[bf3 S=10.0] điểm trùng khung khoá => không đệm", pre < 0.05, "pre=$pre")
        }
    }

    // ---------------------------------------------------------------- 3. container .mov
    run {
        val out = File(dir, "o_mov.mov")
        val (code, _) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "bf3.mp4").path, out.path, 14.32, D, EditListCut.muxerFor("mov")!!)))
        val idx = frameHashes(out).map { hashes.getValue("bf3").indexOf(it) }
        check("[mov] khung đầu #358, không khung lạ", code == 0 && idx.firstOrNull() == 358 && idx.none { it < 0 }, "code=$code first=${idx.firstOrNull()}")
    }
    // m4v: đặt tên .m4v nhưng muxer mp4 (nếu để ffmpeg đoán theo đuôi sẽ ra H.264 thô)
    run {
        val out = File(dir, "o_m4v.m4v")
        val (code, _) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "bf3.mp4").path, out.path, 14.32, D, EditListCut.muxerFor("m4v")!!)))
        val idx = frameHashes(out).map { hashes.getValue("bf3").indexOf(it) }
        val hasAudio = (appProbe("-v error -select_streams a -show_entries stream=codec_type -of csv=p=0 \"${out.path}\"") ?: "").contains("audio")
        check("[m4v] ghi dạng mp4: khung đầu #358 + còn tiếng", code == 0 && idx.firstOrNull() == 358 && hasAudio, "code=$code first=${idx.firstOrNull()} audio=$hasAudio")
    }

    // ---------------------------------------------------------------- 4. cắt tiếp từ file đã cắt (cascade) + nén lại từ file đã cắt
    val c1 = File(dir, "c1.mp4")
    execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "bf3.mp4").path, c1.path, 14.32, 8.0, "mp4")))
    run {
        val c2 = File(dir, "c2.mp4")
        execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(c1.path, c2.path, 2.0, 4.0, "mp4")))
        val idx = frameHashes(c2).map { hashes.getValue("bf3").indexOf(it) }
        check("[cascade] cắt tiếp từ file đã cắt: khung đầu #408 (=358+50), không khung lạ", idx.firstOrNull() == 408 && idx.none { it < 0 }, "first=${idx.firstOrNull()}")
    }
    run {
        val t1 = File(dir, "t1.mp4")
        execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", c1.path, "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", t1.path))
        val n = frameHashes(t1).size
        check("[nén lại từ file đã cắt] số khung ≈ 200 (không lòi ~108 khung đệm)", n in 195..215, "n=$n")
    }

    // ---------------------------------------------------------------- 5. GHÉP kiểu app (concat demuxer -c copy)
    val c3 = File(dir, "c3.mp4")
    execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "bf3.mp4").path, c3.path, 30.0, 5.0, "mp4")))
    val preC1 = EditListCut.parsePreRoll(appProbe(EditListCut.firstPacketProbeCommand(c1.path)) ?: "")
    val preC3 = EditListCut.parsePreRoll(appProbe(EditListCut.firstPacketProbeCommand(c3.path)) ?: "")
    check("[merge] phát hiện file có đệm (c1 ~4.3s) và file không đệm (c3 cắt tại khung khoá)", abs(preC1 - 4.32) < 0.05 && preC3 < 0.05, "c1=$preC1 c3=$preC3")
    run {
        // đúng như VideoEngine.merge: file có đệm được thêm "option ignore_editlist 1"
        val list = File(dir, "list.txt"); val raw = File(dir, "merged.mp4")
        list.writeText("file '${c1.path}'\noption ignore_editlist 1\nfile '${c3.path}'\n")
        val (code, text) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", list.path, "-c", "copy", raw.path))
        val sh = hashes.getValue("bf3")
        val idx = frameHashes(raw).map { sh.indexOf(it) }
        check("[merge có option] ghép chạy được", code == 0 && raw.exists(), text.take(200))
        // c1 đọc thô bắt đầu ở khung khoá #250 (đệm lộ ra), c3 bắt đầu #750; không khung lạ; chỗ nối đúng
        check("[merge có option] bắt đầu ở khung khoá #250 (đệm lộ ra, như ghi chú đã nói), không khung lạ", idx.firstOrNull() == 250 && idx.none { it < 0 }, "first=${idx.firstOrNull()}")
        check("[merge có option] có đủ phần c3 (khung #750 có mặt)", idx.contains(750))
        val dur = EditListCut.parseDuration(appProbe(EditListCut.durationProbeCommand(raw.path)) ?: "") ?: -1.0
        // c1 thô: từ khung khoá 10.0 tới ~22.3 (≈12.4s) + c3 5.1s ≈ 17.5
        check("[merge có option] thời lượng hợp lý (~17.5s, KHÔNG phải 14.4/13.3 sai)", dur in 17.0..18.0, "dur=$dur")
        val a = audioF32(raw)
        val off = audioOffsetMs(audios.getValue("bf3"), a, 10.0 - 0.0)
        // âm thanh cũng bắt đầu quanh khung khoá 10.0: output [1s,2s] ↔ nguồn quanh 11.0 (cho phép ≤ 0.1s do tiền cuộn AAC)
        check("[merge có option] hình-tiếng đồng bộ (tiếng khớp nguồn quanh 11.0s, lệch ≤ 100ms)", !off.isNaN() && abs(off) <= 100.0, "off=$off")
    }
    run {
        // chứng minh LÝ DO cần option: không có option thì SAI điểm đầu
        val list = File(dir, "list_bad.txt"); val bad = File(dir, "merged_bad.mp4")
        list.writeText("file '${c1.path}'\nfile '${c3.path}'\n")
        execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", list.path, "-c", "copy", bad.path))
        val idx = frameHashes(bad).map { hashes.getValue("bf3").indexOf(it) }
        check("[merge KHÔNG option] (đối chứng) điểm đầu lệch: không phải #358 cũng không phải #250", idx.firstOrNull().let { it != 358 && it != 250 }, "first=${idx.firstOrNull()}")
    }

    // ---------------------------------------------------------------- 6. cắt SANG MP4 từ mkv/flv/3gp (remux, không mã hoá lại) + loại trừ ts/avi
    run {
        val bf3 = File(dir, "bf3.mp4"); val sh = hashes.getValue("bf3")
        // phụ đề kèm trong mkv (nếu không có `-map` thì mp4 không nhận subrip và lệnh hỏng)
        val srt = File(dir, "sub.srt").apply { writeText("1\n00:00:01,000 --> 00:00:03,000\nxin chao\n") }
        ffmpeg("-i", bf3.path, "-i", srt.path, "-map", "0:v", "-map", "0:a", "-map", "1:0", "-c", "copy", "-c:s", "srt", File(dir, "withsub.mkv").path)
        ffmpeg("-i", bf3.path, "-c", "copy", File(dir, "r.mkv").path)
        ffmpeg("-i", bf3.path, "-c", "copy", File(dir, "r.flv").path)
        ffmpeg("-i", bf3.path, "-c", "copy", File(dir, "r.3gp").path)
        for (name in listOf("r.mkv", "r.flv", "r.3gp", "withsub.mkv")) {
            val inp = File(dir, name)
            val codecs = EditListCut.parseCodecs(appProbe(EditListCut.codecProbeCommand(inp.path)) ?: "")
            check("[remux $name] codec đọc được = h264+aac và hợp MP4", codecs.video == "h264" && codecs.audio == "aac" && EditListCut.codecsFitMp4(codecs), "${codecs.video}/${codecs.audio}")
            for (st in listOf(3.0, 14.32, 25.55, 10.0)) {
                val out = File(dir, "rx_${name}_$st.mp4")
                val (code, text) = execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(inp.path, out.path, st, D, "mp4", remux = true)))
                check("[remux $name S=$st] ffmpeg chạy OK", code == 0 && out.exists(), text.take(200))
                if (code != 0 || !out.exists()) continue
                val idx = frameHashes(out).map { sh.indexOf(it) }
                val expected = ceil(st * 25.0 - 1e-6).toInt()
                check("[remux $name S=$st] khung đầu #$expected, không khung lạ (không mã hoá lại)", idx.firstOrNull() == expected && idx.none { it < 0 }, "first=${idx.firstOrNull()}")
                val gaps = (0 until idx.size - 1).filter { idx[it + 1] != idx[it] + 1 }
                check("[remux $name S=$st] không hở giữa file", gaps.all { it >= idx.size - 4 }, "gaps=$gaps")
                // So với tiếng của CHÍNH file đầu vào (mkv/flv/3gp tạo từ mp4 có thể lệch ~23ms (1 khung AAC) so với mp4 gốc do tiền cuộn AAC —
                // đó là đặc tính của bước đổi vỏ khi TẠO file thử, không phải của phép cắt)
                val off = audioOffsetMs(audioF32(inp), audioF32(out), st)
                check("[remux $name S=$st] lệch tiếng so với file đầu vào ≤ 1ms", !off.isNaN() && abs(off) <= 1.0, "off=$off")
                val outCodecs = EditListCut.parseCodecs(appProbe(EditListCut.codecProbeCommand(out.path)) ?: "")
                val dur = EditListCut.parseDuration(appProbe(EditListCut.durationProbeCommand(out.path)) ?: "")
                check("[remux $name S=$st] qua checkOutput (có hình, thời lượng hợp lý) và không còn phụ đề", EditListCut.checkOutput(true, out.length(), dur, D, outCodecs.video != null) == null, "dur=$dur")
            }
        }
        // .ts: đã đo là MẤT HÌNH — chốt chặn checkOutput phải bắt được; remuxSupportedFor("ts") đã false nên app không đề nghị
        ffmpeg("-i", bf3.path, "-c", "copy", "-f", "mpegts", File(dir, "r.ts").path)
        val outTs = File(dir, "rx_ts.mp4")
        execAll(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(EditListCut.command(File(dir, "r.ts").path, outTs.path, 3.0, D, "mp4", remux = true)))
        val tsCodecs = EditListCut.parseCodecs(appProbe(EditListCut.codecProbeCommand(outTs.path)) ?: "")
        val tsDur = EditListCut.parseDuration(appProbe(EditListCut.durationProbeCommand(outTs.path)) ?: "")
        check("[ts] (đối chứng) cắt .ts sang MP4 ra file KHÔNG có hình => checkOutput bắt được", tsCodecs.video == null && EditListCut.checkOutput(outTs.exists(), outTs.length(), tsDur, D, tsCodecs.video != null) != null, "video=${tsCodecs.video} dur=$tsDur")
    }

    dir.deleteRecursively()
    println("\nKẾT QUẢ: $passed PASS / $failed FAIL")
    if (failed > 0) System.exit(1)
}
