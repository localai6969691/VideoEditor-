# Test EditListCut — cắt chính xác KHÔNG mã hoá lại (19/11/2026)

Test TÍCH HỢP bằng FFmpeg/FFprobe THẬT trên máy sửa code (cần `ffmpeg` + `ffprobe` có libx264/libx265/aac/drawtext trong PATH, và `kotlinc`).
Chạy ĐÚNG lệnh app chạy (`EditListCut.command`) rồi đo kết quả.

```sh
cd tools/tests/editlistcut
kotlinc ../../../app/src/main/java/com/videoaistudio/app/video/EditListCut.kt EditListCutTest.kt -include-runtime -d editlistcut_test.jar
java -Dfile.encoding=UTF-8 -jar editlistcut_test.jar     # thoát mã 1 nếu có ca FAIL
```

Kết quả lần chạy cuối (19/11/2026, ffmpeg 6.1.1): **312 PASS / 0 FAIL**.

Nguồn thử: H.264 có B-frame (GOP 10s), H.264 không B-frame, H.264 GOP mở 29,97 fps, HEVC (bframes=4), H.264 không tiếng; mỗi khung vẽ số thứ tự.
31 điểm cắt (đầu file, sát/lệch khung khoá ±0.001…0.04s, giữa, gần cuối). Chứng minh được (ffmpeg, KHÔNG phải trình phát trên máy):
- Khung đầu giải mã ra = khung nguồn đầu tiên có mốc ≥ điểm chọn — 31/31.
- KHÔNG mã hoá lại: mọi khung trong file ra trùng md5 với khung nguồn.
- Lệch tiếng so với nguồn ≤ 1 ms (tương quan chéo trên tiếng nhiễu).
- Không có khoảng hở giữa file; chỉ có ≤ 3 khung cuối bị -t cắt (như cách cắt nhanh cũ — không phải lỗi mới). Thời lượng dư 0.06–0.25s.
- .mov và .m4v (ghi bằng muxer mp4) cũng đúng. Cắt tiếp từ file đã cắt đúng. Nén lại từ file đã cắt không lòi khung đệm.
- GHÉP: concat demuxer ghép thẳng file có đoạn đệm cho SAI điểm đầu (ca đối chứng) => `merge()` thêm `option ignore_editlist 1` cho
  file đó: ghép đúng + đồng bộ nhưng đoạn đệm lộ ra (đã nói trong ghi chú kết quả).

- Cắt THẲNG mkv/flv/3gp sang .mp4 (không mã hoá lại; `command(..., remux = true)`): khung đầu đúng, khung giống nguồn, tiếng lệch ≤1ms so với file đầu vào; mkv kèm phụ đề cũng đúng (nhờ `-map`/`-sn`).
- Đối chứng .ts: cắt sang MP4 ra file CHỈ CÒN TIẾNG (mất hình) ⇒ `checkOutput(hasVideoStream=false)` bắt được. .avi đo thấy lệch 1–2 khung nên không được đề nghị.

KHÔNG chứng minh được: ExoPlayer/trình phát/thư viện ảnh trên điện thoại có tôn trọng edit list không; FFmpegKit/FFprobeKit trên Android
(`-read_intervals "%+#1"` qua FFprobeKit.execute); `VideoEngine`/`VideoToolsActivity` (không có Android SDK).
