# Test SafeCopy + CutPointHint (16/11/2026)

Logic thuần JVM (không Android), kiểm bằng `kotlinc` thường:

```sh
cd tools/tests/safecopy
kotlinc ../../../app/src/main/java/com/videoaistudio/app/video/SafeCopy.kt \
        ../../../app/src/main/java/com/videoaistudio/app/video/CutPointHint.kt \
        SafeCopyTest.kt -include-runtime -d safecopy_test.jar
java -jar safecopy_test.jar
```

Chứng minh được: copy + kiểm lại file đích (bắt đúng kiểu "thư mục bị đổi tên giữa chừng" như `clearVideoInputCache`),
kiểm dung lượng trống, bộ đếm "đang copy" an toàn đa luồng, dòng log trạng thái ổ đĩa, dòng chữ "điểm cắt thật".

KHÔNG chứng minh được: hành vi trên Android thật (hệ thống có dọn file hay không), `FileUtils`/`VideoToolsActivity` (cần Android SDK —
môi trường sửa code không có), tốc độ copy.
