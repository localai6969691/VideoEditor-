import com.videoaistudio.app.video.CutPointHint
import com.videoaistudio.app.video.InsufficientStorageException
import com.videoaistudio.app.video.SafeCopy
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.Random
import java.util.concurrent.CancellationException

// Test thật (JVM thuần) cho SafeCopy + CutPointHint. Chạy: xem README.md cùng thư mục.
// Mỗi ca in PASS/FAIL; tổng kết ở cuối, thoát mã 1 nếu có ca FAIL.

var passed = 0
var failed = 0

fun check(name: String, cond: Boolean, detail: String = "") {
    if (cond) { passed++; println("PASS  $name") } else { failed++; println("FAIL  $name  $detail") }
}

inline fun <reified T : Throwable> expectThrows(name: String, block: () -> Unit): T? {
    return try {
        block()
        failed++; println("FAIL  $name  (không ném lỗi nào)"); null
    } catch (e: Throwable) {
        if (e is T) { passed++; println("PASS  $name  -> ${e.javaClass.simpleName}: ${e.message?.take(90)}"); e }
        else { failed++; println("FAIL  $name  (ném ${e.javaClass.simpleName}: ${e.message})"); null }
    }
}

fun tmpDir(): File = java.nio.file.Files.createTempDirectory("safecopy_test").toFile()
fun randomBytes(n: Int): ByteArray = ByteArray(n).also { Random(42).nextBytes(it) }

fun main() {
    // ---------- copyStream ----------
    run {
        val d = tmpDir(); val data = randomBytes(3 * 1024 * 1024 + 123)
        val dest = File(d, "a.mp4")
        var lastProgress = 0L
        val n = SafeCopy.copyStream(ByteArrayInputStream(data), dest, onProgress = { lastProgress = it })
        check("copy thường: trả đúng số byte", n == data.size.toLong(), "n=$n")
        check("copy thường: nội dung giống hệt", dest.readBytes().contentEquals(data))
        check("copy thường: tiến độ cuối = tổng", lastProgress == data.size.toLong())
    }
    run {
        // Mô phỏng ĐÚNG lỗi "0 byte" trong log: thư mục đích bị ĐỔI TÊN (như clearVideoInputCache) giữa lúc đang ghi.
        val d = tmpDir(); val dir = File(d, "video_input").apply { mkdirs() }
        val dest = File(dir, "big.mp4"); val data = randomBytes(5 * 1024 * 1024)
        var renamed = false
        val e = expectThrows<IOException>("copy: thư mục bị đổi tên giữa chừng => ném lỗi (không để lọt file 0 byte)") {
            SafeCopy.copyStream(ByteArrayInputStream(data), dest, onProgress = { p ->
                if (!renamed && p >= 2L * 1024 * 1024) { renamed = true; check("(tiền đề) đổi tên thư mục thành công", dir.renameTo(File(d, "video_input_trash_1"))) }
            })
        }
        check("copy: thông báo lỗi nói rõ file không còn nguyên vẹn", e?.message?.contains("không còn nguyên vẹn") == true, e?.message ?: "")
        check("copy: không để lại file đích", !dest.exists())
    }
    run {
        val d = tmpDir(); val dest = File(d, "x.mp4"); val data = randomBytes(4 * 1024 * 1024)
        expectThrows<IOException>("copy: file đích bị xoá giữa chừng => ném lỗi") {
            SafeCopy.copyStream(ByteArrayInputStream(data), dest, onProgress = { p -> if (p >= 1024 * 1024) dest.delete() })
        }
    }
    run {
        val d = tmpDir(); val dest = File(d, "empty.mp4")
        expectThrows<IOException>("copy: nguồn rỗng (0 byte) => ném lỗi") { SafeCopy.copyStream(ByteArrayInputStream(ByteArray(0)), dest) }
        check("copy rỗng: không để lại file", !dest.exists())
    }
    run {
        val d = tmpDir(); val dest = File(d, "c.mp4"); val data = randomBytes(6 * 1024 * 1024)
        var cancel = false
        expectThrows<CancellationException>("copy: huỷ giữa chừng => CancellationException") {
            SafeCopy.copyStream(ByteArrayInputStream(data), dest, onProgress = { if (it >= 1024 * 1024) cancel = true }, isCancelled = { cancel })
        }
        check("copy huỷ: đã dọn file dở dang", !dest.exists())
    }
    run {
        val d = tmpDir(); val dest = File(d, "ioerr.mp4")
        val bad = object : java.io.InputStream() {
            var calls = 0
            override fun read(): Int = -1
            override fun read(b: ByteArray, off: Int, len: Int): Int { calls++; if (calls == 1) { b.fill(1, off, off + 1000); return 1000 }; throw IOException("ENOSPC giả lập") }
        }
        expectThrows<IOException>("copy: lỗi đọc giữa chừng => ném lại lỗi gốc") { SafeCopy.copyStream(bad, dest) }
        check("copy lỗi đọc: đã dọn file dở dang", !dest.exists())
    }

    // ---------- checkFreeSpace ----------
    run {
        val d = tmpDir(); val dir = File(d, "sub/video_input") // chưa tồn tại
        val usable = d.usableSpace
        check("(tiền đề) máy test có usableSpace > 0", usable > 0, "usable=$usable")
        SafeCopy.checkFreeSpace(dir, 1024L * 1024, marginBytes = 0L)
        check("checkFreeSpace: file nhỏ, đệm 0 => qua; thư mục được tạo", dir.isDirectory)
        SafeCopy.checkFreeSpace(dir, -1L); SafeCopy.checkFreeSpace(dir, 0L)
        check("checkFreeSpace: kích thước không biết (<=0) => không kiểm, không ném", true)
        val e = expectThrows<InsufficientStorageException>("checkFreeSpace: cần nhiều hơn chỗ trống => ném InsufficientStorageException") {
            SafeCopy.checkFreeSpace(dir, usable + 1024L * 1024 * 1024)
        }
        check("checkFreeSpace: requiredBytes = size + đệm mặc định",
            e != null && e.requiredBytes == usable + 1024L * 1024 * 1024 + SafeCopy.FREE_SPACE_MARGIN_BYTES, "req=${e?.requiredBytes}")
        check("checkFreeSpace: thông báo tiếng Việt có chữ 'Không đủ dung lượng' + số GB", e?.message?.let { it.contains("Không đủ dung lượng") && it.contains("GB") } == true, e?.message ?: "")
        // biên: size + đệm đúng bằng usable => qua (không ném) — dùng đệm = usable - size
        val size = 1024L * 1024
        SafeCopy.checkFreeSpace(dir, size, marginBytes = (dir.usableSpace - size - 4L * 1024 * 1024).coerceAtLeast(0L))
        check("checkFreeSpace: còn dư vài MB so với (size+đệm) => qua", true)
    }

    // ---------- tracking / isCopying ----------
    run {
        check("isCopying ban đầu = false", !SafeCopy.isCopying())
        var inside = false
        SafeCopy.tracking { inside = SafeCopy.isCopying() }
        check("isCopying trong tracking = true", inside)
        check("isCopying sau tracking = false", !SafeCopy.isCopying())
        try { SafeCopy.tracking { throw IllegalStateException("x") } } catch (_: IllegalStateException) {}
        check("isCopying sau tracking ném lỗi = false (finally chạy)", !SafeCopy.isCopying())
        var nestedBoth = false
        SafeCopy.tracking { SafeCopy.tracking { nestedBoth = SafeCopy.isCopying() }; nestedBoth = nestedBoth && SafeCopy.isCopying() }
        check("tracking lồng nhau: còn true sau khi lớp trong thoát, false sau cùng", nestedBoth && !SafeCopy.isCopying())
        // đa luồng: 2 luồng cùng copy, isCopying phải true tới khi CẢ 2 xong
        val latch1 = java.util.concurrent.CountDownLatch(1); val latch2 = java.util.concurrent.CountDownLatch(1)
        val t1 = Thread { SafeCopy.tracking { latch1.await() } }; val t2 = Thread { SafeCopy.tracking { latch2.await() } }
        t1.start(); t2.start(); Thread.sleep(100)
        latch1.countDown(); t1.join()
        val afterOne = SafeCopy.isCopying()
        latch2.countDown(); t2.join()
        check("2 luồng: xong 1 luồng vẫn isCopying=true, xong cả 2 => false", afterOne && !SafeCopy.isCopying())
    }

    // ---------- describeState ----------
    run {
        val d = tmpDir(); val dir = File(d, "video_input").apply { mkdirs() }
        File(dir, "clip.mp4").writeBytes(ByteArray(1500))
        File(d, "video_input_trash_99").mkdirs()
        val present = SafeCopy.describeState(dir, File(dir, "clip.mp4"))
        check("describeState: file có mặt", present.contains("exists=true, length=1500"), present)
        check("describeState: liệt kê file trong thư mục", present.contains("clip.mp4=1500B"), present)
        check("describeState: thấy thư mục rác cùng gốc (dấu hiệu chính app đã đổi tên để xoá)", present.contains("video_input_trash_99"), present)
        check("describeState: có dung lượng ổ đĩa", present.contains("ổ đĩa: trống") && present.contains("GB"), present)
        File(dir, "clip.mp4").delete()
        val missing = SafeCopy.describeState(dir, File(dir, "clip.mp4"))
        check("describeState: file đã mất => exists=false, length=0", missing.contains("exists=false, length=0"), missing)
        dir.deleteRecursively()
        val noDir = SafeCopy.describeState(dir, File(dir, "clip.mp4"))
        check("describeState: cả thư mục đã mất => exists=false, không ném lỗi", noDir.contains("thư mục video_input: exists=false"), noDir)
    }

    // ---------- CutPointHint ----------
    run {
        Locale.setDefault(Locale("vi", "VN")) // máy người dùng: dấu thập phân là dấu phẩy — hàm phải vẫn ra dấu chấm
        check("formatTime 0", CutPointHint.formatTime(0.0) == "0:00.0", CutPointHint.formatTime(0.0))
        check("formatTime 2008.1 = 33:28.1", CutPointHint.formatTime(2008.1) == "33:28.1", CutPointHint.formatTime(2008.1))
        check("formatTime 3661.25 = 1:01:01.3 (làm tròn lên)", CutPointHint.formatTime(3661.25) == "1:01:01.3", CutPointHint.formatTime(3661.25))
        check("formatTime âm => 0:00.0", CutPointHint.formatTime(-5.0) == "0:00.0")
        check("formatTime 59.96 => 1:00.0 (không ra 0:59.10)", CutPointHint.formatTime(59.96) == "1:00.0", CutPointHint.formatTime(59.96))
        check("describe: trùng (chênh 0.0005)", CutPointHint.describe(2008.1005, 2008.1).contains("trùng khung khoá"))
        // (Không test đúng biên 0.03: 100.03-100.0 = 0.0300000000000025 do dấu phẩy động — biên chỉ là ngưỡng heuristic.)
        check("describe: chênh 0.029 (trong biên) => trùng", CutPointHint.describe(100.029, 100.0).contains("trùng khung khoá"))
        check("describe: chênh 0.031 (ngoài biên) => báo lệch", CutPointHint.describe(100.031, 100.0).contains("SỚM hơn"))
        val early = CutPointHint.describe(2009.1, 2008.1)
        check("describe: lùi 1.0s => 'SỚM hơn ... 1.0s' + mốc 33:28.1", early.contains("SỚM hơn") && early.contains("1.0s") && early.contains("33:28.1"), early)
        val big = CutPointHint.describe(2005.3, 2001.3)
        check("describe: lùi 4.0s (ca -1S nhảy 5s trong log)", big.contains("4.0s") && big.contains("33:21.3"), big)
        val late = CutPointHint.describe(100.0, 100.06)
        check("describe: khung khoá ngay sau => 'muộn hơn'", late.contains("muộn hơn"), late)
        check("describe: dùng dấu chấm dù Locale vi", !early.contains(",") || early.indexOf("1,0") < 0, early)
        check("UNKNOWN có nội dung", CutPointHint.UNKNOWN.isNotBlank())
    }

    println("\nTỔNG: $passed PASS, $failed FAIL")
    if (failed > 0) System.exit(1)
}
