# Test SmartCut — cắt chính xác từng khung hình (17/11/2026)

Test TÍCH HỢP bằng FFmpeg/FFprobe THẬT trên máy sửa code (cần `ffmpeg` + `ffprobe` có libx264/libx265/aac trong PATH, và `kotlinc`).
Test tự sinh video thử (Main + B-frame + ref=4, Baseline, không âm thanh, xoay 90°, H.265, mkv; khung khoá lẻ
`0, 6.5, 12.7, 25.3, 33.1, 47.9, 60.2, 75.4`), rồi chạy ĐÚNG các lệnh mà app sẽ chạy (`SmartCut.cutExact` qua `Runner`).

```sh
cd tools/tests/smartcut
kotlinc ../../../app/src/main/java/com/videoaistudio/app/video/SmartCut.kt SmartCutTest.kt -include-runtime -d smartcut_test.jar
java -Dfile.encoding=UTF-8 -jar smartcut_test.jar     # thoát mã 1 nếu có ca FAIL
```

Kết quả lần chạy cuối (17/11/2026, ffmpeg 6.1.1): 110 PASS / 0 FAIL.

Chứng minh được:
- Khung ĐẦU của file cắt khớp khung nguồn tại đúng điểm chọn (PSNR ≈ 45–46 dB) — kể cả điểm lẻ khung hình (30.017s).
- Phần giữ nguyên (copy) GIỐNG HỆT nguồn từng bit: 100/100 khung có md5 trùng (tìm khung đầu của phần copy trong output rồi so liên tiếp).
- Giải mã toàn bộ file không lỗi; thời lượng ≈ kỳ vọng (−0.1…+0.4s, do B-frame như cắt nhanh); hình/tiếng lệch ≤ 0.3s.
- Nhánh quay về cắt nhanh: xoay, H.265, mkv, không đủ điều kiện => UNSUPPORTED; ffmpeg lỗi => FAILED; huỷ => CANCELLED; cả ba
  đều dọn sạch file tạm và KHÔNG để lại output.
- Chặn sớm đoạn đuôi nhảy sai khung khoá (mô phỏng mkv thưa Cues).
- Chọn bộ mã hoá theo danh sách FFmpeg thật có (`parseEncoders`/`pickEncoder`): bản FFmpeg trong app KHÔNG có libx264 nên dùng
  `h264_mediacodec`. Máy sửa code không có mediacodec => ca L GIẢ LẬP nó bằng libx264 theo bitrate + profile High (≠ nguồn Main, nên
  SPS đổi giữa luồng): luồng xử lý vẫn đúng (khung đầu PSNR ≥ 33, 100/100 khung phần giữ nguyên giống nguồn, giải mã sạch).
  Ca này KHÔNG chứng minh chip thật xử lý đúng — chỉ chứng minh phần logic/ghép nối không phụ thuộc libx264.
- Kiểm hình/tiếng lệch ≤ 0.5s, không có bộ mã hoá H.264 => UNSUPPORTED.

Hai LỖI THẬT do test này bắt được (đã sửa trong SmartCut.kt, ghi để khỏi lặp lại):
1. `-copypriorss 0` ở lệnh đoạn ĐUÔI làm mất chính khung khoá nextKey (vì seek ở nextKey+5ms) => đuôi chỉ còn 66/510 khung.
   Chỉ dùng `-copypriorss 0` ở đoạn ĐẦU (để bỏ audio tiền-cuộn trước điểm bắt đầu).
2. MKV: `-ss` copy nhảy về khung khoá TRƯỚC khung khoá mong muốn (Cues thưa) => kết quả dài 27.96s thay vì 20s. mkv không còn được hỗ trợ.

KHÔNG chứng minh được: `h264_mediacodec` thật có chạy đúng lệnh `-c:v h264_mediacodec -bitrate_mode 2 -b:v Nk -pix_fmt yuv420p` rồi ra MPEG-TS hợp lệ hay không;
bộ giải mã phần cứng trên điện thoại thật khi SPS/PPS đổi giữa chừng; FFmpegKit/FFprobeKit trên Android
(chỉ chạy ffmpeg/ffprobe trên máy sửa code); tốc độ mã hoá trên điện thoại; `VideoEngine`/`VideoToolsActivity` (không có Android SDK).
