import com.videoaistudio.app.video.SmartCut
import java.io.File
import java.util.concurrent.TimeUnit

// Test thật cho SmartCut: sinh video thử bằng ffmpeg trên máy, cắt bằng ĐÚNG các lệnh mà app sẽ chạy, rồi đo kết quả
// bằng ffmpeg/ffprobe. Chạy: xem README.md cùng thư mục. Thoát mã 1 nếu có ca FAIL.

var passed = 0
var failed = 0
fun check(name: String, cond: Boolean, detail: String = "") {
    if (cond) { passed++; println("PASS  $name") } else { failed++; println("FAIL  $name  $detail") }
}

/** Tách chuỗi lệnh kiểu shell: khoảng trắng phân tách, nháy kép gom lại. */
fun tokenize(s: String): List<String> {
    val out = ArrayList<String>(); val cur = StringBuilder(); var q = false
    for (c in s) when {
        c == '"' -> q = !q
        c == ' ' && !q -> { if (cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() } }
        else -> cur.append(c)
    }
    if (cur.isNotEmpty()) out.add(cur.toString())
    return out
}

fun exec(cmd: List<String>, timeoutSec: Long = 300): Pair<Int, String> {
    val p = ProcessBuilder(cmd).redirectErrorStream(false).start()
    val out = StringBuilder(); val err = StringBuilder()
    val t1 = Thread { out.append(p.inputStream.bufferedReader().readText()) }.apply { start() }
    val t2 = Thread { err.append(p.errorStream.bufferedReader().readText()) }.apply { start() }
    if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return -1 to "timeout" }
    t1.join(); t2.join()
    return p.exitValue() to (out.toString() + (if (p.exitValue() != 0) "\n" + err.toString() else ""))
}

class LocalRunner(var cancelAfterFfmpegCalls: Int = -1) : SmartCut.Runner {
    var ffmpegCalls = 0
    override fun probe(args: String): String? {
        val (code, text) = exec(listOf("ffprobe") + tokenize(args))
        return if (code == 0) text else null
    }
    override fun encoders(): String? = exec(listOf("ffmpeg", "-hide_banner", "-encoders")).second
    override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit): SmartCut.StepResult {
        ffmpegCalls++
        val (code, text) = exec(listOf("ffmpeg", "-hide_banner", "-loglevel", "error") + tokenize(args))
        onProgress(100)
        return SmartCut.StepResult(code == 0, false, text)
    }
}

/** Như exec nhưng LUÔN trả cả stdout lẫn stderr (ffmpeg in thống kê PSNR ra stderr). */
fun execAll(cmd: List<String>, timeoutSec: Long = 300): String {
    val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
    val out = StringBuilder()
    val t = Thread { out.append(p.inputStream.bufferedReader().readText()) }.apply { start() }
    if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return "timeout" }
    t.join()
    return out.toString()
}

fun ff(vararg a: String): Boolean = exec(listOf("ffmpeg", "-hide_banner", "-loglevel", "error", "-y") + a.toList()).first == 0

fun durationOf(f: File): Double =
    if (!f.exists()) -1.0 else exec(listOf("ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f.path)).second.trim().toDoubleOrNull() ?: -1.0

/** Đọc 1 số từ ffprobe, trả -1 nếu không có (tránh NumberFormatException che mất lỗi thật). */
fun probeNumber(vararg args: String): Double = exec(listOf("ffprobe", "-v", "error") + args.toList()).second.trim().toDoubleOrNull() ?: -1.0

fun decodeErrors(f: File): Int = exec(listOf("ffmpeg", "-v", "error", "-i", f.path, "-f", "null", "-")).second.lines().count { it.isNotBlank() }

/** md5 từng khung hình đã giải mã (chỉ hình), theo thứ tự hiển thị. ss<0 = từ đầu file; n = số khung tối đa. */
fun frameMd5(f: File, ss: Double, n: Int): List<String> {
    val args = ArrayList<String>(listOf("ffmpeg", "-v", "error"))
    if (ss >= 0) { args += "-ss"; args += "%.3f".format(java.util.Locale.US, ss) }
    args += listOf("-i", f.path, "-an", "-f", "framemd5", "-")
    return exec(args).second.lines().filter { it.isNotBlank() && !it.startsWith("#") && it.count { c -> c == ',' } >= 5 }
        .map { it.split(",")[5].trim() }.let { if (n > 0) it.take(n) else it }
}

fun psnrFirstFrame(out: File, src: File, srcSs: Double, dir: File): Double {
    val a = File(dir, "a.png"); val b = File(dir, "b.png")
    ff("-i", out.path, "-frames:v", "1", a.path)
    ff("-ss", "%.3f".format(java.util.Locale.US, srcSs), "-i", src.path, "-frames:v", "1", b.path)
    val text = execAll(listOf("ffmpeg", "-hide_banner", "-i", a.path, "-i", b.path, "-lavfi", "psnr", "-f", "null", "-"))
    val m = Regex("average:([0-9.]+|inf)").find(text) ?: return -1.0
    return if (m.groupValues[1] == "inf") 999.0 else m.groupValues[1].toDouble()
}

fun main() {
    val dir = java.nio.file.Files.createTempDirectory("smartcut_test").toFile()
    val kf = "0,6.5,12.7,25.3,33.1,47.9,60.2,75.4"
    val v = "testsrc2=size=1280x720:rate=30:duration=90"; val a = "sine=frequency=440:sample_rate=44100:duration=90"
    val srcM = File(dir, "srcM.mp4"); val srcB = File(dir, "srcB.mp4"); val srcMkv = File(dir, "srcM.mkv")
    val srcNoA = File(dir, "srcNoAudio.mp4"); val srcRot = File(dir, "srcRot.mp4"); val srcHevc = File(dir, "srcHevc.mp4")
    println("== tạo video thử (khung khoá lẻ: $kf)")
    check("tạo srcM (Main, ref=4, B-frame, AAC)", ff("-f", "lavfi", "-i", v, "-f", "lavfi", "-i", a, "-c:v", "libx264", "-preset", "medium", "-profile:v", "main", "-crf", "23",
        "-pix_fmt", "yuv420p", "-x264-params", "ref=4:bframes=3:weightp=0:scenecut=0:keyint=900:min-keyint=1", "-force_key_frames", kf, "-c:a", "aac", "-b:a", "128k", "-shortest", srcM.path))
    check("tạo srcB (Baseline CAVLC không B-frame)", ff("-f", "lavfi", "-i", v, "-f", "lavfi", "-i", a, "-c:v", "libx264", "-preset", "fast", "-profile:v", "baseline", "-crf", "23",
        "-pix_fmt", "yuv420p", "-force_key_frames", kf, "-c:a", "aac", "-b:a", "128k", "-shortest", srcB.path))
    check("tạo srcM.mkv", ff("-i", srcM.path, "-c", "copy", srcMkv.path))
    check("tạo video không âm thanh", ff("-i", srcM.path, "-an", "-c:v", "copy", srcNoA.path))
    check("tạo video xoay 90°", ff("-display_rotation", "90", "-i", srcM.path, "-t", "40", "-c", "copy", srcRot.path))
    check("tạo video H.265", ff("-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=40", "-f", "lavfi", "-i", "sine=duration=40", "-c:v", "libx265", "-preset", "ultrafast",
        "-force_key_frames", kf, "-c:a", "aac", "-shortest", srcHevc.path))

    // ---------- phân tích + quyết định (dữ liệu ffprobe thật)
    val runner = LocalRunner()
    fun probeOf(f: File) = SmartCut.parseProbe(runner.probe(SmartCut.infoProbeCommand(f.path))!!)
    fun kfOf(f: File, s: Double) = SmartCut.parseKeyframes(runner.probe(SmartCut.keyframeProbeCommand(f.path, s))!!)
    run {
        val p = probeOf(srcM)
        check("parseProbe srcM: h264/Main/level 31/yuv420p/30fps/aac", p.videoCodec == "h264" && p.profile == "Main" && p.level == 31 && p.pixFmt == "yuv420p" && p.fps == 30.0 && p.audioCodec == "aac" && !p.rotated, p.toString())
        check("parseProbe srcRot: nhận ra xoay", probeOf(srcRot).rotated)
        check("parseProbe srcHevc: codec hevc", probeOf(srcHevc).videoCodec == "hevc")
        check("parseProbe srcNoAudio: không có audio", probeOf(srcNoA).audioCodec == null)
        val ks = kfOf(srcM, 30.0)
        check("parseKeyframes từ 30s: thấy 25.3 (trước) 33.1 47.9 60.2 75.4", ks.take(5) == listOf(25.3, 33.1, 47.9, 60.2, 75.4), ks.toString())
        val pm = probeOf(srcM)
        check("decide: 30→50 => Smart(33.1)", SmartCut.decide(30.0, 50.0, "mp4", pm, ks) == SmartCut.Plan.Smart(33.1))
        check("decide: đúng khung khoá 33.1 => CopyIsExact", SmartCut.decide(33.1, 50.0, "mp4", pm, ks) == SmartCut.Plan.CopyIsExact)
        check("decide: 33.1004 (nhiễu Float) => CopyIsExact", SmartCut.decide(33.1004, 50.0, "mp4", pm, ks) == SmartCut.Plan.CopyIsExact)
        check("decide: 33.1 + 0.05 => Smart (không coi là khung khoá)", SmartCut.decide(33.15, 50.0, "mp4", pm, kfOf(srcM, 33.15)) is SmartCut.Plan.Smart)
        check("decide: 0s => CopyIsExact", SmartCut.decide(0.0, 10.0, "mp4", pm, kfOf(srcM, 0.0)) == SmartCut.Plan.CopyIsExact)
        check("decide: 30→32 (trước khung khoá kế) => HeadOnly", SmartCut.decide(30.0, 32.0, "mp4", pm, ks) == SmartCut.Plan.HeadOnly)
        check("decide: xoay => Unsupported", SmartCut.decide(30.0, 40.0, "mp4", probeOf(srcRot), kfOf(srcRot, 30.0)) is SmartCut.Plan.Unsupported)
        check("decide: H.265 => Unsupported", SmartCut.decide(30.0, 40.0, "mp4", probeOf(srcHevc), kfOf(srcHevc, 30.0)) is SmartCut.Plan.Unsupported)
        check("decide: .avi => Unsupported", SmartCut.decide(30.0, 40.0, "avi", pm, ks) is SmartCut.Plan.Unsupported)
        check("decide: đoạn rỗng => Unsupported", SmartCut.decide(40.0, 40.0, "mp4", pm, ks) is SmartCut.Plan.Unsupported)
        check("decide: không có khung khoá, đoạn dài => Unsupported", SmartCut.decide(30.0, 400.0, "mp4", pm, emptyList()) is SmartCut.Plan.Unsupported)
        check("decide: không có khung khoá, đoạn ngắn => HeadOnly", SmartCut.decide(30.0, 40.0, "mp4", pm, emptyList()) == SmartCut.Plan.HeadOnly)
        check("x264Args giữ profile/level", SmartCut.x264Args(pm).contains("-profile:v main") && SmartCut.x264Args(pm).contains("-level 3.1"), SmartCut.x264Args(pm))
        check("lastNumber bỏ dòng nhiễu", SmartCut.lastNumber("[h264 @ 0x1] warning\n20.099479\n") == 20.099479)
        check("parseProbe: width/height/bit_rate", pm.width == 1280 && pm.height == 720 && (pm.videoBitRate > 0 || pm.containerBitRate > 0), pm.toString())
        val encText = " Encoders:\n V..... = Video\n ------\n V....D libx264              libx264 H.264\n V..... h264_mediacodec      H.264 Android MediaCodec encoder (codec h264)\n A....D aac                  AAC\n"
        val encs = SmartCut.parseEncoders(encText)
        check("parseEncoders: đọc đúng tên, bỏ dòng chú giải", encs == setOf("libx264", "h264_mediacodec", "aac"), encs.toString())
        check("pickEncoder: ưu tiên libx264 khi có", SmartCut.pickEncoder(encs) == SmartCut.Encoder.LIBX264)
        check("pickEncoder: chỉ có h264_mediacodec => MEDIACODEC", SmartCut.pickEncoder(setOf("h264_mediacodec", "aac")) == SmartCut.Encoder.MEDIACODEC)
        check("pickEncoder: không có bộ H.264 => null", SmartCut.pickEncoder(setOf("aac", "libkvazaar")) == null)
        check("headBitrateKbps: 1.2× bitrate video, kẹp 2000..60000", SmartCut.headBitrateKbps(pm.copy(videoBitRate = 10_000_000)) == 12000 &&
            SmartCut.headBitrateKbps(pm.copy(videoBitRate = 100_000)) == 2000 && SmartCut.headBitrateKbps(pm.copy(videoBitRate = 200_000_000)) == 60000)
        check("headBitrateKbps: không có bitrate => ước lượng theo điểm ảnh, vẫn trong khoảng", SmartCut.headBitrateKbps(pm.copy(videoBitRate = 0, containerBitRate = 0)) in 2000..60000)
        val mc = SmartCut.headCommand("in.mp4", 30.0, 3.1, pm.copy(videoBitRate = 10_000_000), "h.ts", SmartCut.Encoder.MEDIACODEC)
        check("headCommand MEDIACODEC: cờ giống Compress (-bitrate_mode 2 -b:v), không -crf/-profile", mc.contains("-c:v h264_mediacodec -bitrate_mode 2 -b:v 12000k") && !mc.contains("-crf") && !mc.contains("-profile"), mc)
        check("countFrameLines đếm số + N/A, bỏ nhiễu", SmartCut.countFrameLines("1.0\nN/A\n[x] err\n2.5\n") == 3)
    }

    // ---------- cắt thật
    fun exactCase(name: String, src: File, s: Double, e: Double, expectStatus: SmartCut.Status, expectPsnr: Boolean = true) {
        println("== $name")
        val r = LocalRunner()
        val out = File(dir, "out_${name.hashCode()}.${src.extension}")
        val tmp = File(dir, "tmp_${name.hashCode()}")
        val o = SmartCut.cutExact(src.path, out.path, s, e, 90.0, tmp, r)
        println("   status=${o.status}; ${o.note}")
        check("$name: trạng thái = $expectStatus", o.status == expectStatus, "${o.status}: ${o.note}")
        check("$name: đã dọn thư mục tạm", !tmp.exists())
        if (expectStatus != SmartCut.Status.EXACT_DONE) { check("$name: không để lại output", !out.exists()); return }
        check("$name: output tồn tại", out.exists() && out.length() > 0)
        if (!out.exists()) return
        val d = durationOf(out)
        check("$name: thời lượng ${"%.2f".format(java.util.Locale.US, d)}s ≈ ${e - s}s (−0.1..+0.4)", d >= (e - s) - 0.1 && d <= (e - s) + 0.4, "d=$d")
        check("$name: giải mã toàn bộ không lỗi", decodeErrors(out) == 0)
        if (expectPsnr) {
            val p = psnrFirstFrame(out, src, s, dir)
            check("$name: khung ĐẦU khớp nguồn tại ${s}s (PSNR ${"%.1f".format(java.util.Locale.US, p)} dB ≥ 38)", p >= 38.0, "psnr=$p")
        }
        val nextKey = SmartCut.parseKeyframes(LocalRunner().probe(SmartCut.keyframeProbeCommand(src.path, s))!!).firstOrNull { it > s + 0.002 }
        if (o.note.contains("giữ nguyên phần còn lại") && nextKey != null) {
            // phần đuôi bắt đầu ở khung khoá nextKey của nguồn: tìm khung đó trong output rồi so 100 khung liên tiếp
            val ms = frameMd5(src, nextKey, 100); val mo = frameMd5(out, -1.0, 0)
            val at = if (ms.isEmpty()) -1 else mo.indexOf(ms[0])
            val same = if (at < 0) 0 else (0 until ms.size).count { at + it < mo.size && mo[at + it] == ms[it] }
            check("$name: 100 khung phần giữ nguyên GIỐNG HỆT nguồn ($same/${ms.size}, bắt đầu ở khung #$at của output)", ms.size == 100 && at >= 0 && same == 100)
        }
    }
    exactCase("A srcM 30→50 (Smart)", srcM, 30.0, 50.0, SmartCut.Status.EXACT_DONE)
    exactCase("B srcM 33.1→50 (đúng khung khoá)", srcM, 33.1, 50.0, SmartCut.Status.COPY_IS_EXACT)
    exactCase("C srcM 30→32 (HeadOnly)", srcM, 30.0, 32.0, SmartCut.Status.EXACT_DONE)
    exactCase("D srcM 3→40 (K=0)", srcM, 3.0, 40.0, SmartCut.Status.EXACT_DONE)
    exactCase("E srcB 45→70 (baseline)", srcB, 45.0, 70.0, SmartCut.Status.EXACT_DONE)
    exactCase("F srcM.mkv 30→50 (mkv: Cues thưa => không hỗ trợ, quay về cắt nhanh)", srcMkv, 30.0, 50.0, SmartCut.Status.UNSUPPORTED)
    exactCase("G không âm thanh 30→50", srcNoA, 30.0, 50.0, SmartCut.Status.EXACT_DONE)
    exactCase("H srcM 30.017→55.5 (điểm lẻ khung hình)", srcM, 30.017, 55.5, SmartCut.Status.EXACT_DONE)
    exactCase("I srcM 33.15→60 (vừa sau khung khoá: đầu 1.5 khung)", srcM, 33.15, 60.0, SmartCut.Status.EXACT_DONE)
    exactCase("J xoay => quay về cắt nhanh", srcRot, 30.0, 38.0, SmartCut.Status.UNSUPPORTED)
    exactCase("K H.265 => quay về cắt nhanh", srcHevc, 30.0, 38.0, SmartCut.Status.UNSUPPORTED)

    // ---------- đồng bộ hình/tiếng tại chỗ nối: thời lượng audio ≈ video
    run {
        val out = File(dir, "out_sync.mp4")
        SmartCut.cutExact(srcM.path, out.path, 30.0, 50.0, 90.0, File(dir, "tmp_sync"), LocalRunner())
        check("đồng bộ: có output", out.exists())
        val vd = probeNumber("-select_streams", "v", "-show_entries", "stream=duration", "-of", "csv=p=0", out.path)
        val ad = probeNumber("-select_streams", "a", "-show_entries", "stream=duration", "-of", "csv=p=0", out.path)
        check("đồng bộ: |thời lượng hình − tiếng| ≤ 0.3s (${"%.3f".format(java.util.Locale.US, vd)} vs ${"%.3f".format(java.util.Locale.US, ad)})", vd >= 0 && ad >= 0 && kotlin.math.abs(vd - ad) <= 0.3)
        val vs = probeNumber("-select_streams", "v", "-show_entries", "stream=start_time", "-of", "csv=p=0", out.path)
        val aS = probeNumber("-select_streams", "a", "-show_entries", "stream=start_time", "-of", "csv=p=0", out.path)
        check("đồng bộ: |start hình − start tiếng| ≤ 0.15s (${"%.3f".format(java.util.Locale.US, vs)} vs ${"%.3f".format(java.util.Locale.US, aS)})", vs >= 0 && aS >= 0 && kotlin.math.abs(vs - aS) <= 0.15)
    }

    // ---------- đoạn đuôi nhảy sai khung khoá (mô phỏng container seek thưa) => bị chặn SỚM, dọn sạch
    run {
        val out = File(dir, "out_badtail.mp4"); val tmp = File(dir, "tmp_badtail")
        val badTail = object : SmartCut.Runner {
            val inner = LocalRunner()
            override fun probe(args: String) = inner.probe(args)
            override fun encoders() = inner.encoders()
            override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit): SmartCut.StepResult {
                // lệnh đuôi ghi ra tail.ts: mô phỏng mkv thưa Cues — seek nhảy về khung khoá 25.3 (TRƯỚC) nhưng -t vẫn tính từ
                // điểm yêu cầu, nên đoạn đuôi dài thừa ~7.8s (đúng triệu chứng đo được: 27.96s thay vì 20s)
                val cmd = if (args.contains("tail.ts")) args.replace(Regex("-ss [0-9.]+"), "-ss 25.305").replace(Regex("-t [0-9.]+"), "-t 24.700") else args
                return inner.ffmpeg(cmd, durationSec, onProgress)
            }
        }
        val o = SmartCut.cutExact(srcM.path, out.path, 30.0, 50.0, 90.0, tmp, badTail)
        check("đuôi nhảy sai khung khoá => FAILED có lý do", o.status == SmartCut.Status.FAILED && o.note.contains("đoạn đuôi"), o.toString())
        check("đuôi sai: dọn sạch, không để output", !tmp.exists() && !out.exists())
    }

    // ---------- bản FFmpeg KHÔNG có libx264 (như trong app): chọn h264_mediacodec. Máy sửa code không có mediacodec nên GIẢ LẬP bằng
    // libx264 theo BITRATE + profile High (khác nguồn Main => SPS đổi giữa luồng) để kiểm cả luồng xử lý. KHÔNG chứng minh gì về chip thật.
    run {
        val out = File(dir, "out_mc.mp4"); val tmp = File(dir, "tmp_mc")
        val mcRunner = object : SmartCut.Runner {
            val inner = LocalRunner()
            override fun probe(args: String) = inner.probe(args)
            override fun encoders() = " Encoders:\n V..... h264_mediacodec      H.264 Android MediaCodec encoder (codec h264)\n A....D aac   AAC\n"
            override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit): SmartCut.StepResult {
                val cmd = args.replace(Regex("-c:v h264_mediacodec -bitrate_mode 2 -b:v (\\d+)k"), "-c:v libx264 -preset ultrafast -b:v $1k -maxrate $1k -bufsize $1k -bf 0 -profile:v high")
                return inner.ffmpeg(cmd, durationSec, onProgress)
            }
        }
        val o = SmartCut.cutExact(srcM.path, out.path, 30.0, 50.0, 90.0, tmp, mcRunner)
        println("== L giả lập h264_mediacodec (bitrate, High≠Main)\n   status=${o.status}; ${o.note}")
        check("L mediacodec(giả lập): EXACT_DONE và ghi tên bộ mã hoá", o.status == SmartCut.Status.EXACT_DONE && o.note.contains("h264_mediacodec"), o.toString())
        if (out.exists()) {
            check("L: giải mã toàn bộ không lỗi", decodeErrors(out) == 0)
            val p = psnrFirstFrame(out, srcM, 30.0, dir)
            check("L: khung ĐẦU khớp nguồn (PSNR ${"%.1f".format(java.util.Locale.US, p)} dB ≥ 33, mã hoá theo bitrate nên thấp hơn CRF)", p >= 33.0, "psnr=$p")
            val nk = 33.1
            val ms = frameMd5(srcM, nk, 100); val mo = frameMd5(out, -1.0, 0); val at = if (ms.isEmpty()) -1 else mo.indexOf(ms[0])
            val same = if (at < 0) 0 else (0 until ms.size).count { at + it < mo.size && mo[at + it] == ms[it] }
            check("L: 100 khung phần giữ nguyên GIỐNG HỆT nguồn ($same/100)", at >= 0 && same == 100)
            val prof = exec(listOf("ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "packet=pts_time", "-of", "csv=p=0", out.path)).second.isNotBlank()
            check("L: đọc được gói video", prof)
        }
    }
    run {
        val none = object : SmartCut.Runner {
            val inner = LocalRunner()
            override fun probe(args: String) = inner.probe(args)
            override fun encoders() = " Encoders:\n A....D aac   AAC\n V..... libkvazaar   kvazaar HEVC\n"
            override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit) = SmartCut.StepResult(false, false, "không được gọi")
        }
        val o = SmartCut.cutExact(srcM.path, File(dir, "out_none.mp4").path, 30.0, 50.0, 90.0, File(dir, "tmp_none"), none)
        check("không có bộ mã hoá H.264 => UNSUPPORTED có lý do", o.status == SmartCut.Status.UNSUPPORTED && o.note.contains("bộ mã hoá"), o.toString())
        check("không có bộ mã hoá: không tạo gì", !File(dir, "tmp_none").exists() && !File(dir, "out_none.mp4").exists())
    }

    // ---------- huỷ giữa chừng: không để lại gì
    run {
        val out = File(dir, "out_cancel.mp4"); val tmp = File(dir, "tmp_cancel")
        var calls = 0
        val cancelRunner = object : SmartCut.Runner {
            val inner = LocalRunner()
            override fun probe(args: String) = inner.probe(args)
            override fun encoders() = inner.encoders()
            override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit): SmartCut.StepResult {
                calls++
                return if (calls == 2) SmartCut.StepResult(false, true, "huỷ") else inner.ffmpeg(args, durationSec, onProgress)
            }
        }
        val o = SmartCut.cutExact(srcM.path, out.path, 30.0, 50.0, 90.0, tmp, cancelRunner)
        check("huỷ ở bước 2 => CANCELLED", o.status == SmartCut.Status.CANCELLED, o.toString())
        check("huỷ: không còn file tạm / output", !tmp.exists() && !out.exists())
    }
    // ---------- ffmpeg lỗi => FAILED, dọn sạch
    run {
        val out = File(dir, "out_fail.mp4"); val tmp = File(dir, "tmp_fail")
        val failRunner = object : SmartCut.Runner {
            val inner = LocalRunner()
            override fun probe(args: String) = inner.probe(args)
            override fun encoders() = inner.encoders()
            override fun ffmpeg(args: String, durationSec: Double, onProgress: (Int) -> Unit) = SmartCut.StepResult(false, false, "boom")
        }
        val o = SmartCut.cutExact(srcM.path, out.path, 30.0, 50.0, 90.0, tmp, failRunner)
        check("ffmpeg lỗi => FAILED (người gọi quay về cắt nhanh)", o.status == SmartCut.Status.FAILED, o.toString())
        check("ffmpeg lỗi: dọn sạch", !tmp.exists() && !out.exists())
    }

    println("\nTỔNG: $passed PASS, $failed FAIL")
    dir.deleteRecursively()
    if (failed > 0) System.exit(1)
}
