// Stub CÓ CHỨC NĂNG: giả lập 1 model upscale "phóng nearest ×scale" với shape đầu vào tuỳ chọn (tĩnh/động), đúng bố cục NCHW/NHWC.
package ai.onnxruntime

import java.nio.FloatBuffer

class OrtException(msg: String) : Exception(msg)
enum class OnnxJavaType { FLOAT, INT64, UINT8 }
interface OnnxTensorLike
abstract class ValueInfo
class TensorInfo(@JvmField val shape: LongArray, @JvmField val type: OnnxJavaType) : ValueInfo()
class NodeInfo(val info: ValueInfo)
interface OnnxValue : AutoCloseable { val info: ValueInfo; val value: Any? }

/** Mô tả model giả. inputShape có thể chứa -1 (động). scaleOut: hệ số nguyên; badOutputWidth để thử lỗi. */
class FakeModel(val inputShape: LongArray, val nchw: Boolean, val scale: Int, val badOutputWidthDelta: Int = 0, val badChannels: Boolean = false)
object FakeOrt { lateinit var model: FakeModel; var runCount = 0; var closedTensors = 0; var openTensors = 0 }

class OnnxTensor(val data: FloatArray, val shape: LongArray) : OnnxValue, OnnxTensorLike {
    init { FakeOrt.openTensors++ }
    override val info: ValueInfo get() = TensorInfo(shape, OnnxJavaType.FLOAT)
    override val value: Any?
        get() {
            // mảng lồng nhau 4 chiều như ONNX Runtime thật trả về
            val (a, b, c, d) = shape.map { it.toInt() }
            var k = 0
            return Array(a) { Array(b) { Array(c) { FloatArray(d) { data[k++] } } } }
        }
    val floatBuffer: FloatBuffer? get() = FloatBuffer.wrap(data.copyOf())
    override fun close() { FakeOrt.closedTensors++ }
    companion object {
        @JvmStatic @Throws(OrtException::class)
        fun createTensor(env: OrtEnvironment, buf: FloatBuffer, shape: LongArray): OnnxTensor {
            val a = FloatArray(buf.remaining()); buf.get(a); return OnnxTensor(a, shape)
        }
    }
}

class OrtEnvironment private constructor() {
    @Throws(OrtException::class)
    fun createSession(model: ByteArray, options: OrtSession.SessionOptions): OrtSession = OrtSession(FakeOrt.model)
    companion object { @JvmStatic fun getEnvironment(): OrtEnvironment = OrtEnvironment() }
}

class OrtSession(private val m: FakeModel) : AutoCloseable {
    val inputInfo: Map<String, NodeInfo> get() = mapOf("input" to NodeInfo(TensorInfo(m.inputShape, OnnxJavaType.FLOAT)))
    val inputNames: Set<String> get() = setOf("input")

    @Throws(OrtException::class)
    fun run(inputs: Map<String, out OnnxTensorLike>): Result {
        FakeOrt.runCount++
        val t = inputs["input"] as OnnxTensor
        // kiểm shape đầu vào như ORT thật: chiều cố định phải khớp
        if (t.shape.size != m.inputShape.size) throw OrtException("rank mismatch")
        for (i in t.shape.indices) if (m.inputShape[i] > 0 && m.inputShape[i] != t.shape[i])
            throw OrtException("Got invalid dimensions for input: input index: $i Got: ${t.shape[i]} Expected: ${m.inputShape[i]}")
        val s = m.scale
        val n = t.shape.map { it.toInt() }
        val h = if (m.nchw) n[2] else n[1]; val w = if (m.nchw) n[3] else n[2]
        val oh = h * s; val ow = w * s + m.badOutputWidthDelta
        val out = FloatArray(3 * oh * ow)
        for (c in 0 until 3) for (y in 0 until oh) for (x in 0 until ow) {
            val sx = minOf(x / s, w - 1); val sy = y / s
            out[if (m.nchw) c * oh * ow + y * ow + x else (y * ow + x) * 3 + c] =
                t.data[if (m.nchw) c * h * w + sy * w + sx else (sy * w + sx) * 3 + c]
        }
        val outShape = if (m.nchw) longArrayOf(1, (if (m.badChannels) 4 else 3).toLong(), oh.toLong(), ow.toLong()) else longArrayOf(1, oh.toLong(), ow.toLong(), (if (m.badChannels) 4 else 3).toLong())
        return Result(listOf(OnnxTensor(out, outShape)))
    }
    @Throws(OrtException::class) fun endProfiling(): String = ""
    override fun close() {}

    class Result(private val vals: List<OnnxValue>) : AutoCloseable, Iterable<Map.Entry<String, OnnxValue>> {
        operator fun get(i: Int): OnnxValue = vals[i]
        override fun iterator(): Iterator<Map.Entry<String, OnnxValue>> = emptyList<Map.Entry<String, OnnxValue>>().iterator()
        override fun close() { vals.forEach { it.close() } }
    }
    class SessionOptions : AutoCloseable {
        fun addNnapi() {}; fun addQnn(m: Map<String, String>) {}; fun addConfigEntry(k: String, v: String) {}; fun enableProfiling(p: String) {}
        override fun close() {}
    }
}
