package android.graphics

class Bitmap private constructor(val width: Int, val height: Int) {
    val px = IntArray(width * height)
    enum class Config { ARGB_8888 }
    var recycled = false
    fun getPixels(dst: IntArray, off: Int, stride: Int, x: Int, y: Int, w: Int, h: Int) {
        for (r in 0 until h) for (c in 0 until w) dst[off + r * stride + c] = px[(y + r) * width + x + c]
    }
    fun setPixels(src: IntArray, off: Int, stride: Int, x: Int, y: Int, w: Int, h: Int) {
        require(x >= 0 && y >= 0 && x + w <= width && y + h <= height) { "setPixels ngoài ảnh" }
        for (r in 0 until h) for (c in 0 until w) px[(y + r) * width + x + c] = src[off + r * stride + c]
    }
    fun recycle() { recycled = true }
    companion object {
        @JvmStatic fun createBitmap(w: Int, h: Int, c: Config) = Bitmap(w, h)
        @JvmStatic fun createScaledBitmap(src: Bitmap, w: Int, h: Int, filter: Boolean) = Bitmap(w, h)
    }
}
