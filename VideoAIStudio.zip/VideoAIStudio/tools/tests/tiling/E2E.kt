import ai.onnxruntime.FakeModel
import ai.onnxruntime.FakeOrt
import android.content.Context
import android.graphics.Bitmap
import com.videoaistudio.app.inference.*
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.Random

var fails = 0
fun ok(c: Boolean, m: () -> String) { if (!c) { fails++; println("FAIL: " + m()) } }

fun bmp(w: Int, h: Int, seed: Long): Bitmap {
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val r = Random(seed)
    val p = IntArray(w * h) { (0xFF shl 24) or r.nextInt(0x1000000) }
    b.setPixels(p, 0, w, 0, 0, w, h); return b
}

fun main() = runBlocking {
    val f = File.createTempFile("fakemodel", ".onnx").apply { writeBytes(byteArrayOf(1)); deleteOnExit() }
    val cfg = ModelConfig("1", "fake", TaskType.VIDEO_UPSCALE, ProviderSource.LOCAL_MODEL, HardwareTarget.CPU, localFilePath = f.absolutePath)
    var cases = 0
    for (nchw in listOf(true, false)) for (scale in listOf(2, 4)) for ((tw, th) in listOf(32 to 32, 48 to 24, 16 to 64)) for ((w, h) in listOf(100 to 70, 20 to 10, tw to th, tw + 1 to th - 1, 1 to 1, 130 to 5)) {
        val layout = if (nchw) TensorLayout.NCHW else TensorLayout.NHWC
        val src = bmp(w, h, (w * 31 + h).toLong())

        // chuẩn: model ĐỘNG -> đường chạy cũ (cả khung hình)
        FakeOrt.model = FakeModel(if (nchw) longArrayOf(1, 3, -1, -1) else longArrayOf(1, -1, -1, 3), nchw, scale)
        val pDyn = LocalModelProvider(Context(), cfg)
        val whole = pDyn.upscaleFrame(src, layout)
        ok(whole != null, { "đường động lỗi: ${pDyn.lastError}" })

        // model TĨNH cỡ ô -> đường chia ô
        FakeOrt.model = FakeModel(if (nchw) longArrayOf(1, 3, th.toLong(), tw.toLong()) else longArrayOf(1, th.toLong(), tw.toLong(), 3), nchw, scale)
        FakeOrt.runCount = 0
        val pFix = LocalModelProvider(Context(), cfg)
        val tiled = pFix.upscaleFrame(src, layout)
        cases++
        ok(tiled != null && pFix.lastError == null, { "đường chia ô lỗi: ${pFix.lastError} (nchw=$nchw s=$scale tile=${tw}x$th img=${w}x$h)" })
        if (tiled != null && whole != null) {
            ok(tiled.width == w * scale && tiled.height == h * scale, { "kích thước ${tiled.width}x${tiled.height}" })
            ok(tiled.width == whole.width && tiled.px.contentEquals(whole.px), { "KHÁC đường cả khung (nchw=$nchw s=$scale tile=${tw}x$th img=${w}x$h)" })
            val pad = TiledUpscale.effectivePad(tw, th)
            ok(FakeOrt.runCount == TiledUpscale.tileCount(w, h, tw, th, pad), { "số lần chạy ${FakeOrt.runCount}" })
        }
    }
    println("A. chia ô == cả khung (model pointwise): $cases ca")
    ok(FakeOrt.openTensors == FakeOrt.closedTensors, { "rò tensor: mở ${FakeOrt.openTensors}, đóng ${FakeOrt.closedTensors}" })
    println("A2. tensor mở/đóng: ${FakeOrt.openTensors}/${FakeOrt.closedTensors}")

    // ---- dò thông số model ----
    for (nchw in listOf(true, false)) {
        FakeOrt.model = FakeModel(if (nchw) longArrayOf(1, 3, 40, 56) else longArrayOf(1, 40, 56, 3), nchw, 4)
        val sp = LocalModelProvider(Context(), cfg).detectUpscaleModelSpec()
        ok(sp != null && sp.detectedScaleFactor == 4 && !sp.supportsDynamicResolution && sp.fixedInputHeight == 40 && sp.fixedInputWidth == 56, { "spec tĩnh sai: $sp" })
        FakeOrt.model = FakeModel(if (nchw) longArrayOf(-1, 3, -1, -1) else longArrayOf(-1, -1, -1, 3), nchw, 2)
        val sd = LocalModelProvider(Context(), cfg).detectUpscaleModelSpec()
        ok(sd != null && sd.detectedScaleFactor == 2 && sd.supportsDynamicResolution && sd.fixedInputHeight == null, { "spec động sai: $sd" })
        // batch động nhưng H/W cố định -> vẫn là TĨNH
        FakeOrt.model = FakeModel(if (nchw) longArrayOf(-1, 3, 32, 32) else longArrayOf(-1, 32, 32, 3), nchw, 3)
        val sb = LocalModelProvider(Context(), cfg).detectUpscaleModelSpec()
        ok(sb != null && sb.detectedScaleFactor == 3 && !sb.supportsDynamicResolution && sb.fixedInputWidth == 32, { "spec batch động sai: $sb" })
        println("B. dò spec nchw=$nchw: tĩnh=${sp}  động=${sd}  batch-động=${sb}")
    }

    // ---- đường lỗi: phải trả null + lastError có nội dung ----
    FakeOrt.model = FakeModel(longArrayOf(1, 3, 32, 32), true, 2, badOutputWidthDelta = 1)
    val pe = LocalModelProvider(Context(), cfg)
    ok(pe.upscaleFrame(bmp(70, 70, 1), TensorLayout.NCHW) == null && pe.lastError?.contains("bội số") == true, { "lỗi bội số: ${pe.lastError}" })
    println("C1. đầu ra không nguyên bội -> ${pe.lastError}")
    FakeOrt.model = FakeModel(longArrayOf(1, 3, 32, 32), true, 2, badChannels = true)
    val pc = LocalModelProvider(Context(), cfg)
    ok(pc.upscaleFrame(bmp(70, 70, 1), TensorLayout.NCHW) == null && pc.lastError?.contains("kênh") == true, { "lỗi kênh: ${pc.lastError}" })
    println("C2. đầu ra 4 kênh -> ${pc.lastError}")
    // model tĩnh nhưng gọi với layout sai (NHWC trong khi model NCHW): không được crash
    FakeOrt.model = FakeModel(longArrayOf(1, 3, 32, 32), true, 2)
    val pl = LocalModelProvider(Context(), cfg)
    val rl = pl.upscaleFrame(bmp(70, 70, 1), TensorLayout.NHWC)
    println("C3. layout sai -> ${if (rl == null) "null, lỗi: ${pl.lastError}" else "(không lỗi, ảnh ${rl.width}x${rl.height})"}")
    // thành công thì lastError phải được xoá
    val pg = LocalModelProvider(Context(), cfg)
    FakeOrt.model = FakeModel(longArrayOf(1, 3, 32, 32), true, 2)
    ok(pg.upscaleFrame(bmp(40, 40, 2), TensorLayout.NCHW) != null && pg.lastError == null, { "thành công mà lastError=${pg.lastError}" })

    println(if (fails == 0) "\nTẤT CẢ ĐẠT" else "\nCÓ $fails LỖI")
    if (fails != 0) System.exit(1)
}
