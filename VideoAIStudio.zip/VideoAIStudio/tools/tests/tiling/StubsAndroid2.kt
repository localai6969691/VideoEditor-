package android.net

class Uri {
    companion object { @JvmStatic fun parse(s: String): Uri = Uri() }
}
