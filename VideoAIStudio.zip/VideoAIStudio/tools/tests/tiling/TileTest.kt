import com.videoaistudio.app.inference.TiledUpscale
import com.videoaistudio.app.inference.TiledUpscale.TileResult
import java.util.Random
import java.util.concurrent.CancellationException

var failures = 0
fun check(cond: Boolean, msg: () -> String) {
    if (!cond) { failures++; if (failures <= 15) println("FAIL: " + msg()) }
}

/** Model giả "cục bộ": làm mờ hộp bán kính r (clamp-edge, số nguyên) từng kênh rồi phóng nearest ×s. */
fun fakeModel(px: IntArray, w: Int, h: Int, r: Int, s: Int): TileResult {
    val blurred = IntArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        var a = 0; var rr = 0; var g = 0; var b = 0; var n = 0
        for (dy in -r..r) for (dx in -r..r) {
            val sx = (x + dx).coerceIn(0, w - 1); val sy = (y + dy).coerceIn(0, h - 1)
            val p = px[sy * w + sx]
            a += (p ushr 24) and 0xFF; rr += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; b += p and 0xFF; n++
        }
        blurred[y * w + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
    }
    val ow = w * s; val oh = h * s
    val out = IntArray(ow * oh)
    for (y in 0 until oh) for (x in 0 until ow) out[y * ow + x] = blurred[(y / s) * w + (x / s)]
    return TileResult(out, ow, oh)
}

class ArraySink : TiledUpscale.Sink {
    lateinit var out: IntArray; var ow = 0; var oh = 0; lateinit var cover: IntArray; var begins = 0
    override fun begin(outWidth: Int, outHeight: Int) { begins++; ow = outWidth; oh = outHeight; out = IntArray(ow * oh); cover = IntArray(ow * oh) }
    override fun write(x: Int, y: Int, width: Int, height: Int, pixels: IntArray) {
        for (r in 0 until height) for (c in 0 until width) {
            out[(y + r) * ow + x + c] = pixels[r * width + c]; cover[(y + r) * ow + x + c]++
        }
    }
}

fun main() {
    val rnd = Random(12345)

    // ---- 1. Kiểm tra kế hoạch chia trục ----
    var planCases = 0
    for (tile in listOf(1, 2, 7, 8, 16, 33, 64, 100, 128, 256)) {
        val pads = listOf(0, 1, 2, 4, 8, 16, TiledUpscale.effectivePad(tile, tile)).distinct().filter { 2 * it < tile }
        for (pad in pads) for (size in (1..600 step 7).toList() + listOf(tile - 1, tile, tile + 1, 2 * tile, 2 * tile + 1).filter { it >= 1 }) {
            val spans = TiledUpscale.plan(size, tile, pad)
            planCases++
            // lõi liền nhau, phủ đúng [0,size), không chồng
            check(spans.first().coreStart == 0 && spans.last().coreEnd == size) { "phủ sai size=$size tile=$tile pad=$pad" }
            for (i in 1 until spans.size) check(spans[i].coreStart == spans[i - 1].coreEnd) { "lõi không liền size=$size tile=$tile pad=$pad" }
            for (sp in spans) {
                check(sp.coreEnd > sp.coreStart) { "lõi rỗng size=$size tile=$tile pad=$pad" }
                if (size <= tile) {
                    check(spans.size == 1 && sp.windowStart == 0, { "ảnh nhỏ: phải 1 ô size=$size tile=$tile" })
                } else {
                    check(sp.windowStart >= 0 && sp.windowStart + tile <= size) { "ô ra ngoài ảnh size=$size tile=$tile pad=$pad $sp" }
                    check(sp.coreEnd - sp.coreStart <= tile - 2 * pad) { "lõi quá dài size=$size tile=$tile pad=$pad $sp" }
                    check(sp.coreStart >= sp.windowStart && sp.coreEnd <= sp.windowStart + tile) { "lõi ngoài ô size=$size tile=$tile pad=$pad $sp" }
                    val left = sp.coreStart - sp.windowStart
                    val right = sp.windowStart + tile - sp.coreEnd
                    check(left >= minOf(pad, sp.coreStart)) { "thiếu ngữ cảnh trái size=$size tile=$tile pad=$pad $sp" }
                    check(right >= minOf(pad, size - sp.coreEnd)) { "thiếu ngữ cảnh phải size=$size tile=$tile pad=$pad $sp" }
                }
            }
            if (size > tile) {
                val lens = spans.map { it.coreEnd - it.coreStart }
                check(lens.max() - lens.min() <= 1) { "lõi không đều size=$size tile=$tile pad=$pad $lens" }
            }
        }
    }
    println("1. kế hoạch trục: $planCases ca")

    // ---- 2. Tương đương số học: ghép ô == chạy cả ảnh ----
    var eqCases = 0
    val tiles = listOf(16 to 16, 32 to 24, 64 to 64, 40 to 128, 128 to 96)
    for ((tw, th) in tiles) {
        val pad = TiledUpscale.effectivePad(tw, th)
        for (r in listOf(0, 1, 2).filter { it <= pad }) for (s in listOf(1, 2, 3, 4)) {
            val sizes = listOf(1, 2, 5, tw - 1, tw, tw + 1, 2 * tw - 2 * pad, 2 * tw + 3, 3 * tw + 7, 77, 150)
            for (w in sizes.filter { it >= 1 }.distinct()) for (h in listOf(1, th - 1, th, th + 1, 2 * th + 5, 61, 140).filter { it >= 1 }.distinct()) {
                val src = IntArray(w * h) { rnd.nextInt() }
                val expected = fakeModel(src, w, h, r, s)
                val sink = ArraySink()
                var calls = 0
                val scale = TiledUpscale.run(src, w, h, tw, th, pad, { t ->
                    calls++
                    check(t.size == tw * th) { "ô sai cỡ ${t.size} != ${tw * th}" }
                    fakeModel(t, tw, th, r, s)
                }, sink)
                eqCases++
                check(scale == s) { "hệ số $scale != $s" }
                check(sink.begins == 1 && sink.ow == w * s && sink.oh == h * s) { "begin sai" }
                check(calls == TiledUpscale.tileCount(w, h, tw, th, pad)) { "số ô $calls != tileCount" }
                check(sink.cover.all { it == 1 }) { "phủ không đúng 1 lần w=$w h=$h tile=${tw}x$th s=$s" }
                var firstDiff = -1
                for (i in expected.pixels.indices) if (expected.pixels[i] != sink.out[i]) { firstDiff = i; break }
                check(firstDiff < 0) { "KHÁC KẾT QUẢ CẢ ẢNH w=$w h=$h tile=${tw}x$th pad=$pad r=$r s=$s tại ${firstDiff % (w * s)},${firstDiff / (w * s)}" }
            }
        }
    }
    println("2. tương đương số học: $eqCases ca")

    // ---- 2b. Đối chứng ÂM: pad quá nhỏ so với bán kính mờ PHẢI cho kết quả khác (chứng tỏ test đủ nhạy) ----
    run {
        val tw = 32; val th = 32; val w = 100; val h = 100; val r = 3; val s = 2
        val src = IntArray(w * h) { rnd.nextInt() }
        val expected = fakeModel(src, w, h, r, s)
        val sink = ArraySink()
        TiledUpscale.run(src, w, h, tw, th, 1, { t -> fakeModel(t, tw, th, r, s) }, sink)
        val differs = expected.pixels.indices.any { expected.pixels[it] != sink.out[it] }
        check(differs) { "đối chứng âm: pad=1 < r=3 lẽ ra phải lệch nhưng lại khớp → test không đủ nhạy" }
        println("2b. đối chứng âm (pad < bán kính mờ → lệch): ${if (differs) "đúng như dự đoán" else "SAI"}")
    }

    // ---- 3. Lỗi ----
    try { TiledUpscale.run(IntArray(100), 10, 10, 8, 8, 1, { null }, ArraySink()); check(false) { "null phải ném lỗi" } }
    catch (e: IllegalStateException) { println("3a. runTile=null -> '${e.message}'") }
    try { TiledUpscale.run(IntArray(100), 10, 10, 8, 8, 1, { TileResult(IntArray(12 * 8), 12, 8) }, ArraySink()); check(false) { "bội số không nguyên phải ném lỗi" } }
    catch (e: IllegalStateException) { println("3b. bội số không nguyên -> '${e.message}'") }
    try { TiledUpscale.run(IntArray(100), 10, 10, 8, 8, 1, { TileResult(IntArray(16 * 24), 16, 24) }, ArraySink()); check(false) { "2 chiều khác hệ số phải ném lỗi" } }
    catch (e: IllegalStateException) { println("3c. 2 chiều khác hệ số -> '${e.message}'") }
    var n = 0
    try { TiledUpscale.run(IntArray(100 * 100), 100, 100, 16, 16, 2, { t -> fakeModel(t, 16, 16, 0, 2) }, ArraySink(), { ++n > 3 }); check(false) { "huỷ phải ném lỗi" } }
    catch (e: CancellationException) { println("3d. huỷ -> '${e.message}'") }

    // ---- 4. Cỡ thực tế (chỉ đếm ô, không chạy model) ----
    for ((w, h) in listOf(1920 to 1080, 1280 to 720, 3840 to 2160)) for (t in listOf(64, 128, 256)) {
        val pad = TiledUpscale.effectivePad(t, t)
        println("4. ${w}x$h ô ${t}x$t pad=$pad -> ${TiledUpscale.tileCount(w, h, t, t, pad)} ô/khung hình")
    }

    println(if (failures == 0) "\nTẤT CẢ ĐẠT" else "\nCÓ $failures LỖI")
    if (failures != 0) System.exit(1)
}
