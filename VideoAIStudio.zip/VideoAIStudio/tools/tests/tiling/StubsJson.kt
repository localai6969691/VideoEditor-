package org.json

class JSONObject {
    fun optJSONObject(k: String): JSONObject? = null
    fun optString(k: String, d: String): String = d
}

class JSONArray(s: String) {
    fun length(): Int = 0
    fun optJSONObject(i: Int): JSONObject? = null
}
