package android.content

import android.net.Uri
import java.io.InputStream

class ApplicationInfo { @JvmField var nativeLibraryDir: String = "" }
class ContentResolver { fun openInputStream(u: Uri): InputStream? = null }
open class Context {
    val contentResolver: ContentResolver get() = ContentResolver()
    val applicationInfo: ApplicationInfo get() = ApplicationInfo()
}
