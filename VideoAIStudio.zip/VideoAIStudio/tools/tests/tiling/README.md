# Kiểm tra số học chia ô (TiledUpscale) — chạy NGOÀI Android, không thuộc build Gradle

Cần `kotlinc` (đã thử với 1.9.24) + `kotlinx-coroutines-core-jvm.jar` (có sẵn trong thư mục `lib` của bản kotlinc).
Các lớp ONNX Runtime/Android ở đây là **GIẢ** (do người viết tự viết theo chữ ký API) — chỉ chứng minh logic chia/ghép và luồng
`LocalModelProvider.upscaleFrame`, KHÔNG chứng minh chạy được trên máy thật hay với model thật.

```
P=app/src/main/java/com/videoaistudio/app/inference
# 1. Thuần (không cần stub): chia trục + ghép ô == chạy cả ảnh
kotlinc tools/tests/tiling/TileTest.kt $P/TiledUpscale.kt -d out1 && java -cp "out1:<kotlin-stdlib.jar>" TileTestKt
# 2. Qua LocalModelProvider với ORT giả
cd tools/tests/tiling && kotlinc -cp <kotlinx-coroutines-core-jvm.jar> FakeOrt.kt BitmapStub.kt StubsAndroid2.kt StubsAndroid3.kt StubsJson.kt E2E.kt \
  ../../../$P/InferenceTypes.kt ../../../$P/IInferenceProvider.kt ../../../$P/ImageTensorUtils.kt ../../../$P/TiledUpscale.kt ../../../$P/LocalModelProvider.kt -d out2 \
  && java -cp "out2:<kotlin-stdlib.jar>:<kotlinx-coroutines-core-jvm.jar>" E2EKt
```
Cả hai in "TẤT CẢ ĐẠT" khi thành công (thoát mã 1 nếu có lỗi).
